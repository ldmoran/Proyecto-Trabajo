package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.CoberturaCxpDTO;
import com.finanzas.gestionfinanzas.dto.FacturaPagableDTO;
import com.finanzas.gestionfinanzas.dto.ResumenCxpFuenteDTO;
import com.finanzas.gestionfinanzas.entity.EgresoCxpPagable;
import com.finanzas.gestionfinanzas.entity.FlujoCajaCxpAsignada;
import com.finanzas.gestionfinanzas.repository.apps.XxocsApAsignaFacturaTmpRepository;
import com.finanzas.gestionfinanzas.repository.pam.PamAsignaFacturaTmpRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaCxpAsignadaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaCxpPagableRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

// Cruza la vista de Cuentas por Pagar del ERP (EgresoCxpService, datasource "apps")
// con lo que YA quedó comprometido por otros reportes (FC_EGR_CXP_ASIGNADA,
// datasource "bdd") para saber, factura por factura y en orden de prioridad, cuáles
// están realmente disponibles para este reporte. El cruce se hace en Java porque
// son dos bases Oracle físicamente distintas — no hay forma de hacerlo en un
// solo SELECT.
@Service
public class FlujoCajaCxpPagableService {

    // Índices de columna de las filas que devuelve EgresoCxpService.obtenerTodasLasFacturas().
    private static final int ORDEN = 0, FUENTE = 1, INVOICE_ID = 2, PROVEEDOR = 3, TIPO_DOCUMENTO = 4, DOCUMENTO = 5,
            FECHA_DOCUMENTO = 6, TERMINO_PAGO = 7, GRUPO_PAGO = 8, CATEGORIA = 9, METODO_PAGO = 10,
            FECHA_VENCIMIENTO = 11, IMPORTE_A_PAGAR = 12, DESCRIPCION = 13, PRIORIZADO = 14;

    private static final String[] MESES = {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO",
            "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"};
    private static final String[] MESES_ABREV = {"ENE", "FEB", "MAR", "ABR", "MAY", "JUN",
            "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"};

    private final FlujoCajaCxpPagableRepository pagableRepository;
    private final FlujoCajaCxpAsignadaRepository asignadaRepository;
    private final EgresoCxpService egresoCxpService;
    private final PamAsignaFacturaTmpRepository pamAsignaRepository;
    private final XxocsApAsignaFacturaTmpRepository xxocsApAsignaRepository;

    // Offset que se le suma al INVOICE_ID SOLO al mandarlo a PAM_ASIGNA_FACTURAS_TMP
    // (nunca a XXOCS_AP_ASIGNA_FACTURAS_TMP) mientras el sistema esté en pruebas —
    // esa tabla ya está en producción y de verdad la usa el ERP, así que hay que
    // evitar que un INVOICE_ID de prueba choque con uno real. Se apaga a mano
    // (poniendo el valor en 0 en el YAML) el día que este sistema pase a producción
    // de verdad — ver application.yaml (flujo-caja.offset-invoice-id-pam-pec).
    @Value("${flujo-caja.offset-invoice-id-pam-pec:0}")
    private long offsetInvoiceIdPam;

    public FlujoCajaCxpPagableService(FlujoCajaCxpPagableRepository pagableRepository,
                                       FlujoCajaCxpAsignadaRepository asignadaRepository,
                                       EgresoCxpService egresoCxpService,
                                       PamAsignaFacturaTmpRepository pamAsignaRepository,
                                       XxocsApAsignaFacturaTmpRepository xxocsApAsignaRepository) {
        this.pagableRepository = pagableRepository;
        this.asignadaRepository = asignadaRepository;
        this.egresoCxpService = egresoCxpService;
        this.pamAsignaRepository = pamAsignaRepository;
        this.xxocsApAsignaRepository = xxocsApAsignaRepository;
    }

    // Resumen en vivo: hasta qué factura alcanzaría a pagar, salteando las que ya
    // están comprometidas por OTRO reporte ya Autorizado. idReporteActual puede
    // venir null (reporte todavía sin guardar) — ahí se excluyen las de TODOS los
    // reportes, porque no hay forma de saber "cuáles son mías" sin ID.
    public CoberturaCxpDTO calcularCobertura(BigDecimal montoDisponible, Long idReporteActual) {
        List<Object[]> disponibles = obtenerDisponibles(idReporteActual);
        List<Object[]> cubiertas = calcularCubiertas(disponibles, montoDisponible);
        return construirDTO(cubiertas, disponibles.size());
    }

    // Lista completa (no solo el resumen) de las facturas cubiertas con
    // montoDisponible — para el anexo "Facturas que se pueden pagar" del PDF (ver
    // FlujoCajaFirmaService). A propósito NO lee la copia local
    // FC_EGR_CXP_PAGABLE (compartida entre TODOS los reportes, se reescribe
    // cada vez que cualquiera aprieta "Actualizar" en cualquier semana): la calcula
    // en vivo, propia de este reporte, para que el PDF de un reporte no dependa de
    // lo último que haya tocado otro usuario en otra semana.
    public List<FacturaPagableDTO> calcularCubiertasCompleto(BigDecimal montoDisponible, Long idReporteActual) {
        List<Object[]> disponibles = obtenerDisponibles(idReporteActual);
        List<Object[]> cubiertas = calcularCubiertas(disponibles, montoDisponible);

        List<FacturaPagableDTO> resultado = new ArrayList<>();
        for (Object[] fila : cubiertas) {
            resultado.add(new FacturaPagableDTO(
                    aLong(fila[ORDEN]),
                    (String) fila[PROVEEDOR],
                    (String) fila[DOCUMENTO],
                    aFecha(fila[FECHA_DOCUMENTO]),
                    aFecha(fila[FECHA_VENCIMIENTO]),
                    aBigDecimal(fila[IMPORTE_A_PAGAR])));
        }
        return resultado;
    }

    // Guarda en la copia local (tabla FC_EGR_CXP_PAGABLE) la lista de facturas
    // cubiertas — solo para PREVISUALIZAR/navegar en la pantalla (botón "Actualizar").
    // Esto NO compromete nada todavía: la reserva de verdad, permanente, solo pasa en
    // confirmarAsignacion, al Autorizar el reporte.
    @Transactional("secondTransactionManager")
    public void guardarPagables(BigDecimal montoDisponible, Long idReporteActual) {
        List<Object[]> disponibles = obtenerDisponibles(idReporteActual);
        List<Object[]> cubiertas = calcularCubiertas(disponibles, montoDisponible);

        pagableRepository.deleteAllInBatch();

        LocalDateTime ahora = LocalDateTime.now();
        List<EgresoCxpPagable> entidades = new ArrayList<>();
        for (Object[] fila : cubiertas) {
            EgresoCxpPagable e = new EgresoCxpPagable();
            e.setOrden(aLong(fila[ORDEN]));
            e.setFuente((String) fila[FUENTE]);
            e.setPriorizado((String) fila[PRIORIZADO]);
            e.setInvoiceId(aLong(fila[INVOICE_ID]));
            e.setProveedor((String) fila[PROVEEDOR]);
            e.setTipoDocumento((String) fila[TIPO_DOCUMENTO]);
            e.setDocumento((String) fila[DOCUMENTO]);
            e.setFechaDocumento(aFecha(fila[FECHA_DOCUMENTO]));
            e.setTerminoPago((String) fila[TERMINO_PAGO]);
            e.setGrupoPago((String) fila[GRUPO_PAGO]);
            e.setCategoria((String) fila[CATEGORIA]);
            e.setMetodoPago((String) fila[METODO_PAGO]);
            e.setFechaVencimiento(aFecha(fila[FECHA_VENCIMIENTO]));
            e.setImporteAPagar(aBigDecimal(fila[IMPORTE_A_PAGAR]));
            e.setDescripcion((String) fila[DESCRIPCION]);
            e.setFechaCarga(ahora);
            entidades.add(e);
        }
        pagableRepository.saveAll(entidades);
    }

    // Se llama SOLO desde FlujoCajaReporteService.marcarAutorizado, justo antes de
    // firmar Autorizado: calcula con el monto final de Ingresos qué facturas quedan
    // cubiertas. El resultado se reutiliza tanto para mandarlas al ERP
    // (enviarAsignacionErp) como para comprometerlas para siempre acá localmente
    // (confirmarAsignacion) — se calcula UNA sola vez para que ambos destinos
    // queden con exactamente la misma lista.
    public List<Object[]> calcularCubiertasParaAutorizar(Long idReporte, BigDecimal montoDisponible) {
        List<Object[]> disponibles = obtenerDisponibles(idReporte);
        return calcularCubiertas(disponibles, montoDisponible);
    }

    // Manda las facturas ya cubiertas (ver calcularCubiertasParaAutorizar) a los dos
    // "buzones" del ERP — tablas TMP que YA ESTÁN EN PRODUCCIÓN y son ajenas a este
    // sistema: un batch externo las lee para armar la orden de pago. PAM y PEC
    // viven en instancias Oracle DISTINTAS (ver PamDataSourceConfig vs
    // PrimaryDataSourceConfig), así que NO se pueden mandar en una sola transacción
    // — por eso son dos métodos separados en vez de uno solo, cada uno con su
    // propio @Transactional. A propósito FlujoCajaReporteService.marcarAutorizado
    // los llama DESPUÉS de firmar Autorizado (para que solo se manden con las 3
    // firmas ya puestas) pero ANTES de guardar nada localmente — si cualquiera de
    // los dos falla, el reporte no llega a quedar Autorizado ni las facturas
    // comprometidas localmente, para poder reintentar limpio. OJO: como son dos
    // bases físicamente distintas, no hay forma de revertir automáticamente la
    // OTRA si una ya se mandó bien y la siguiente falla (no hay transacción
    // distribuida entre ellas) — es una limitación de la infraestructura, no de
    // este código.

    // PAM => XX_PAM.PAM_ASIGNA_FACTURAS_TMP, con el offset de pruebas sumado al
    // INVOICE_ID (ver flujo-caja.offset-invoice-id-pam-pec).
    @Transactional("pamTransactionManager")
    public void enviarAsignacionPam(List<Object[]> cubiertas, LocalDate fechaInicio, LocalDate fechaFin) {
        String comentario = construirComentarioPeriodo(fechaInicio, fechaFin);
        String codigoBase = construirCodigoPeriodo(fechaInicio, fechaFin);

        for (Object[] fila : cubiertas) {
            String fuente = fila[FUENTE] != null ? ((String) fila[FUENTE]).toUpperCase() : "";
            if (fuente.contains("PAM")) {
                Long invoiceId = aLong(fila[INVOICE_ID]);
                pamAsignaRepository.insertar(invoiceId + offsetInvoiceIdPam, comentario, codigoBase + "-PAM");
            }
        }
    }

    // PEC => APPS.XXOCS_AP_ASIGNA_FACTURAS_TMP, con el INVOICE_ID real, SIN
    // offset — así lo pidió el negocio (a diferencia de PAM).
    @Transactional("primaryTransactionManager")
    public void enviarAsignacionPec(List<Object[]> cubiertas, LocalDate fechaInicio, LocalDate fechaFin) {
        String comentario = construirComentarioPeriodo(fechaInicio, fechaFin);
        String codigoBase = construirCodigoPeriodo(fechaInicio, fechaFin);

        for (Object[] fila : cubiertas) {
            String fuente = fila[FUENTE] != null ? ((String) fila[FUENTE]).toUpperCase() : "";
            if (fuente.contains("PEC")) {
                Long invoiceId = aLong(fila[INVOICE_ID]);
                xxocsApAsignaRepository.insertar(invoiceId, comentario, codigoBase + "-PEC");
            }
        }
    }

    // "31 DE AGOSTO AL 6 DE SEPTIEMBRE DE 2026"
    private String construirComentarioPeriodo(LocalDate fechaInicio, LocalDate fechaFin) {
        return fechaInicio.getDayOfMonth() + " DE " + MESES[fechaInicio.getMonthValue() - 1] +
                " AL " + fechaFin.getDayOfMonth() + " DE " + MESES[fechaFin.getMonthValue() - 1] +
                " DE " + fechaFin.getYear();
    }

    // "31AGO06SEP2026" (se le agrega "-PAM"/"-PEC" en enviarAsignacionErp)
    private String construirCodigoPeriodo(LocalDate fechaInicio, LocalDate fechaFin) {
        return String.format("%02d%s%02d%s%d",
                fechaInicio.getDayOfMonth(), MESES_ABREV[fechaInicio.getMonthValue() - 1],
                fechaFin.getDayOfMonth(), MESES_ABREV[fechaFin.getMonthValue() - 1],
                fechaFin.getYear());
    }

    // Se llama SOLO desde FlujoCajaReporteService.marcarAutorizado, con la MISMA
    // lista que ya devolvió calcularCubiertasParaAutorizar (y que ya se mandó al
    // ERP): graba PARA SIEMPRE qué facturas quedan comprometidas por este reporte,
    // para que ninguna semana futura vuelva a ofrecerlas.
    @Transactional("secondTransactionManager")
    public void confirmarAsignacion(Long idReporte, List<Object[]> cubiertas) {
        LocalDateTime ahora = LocalDateTime.now();
        List<FlujoCajaCxpAsignada> entidades = new ArrayList<>();
        for (Object[] fila : cubiertas) {
            FlujoCajaCxpAsignada a = new FlujoCajaCxpAsignada();
            a.setIdReporte(idReporte);
            a.setOrden(aLong(fila[ORDEN]));
            a.setFuente((String) fila[FUENTE]);
            a.setPriorizado((String) fila[PRIORIZADO]);
            a.setInvoiceId(aLong(fila[INVOICE_ID]));
            a.setProveedor((String) fila[PROVEEDOR]);
            a.setTipoDocumento((String) fila[TIPO_DOCUMENTO]);
            a.setDocumento((String) fila[DOCUMENTO]);
            a.setFechaDocumento(aFecha(fila[FECHA_DOCUMENTO]));
            a.setTerminoPago((String) fila[TERMINO_PAGO]);
            a.setGrupoPago((String) fila[GRUPO_PAGO]);
            a.setCategoria((String) fila[CATEGORIA]);
            a.setMetodoPago((String) fila[METODO_PAGO]);
            a.setFechaVencimiento(aFecha(fila[FECHA_VENCIMIENTO]));
            a.setImporteAPagar(aBigDecimal(fila[IMPORTE_A_PAGAR]));
            a.setDescripcion((String) fila[DESCRIPCION]);
            a.setFechaAsignacion(ahora);
            entidades.add(a);
        }
        asignadaRepository.saveAll(entidades);
    }

    // Secciones 3) Priorizado (Fondos Disponibles, PRIORIZADO='NO') y 4) Montos
    // Priorizados Pendientes de Ejecutar (PRIORIZADO='SI'): suma IMPORTE_A_PAGAR y
    // cuenta facturas de TODO lo disponible (obtenerDisponibles: la vista completa
    // del ERP, menos lo ya comprometido por OTRO reporte) — a propósito SIN el
    // recorte de "cuánto alcanza a pagar" (eso es una cosa aparte: la cobertura y
    // la lista de "Egresos — Cuentas por Pagar" de más abajo, que sí quedan
    // acotadas por Saldo Final). Agrupa por PRIORIZADO y, dentro de cada uno, por
    // FUENTE — "PAM" => Exploración y Producción, "PEC" => Gerencias Petroecuador.
    // Se resuelven los dos PRIORIZADO juntos en una sola pasada (y una sola llamada
    // a la vista del ERP) para no consultarla dos veces por cada carga de pantalla.
    public Map<String, Map<String, ResumenCxpFuenteDTO>> resumenPorFuenteSinFiltrar(Long idReporteActual) {
        Map<String, BigDecimal> valores = new HashMap<>();
        Map<String, Long> conteos = new HashMap<>();
        for (String p : new String[]{"SI", "NO"}) {
            for (String f : new String[]{"PAM", "PEC"}) {
                valores.put(p + "_" + f, BigDecimal.ZERO);
                conteos.put(p + "_" + f, 0L);
            }
        }

        for (Object[] fila : obtenerDisponibles(idReporteActual)) {
            String priorizado = (String) fila[PRIORIZADO];
            String fuente = fila[FUENTE] != null ? ((String) fila[FUENTE]).toUpperCase() : null;
            if (fuente == null) {
                continue;
            }
            String priorizadoClave = "SI".equalsIgnoreCase(priorizado) ? "SI" : "NO".equalsIgnoreCase(priorizado) ? "NO" : null;
            String fuenteClave = fuente.contains("PAM") ? "PAM" : fuente.contains("PEC") ? "PEC" : null;
            if (priorizadoClave == null || fuenteClave == null) {
                continue;
            }

            String clave = priorizadoClave + "_" + fuenteClave;
            BigDecimal importe = aBigDecimal(fila[IMPORTE_A_PAGAR]);
            valores.merge(clave, importe != null ? importe : BigDecimal.ZERO, BigDecimal::add);
            conteos.merge(clave, 1L, Long::sum);
        }

        Map<String, Map<String, ResumenCxpFuenteDTO>> resultado = new HashMap<>();
        for (String p : new String[]{"SI", "NO"}) {
            Map<String, ResumenCxpFuenteDTO> porFuente = new HashMap<>();
            for (String f : new String[]{"PAM", "PEC"}) {
                String clave = p + "_" + f;
                porFuente.put(f, new ResumenCxpFuenteDTO(valores.get(clave), conteos.get(clave)));
            }
            resultado.put(p, porFuente);
        }
        return resultado;
    }

    // Todas las facturas de la vista MENOS las que ya están comprometidas por otro
    // reporte, en el mismo orden de prioridad (ORDEN) que ya trae el ERP. Público
    // (además de usarse acá adentro) para el Excel "todas las facturas" del
    // controlador — a diferencia de calcularCubiertas, esta lista NO se corta por
    // cuánto alcanza a pagar con los Ingresos.
    public List<Object[]> obtenerDisponibles(Long idReporteActual) {
        List<Long> excluidos = idReporteActual == null
                ? asignadaRepository.obtenerTodosLosInvoiceIds()
                : asignadaRepository.obtenerInvoiceIdsDeOtrosReportes(idReporteActual);
        Set<Long> excluidosSet = new HashSet<>(excluidos);

        List<Object[]> todas = egresoCxpService.obtenerTodasLasFacturas();
        List<Object[]> disponibles = new ArrayList<>();
        for (Object[] fila : todas) {
            if (!excluidosSet.contains(aLong(fila[INVOICE_ID]))) {
                disponibles.add(fila);
            }
        }
        return disponibles;
    }

    // Va acumulando IMPORTE_A_PAGAR en orden hasta quedarse sin monto — la última
    // que entra completa es el corte.
    private List<Object[]> calcularCubiertas(List<Object[]> disponibles, BigDecimal montoDisponible) {
        List<Object[]> cubiertas = new ArrayList<>();
        if (montoDisponible == null || montoDisponible.compareTo(BigDecimal.ZERO) <= 0) {
            return cubiertas;
        }

        BigDecimal acumulado = BigDecimal.ZERO;
        for (Object[] fila : disponibles) {
            BigDecimal importe = aBigDecimal(fila[IMPORTE_A_PAGAR]);
            BigDecimal nuevoAcumulado = acumulado.add(importe != null ? importe : BigDecimal.ZERO);
            if (nuevoAcumulado.compareTo(montoDisponible) > 0) {
                break;
            }
            acumulado = nuevoAcumulado;
            cubiertas.add(fila);
        }
        return cubiertas;
    }

    private CoberturaCxpDTO construirDTO(List<Object[]> cubiertas, long totalDisponibles) {
        if (cubiertas.isEmpty()) {
            return new CoberturaCxpDTO(0, totalDisponibles, null, null, null, BigDecimal.ZERO);
        }

        Object[] ultima = cubiertas.get(cubiertas.size() - 1);
        BigDecimal totalCubierto = BigDecimal.ZERO;
        for (Object[] fila : cubiertas) {
            BigDecimal importe = aBigDecimal(fila[IMPORTE_A_PAGAR]);
            if (importe != null) {
                totalCubierto = totalCubierto.add(importe);
            }
        }

        return new CoberturaCxpDTO(cubiertas.size(), totalDisponibles,
                (String) ultima[PROVEEDOR], (String) ultima[DOCUMENTO], (String) ultima[FECHA_VENCIMIENTO],
                totalCubierto);
    }

    private Long aLong(Object valor) {
        return valor == null ? null : ((Number) valor).longValue();
    }

    private LocalDate aFecha(Object valor) {
        return valor == null ? null : LocalDate.parse((String) valor);
    }

    private BigDecimal aBigDecimal(Object valor) {
        if (valor == null) {
            return null;
        }
        return valor instanceof BigDecimal ? (BigDecimal) valor : new BigDecimal(valor.toString());
    }
}
