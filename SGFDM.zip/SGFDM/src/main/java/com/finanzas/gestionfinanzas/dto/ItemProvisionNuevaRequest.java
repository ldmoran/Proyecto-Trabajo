package com.finanzas.gestionfinanzas.dto;

import java.math.BigDecimal;

// Una fila (Concepto + Valor) de un lote de Provisión Nueva. Varias de estas
// viajan juntas como JSON dentro de un campo del multipart de POST
// /provisiones/nuevo (ver ProvisionesController.crearNuevo), porque el resto
// del formulario (fechas, PDF) es compartido por todo el lote.
public class ItemProvisionNuevaRequest {

    private Long idConcepto;
    private BigDecimal valor;

    public Long getIdConcepto() { return idConcepto; }
    public void setIdConcepto(Long idConcepto) { this.idConcepto = idConcepto; }

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
}
