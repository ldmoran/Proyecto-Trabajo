package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "FC_ING_CONCEPTO")
public class ConceptoIngreso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CONCEPTO")
    private Long idConcepto;

    @Column(name = "NOMBRE_CONCEPTO")
    private String nombreConcepto;

    // Null para los conceptos manuales; solo se completa en los 3
    // conceptos "Automático" que se calculan solos por cuenta contable.
    @ManyToOne
    @JoinColumn(name = "ID_CUENTA")
    private Cuenta cuenta;

    @Column(name = "ESTADO")
    private String estado;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdConcepto() { return idConcepto; }
    public void setIdConcepto(Long idConcepto) { this.idConcepto = idConcepto; }

    public String getNombreConcepto() { return nombreConcepto; }
    public void setNombreConcepto(String nombreConcepto) { this.nombreConcepto = nombreConcepto; }

    public Cuenta getCuenta() { return cuenta; }
    public void setCuenta(Cuenta cuenta) { this.cuenta = cuenta; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    // Conveniencia: true si este concepto se calcula solo (no se teclea a mano)
    public boolean isAutomatico() {
        return cuenta != null;
    }
}