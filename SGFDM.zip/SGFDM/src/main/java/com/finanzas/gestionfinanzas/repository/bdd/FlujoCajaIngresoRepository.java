package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaIngreso;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FlujoCajaIngresoRepository extends JpaRepository<FlujoCajaIngreso, Long> {
    List<FlujoCajaIngreso> findByReporte_IdReporte(Long idReporte);
}