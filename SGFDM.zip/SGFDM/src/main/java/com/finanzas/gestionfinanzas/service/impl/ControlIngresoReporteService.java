package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.ColumnaCostoDTO;
import com.finanzas.gestionfinanzas.dto.ControlIngresoFilaDTO;
import com.finanzas.gestionfinanzas.dto.ControlIngresoReporteDTO;
import com.finanzas.gestionfinanzas.entity.CostoFactura;
import com.finanzas.gestionfinanzas.entity.DetalleDistribucion;
import com.finanzas.gestionfinanzas.entity.DistribucionHija;
import com.finanzas.gestionfinanzas.entity.DistribucionPadre;
import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import com.finanzas.gestionfinanzas.entity.TipoCosto;
import com.finanzas.gestionfinanzas.repository.bdd.CostoFacturaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Arma el reporte de Control de Ingresos a partir de COSTOS_FACTURA, que es el
// respaldo ya congelado al Aprobar cada factura (volumen, valor unitario y total
// de cada costo). Una fila del reporte = una distribución de una factura, con sus
// costos repartidos en columnas.
@Service
public class ControlIngresoReporteService {

    private final CostoFacturaRepository costoFacturaRepository;

    public ControlIngresoReporteService(CostoFacturaRepository costoFacturaRepository) {
        this.costoFacturaRepository = costoFacturaRepository;
    }

    @Transactional("secondTransactionManager")
    public ControlIngresoReporteDTO generar(String desde, String hasta) {
        LocalDate fechaDesde = parsearIso(desde);
        LocalDate fechaHasta = parsearIso(hasta);

        // Se agrupa por (factura, distribución): cada grupo es una fila del reporte
        // y sus costos se van sumando en la columna que les corresponde.
        Map<String, ControlIngresoFilaDTO> filasPorClave = new LinkedHashMap<>();
        Map<String, ColumnaCostoDTO> columnasPorClave = new LinkedHashMap<>();

        for (CostoFactura cf : costoFacturaRepository.findTodoParaControlIngresos()) {
            FacturasBDD factura = cf.getFactura();
            DetalleDistribucion detalle = cf.getDetalleDistribucion();
            if (factura == null || detalle == null || cf.getTipoCosto() == null) {
                continue;
            }

            if (!dentroDelRango(cf.getFechaCreacion(), fechaDesde, fechaHasta)) {
                continue;
            }

            String clave = factura.getIdFactura() + "-" + detalle.getIdDetalle();
            ControlIngresoFilaDTO fila = filasPorClave.get(clave);
            if (fila == null) {
                fila = new ControlIngresoFilaDTO(
                        factura.getNumFactura(),
                        factura.getFecEmbarque(),
                        factura.getFecDeposito(),
                        factura.getCompania(),
                        factura.getContrato(),
                        factura.getBuque(),
                        nombreProducto(detalle),
                        nombreDistribucion(detalle),
                        detalle.getVolumen(),
                        factura.getPrecio(),
                        factura.getExcluidaEbs());
                filasPorClave.put(clave, fila);
            }

            ColumnaCostoDTO columna = columnaDe(cf.getTipoCosto());
            columnasPorClave.putIfAbsent(columna.getClave(), columna);
            fila.sumarCosto(columna.getClave(), cf.getTotal());
        }

        // Ordenadas por entidad y luego por nombre, para que la cabecera quede
        // agrupada ("COSTOS PETROECUADOR" primero, "COSTOS MINISTERIO" después).
        List<ColumnaCostoDTO> columnas = new ArrayList<>(columnasPorClave.values());
        columnas.sort(Comparator.comparing(ColumnaCostoDTO::getEntidad)
                .thenComparing(ColumnaCostoDTO::getNombreCosto));

        return new ControlIngresoReporteDTO(
                new ArrayList<>(filasPorClave.values()),
                columnas,
                desde, hasta);
    }

    // El mismo nombre de costo existe para Petroecuador y para Ministerio, así que
    // cada uno va en su propia columna; la cuenta contable viene del tipo de costo.
    private ColumnaCostoDTO columnaDe(TipoCosto tipoCosto) {
        String entidad = tipoCosto.getCrudoEntidad() != null
                ? tipoCosto.getCrudoEntidad().getNombreGrupo()
                : "SIN ENTIDAD";
        String cuenta = tipoCosto.getCuenta() != null
                ? tipoCosto.getCuenta().getNumeroCuenta()
                : "Sin cuenta";

        return new ColumnaCostoDTO(tipoCosto.getNombreCosto(), entidad, cuenta);
    }

    private String nombreProducto(DetalleDistribucion detalle) {
        DistribucionHija hija = detalle.getDistribucionHija();
        DistribucionPadre padre = hija != null ? hija.getDistribucionPadre() : null;
        if (padre != null && padre.getCrudo() != null) {
            return padre.getCrudo().getNombreCrudo();
        }
        return "-";
    }

    private String nombreDistribucion(DetalleDistribucion detalle) {
        DistribucionHija hija = detalle.getDistribucionHija();
        return hija != null ? hija.getNombreCompleto() : "-";
    }

    // El rango se aplica sobre la fecha en que se aprobó la factura (la que quedó
    // grabada en COSTOS_FACTURA), no sobre FEC_EMBARQUE/FEC_DEPOSITO: esas dos
    // vienen del ERP como texto libre y con formatos mezclados, así que filtrar
    // por ellas dejaba el reporte vacío aunque sí hubiera facturas en el rango.
    private boolean dentroDelRango(LocalDateTime fecha, LocalDate desde, LocalDate hasta) {
        if (desde == null && hasta == null) {
            return true;
        }
        if (fecha == null) {
            return false;
        }

        LocalDate dia = fecha.toLocalDate();
        if (desde != null && dia.isBefore(desde)) {
            return false;
        }
        return hasta == null || !dia.isAfter(hasta);
    }

    private LocalDate parsearIso(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return null;
        }
        try {
            return LocalDate.parse(texto.trim());
        } catch (Exception e) {
            return null;
        }
    }
}
