package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

// Una Gerencia puede tener varias Áreas. Las gerencias que en la práctica no
// se dividen en áreas reales (Comercialización Nacional, Exploración y
// Producción, Refinación, Transporte) tienen una única Área con el mismo
// nombre de la Gerencia — ver el catálogo real cargado en reset_bd.sql.
@Entity
@Table(name = "PROVISION_AREA")
public class ProvisionArea {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_AREA")
    private Long idArea;

    @ManyToOne
    @JoinColumn(name = "ID_GERENCIA")
    private ProvisionGerencia gerencia;

    @Column(name = "NOMBRE_AREA")
    private String nombreArea;

    @Column(name = "ESTADO")
    private String estado;

    public Long getIdArea() { return idArea; }
    public void setIdArea(Long idArea) { this.idArea = idArea; }

    public ProvisionGerencia getGerencia() { return gerencia; }
    public void setGerencia(ProvisionGerencia gerencia) { this.gerencia = gerencia; }

    public String getNombreArea() { return nombreArea; }
    public void setNombreArea(String nombreArea) { this.nombreArea = nombreArea; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
