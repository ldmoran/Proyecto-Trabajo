package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

// Registro (append-only) de cada firma electrónica con .p12 sobre un reporte:
// una fila por etapa (ELABORADO/APROBADO/AUTORIZADO) firmada. El nombre del
// firmante sale del certificado, no de la sesión, porque eso es justamente lo
// que hace que sea una firma y no solo un botón — lo garantiza el .p12, no el
// login de la app.
@Entity
@Table(name = "FC_FIRMA")
public class FlujoCajaFirma {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_FIRMA")
    private Long idFirma;

    @ManyToOne
    @JoinColumn(name = "ID_REPORTE")
    private FlujoCajaReporte reporte;

    @Column(name = "ETAPA")
    private String etapa;

    @Column(name = "NOMBRE_FIRMANTE")
    private String nombreFirmante;

    @Column(name = "FECHA_FIRMA")
    private LocalDateTime fechaFirma;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    public Long getIdFirma() {
        return idFirma;
    }

    public void setIdFirma(Long idFirma) {
        this.idFirma = idFirma;
    }

    public FlujoCajaReporte getReporte() {
        return reporte;
    }

    public void setReporte(FlujoCajaReporte reporte) {
        this.reporte = reporte;
    }

    public String getEtapa() {
        return etapa;
    }

    public void setEtapa(String etapa) {
        this.etapa = etapa;
    }

    public String getNombreFirmante() {
        return nombreFirmante;
    }

    public void setNombreFirmante(String nombreFirmante) {
        this.nombreFirmante = nombreFirmante;
    }

    public LocalDateTime getFechaFirma() {
        return fechaFirma;
    }

    public void setFechaFirma(LocalDateTime fechaFirma) {
        this.fechaFirma = fechaFirma;
    }

    public String getIdUsuarioCreacion() {
        return idUsuarioCreacion;
    }

    public void setIdUsuarioCreacion(String idUsuarioCreacion) {
        this.idUsuarioCreacion = idUsuarioCreacion;
    }
}
