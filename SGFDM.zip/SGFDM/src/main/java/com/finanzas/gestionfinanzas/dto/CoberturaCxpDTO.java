package com.finanzas.gestionfinanzas.dto;

import java.math.BigDecimal;

// Resultado de "con este monto disponible, hasta qué factura de Cuentas por Pagar
// (ordenadas por la columna ORDEN de la vista) se alcanza a pagar completa".
public class CoberturaCxpDTO {

    private final long facturasCubiertas;
    private final long facturasTotal;
    private final String proveedorCorte;
    private final String documentoCorte;
    private final String fechaVencimientoCorte;
    private final BigDecimal totalCubierto;

    public CoberturaCxpDTO(long facturasCubiertas, long facturasTotal, String proveedorCorte,
                            String documentoCorte, String fechaVencimientoCorte, BigDecimal totalCubierto) {
        this.facturasCubiertas = facturasCubiertas;
        this.facturasTotal = facturasTotal;
        this.proveedorCorte = proveedorCorte;
        this.documentoCorte = documentoCorte;
        this.fechaVencimientoCorte = fechaVencimientoCorte;
        this.totalCubierto = totalCubierto;
    }

    public long getFacturasCubiertas() {
        return facturasCubiertas;
    }

    public long getFacturasTotal() {
        return facturasTotal;
    }

    public String getProveedorCorte() {
        return proveedorCorte;
    }

    public String getDocumentoCorte() {
        return documentoCorte;
    }

    public String getFechaVencimientoCorte() {
        return fechaVencimientoCorte;
    }

    public BigDecimal getTotalCubierto() {
        return totalCubierto;
    }
}
