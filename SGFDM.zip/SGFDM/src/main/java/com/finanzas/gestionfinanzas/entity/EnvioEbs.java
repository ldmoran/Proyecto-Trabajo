package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "ENVIO_EBS")
public class EnvioEbs {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_ENVIO_EBS")
    private Long idEnvioEbs;

    @Column(name = "FECHA_ENVIO")
    private LocalDateTime fechaEnvio;

    // Lunes de la semana a la que la persona decidió atribuir este envío (elegido
    // a mano en Ingresos > Enviar a Flujo) — no siempre coincide con FECHA_ENVIO,
    // ver el comentario de la tabla en reset_bd.sql.
    @Column(name = "FECHA_PERIODO")
    private LocalDate fechaPeriodo;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "TOTAL_GENERAL")
    private Double totalGeneral;

    public Long getIdEnvioEbs() {
        return idEnvioEbs;
    }

    public void setIdEnvioEbs(Long idEnvioEbs) {
        this.idEnvioEbs = idEnvioEbs;
    }

    public LocalDateTime getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(LocalDateTime fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public LocalDate getFechaPeriodo() {
        return fechaPeriodo;
    }

    public void setFechaPeriodo(LocalDate fechaPeriodo) {
        this.fechaPeriodo = fechaPeriodo;
    }

    public String getIdUsuarioCreacion() {
        return idUsuarioCreacion;
    }

    public void setIdUsuarioCreacion(String idUsuarioCreacion) {
        this.idUsuarioCreacion = idUsuarioCreacion;
    }

    public Double getTotalGeneral() {
        return totalGeneral;
    }

    public void setTotalGeneral(Double totalGeneral) {
        this.totalGeneral = totalGeneral;
    }
}
