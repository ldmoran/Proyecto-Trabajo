package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.dto.ConceptoConPagosRequest;
import com.finanzas.gestionfinanzas.dto.ItemProvisionNuevaRequest;
import com.finanzas.gestionfinanzas.dto.ProvisionAnteriorLoteRequest;
import com.finanzas.gestionfinanzas.entity.Archivo;
import com.finanzas.gestionfinanzas.entity.FlujoCajaReporte;
import com.finanzas.gestionfinanzas.entity.ProvisionConcepto;
import com.finanzas.gestionfinanzas.entity.ProvisionPagoSeleccionado;
import com.finanzas.gestionfinanzas.entity.ProvisionRegistro;
import com.finanzas.gestionfinanzas.repository.bdd.ArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaReporteRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionConceptoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionPagoSeleccionadoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionRegistroRepository;
import com.finanzas.gestionfinanzas.service.impl.ProvisionRegistroService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

// Provisiones: apartado propio en el menú, todavía en definición (a
// diferencia de Egresos, del que se pensó que era un duplicado al
// principio). Flujo: elegir Concepto de Provisión (trae Gerencia/Área/Zona
// solas), elegir Período (mismas semanas que ya existen en Ingresos/Egresos)
// y marcar el tipo de ciclo Nuevo/Anterior/Mixto (ver PROVISION_REGISTRO en
// reset_bd.sql y ProvisionRegistroService para el detalle de negocio).
@Controller
@RequestMapping("/provisiones")
public class ProvisionesController {

    private static final Logger log = LoggerFactory.getLogger(ProvisionesController.class);

    private final ProvisionConceptoRepository conceptoRepository;
    private final FlujoCajaReporteRepository reporteRepository;
    private final ProvisionRegistroRepository registroRepository;
    private final ArchivoRepository archivoRepository;
    private final ProvisionRegistroService provisionRegistroService;
    private final ObjectMapper objectMapper;
    private final ProvisionPagoSeleccionadoRepository pagoSeleccionadoRepository;

    public ProvisionesController(ProvisionConceptoRepository conceptoRepository,
                                  FlujoCajaReporteRepository reporteRepository,
                                  ProvisionRegistroRepository registroRepository,
                                  ArchivoRepository archivoRepository,
                                  ProvisionRegistroService provisionRegistroService,
                                  ObjectMapper objectMapper,
                                  ProvisionPagoSeleccionadoRepository pagoSeleccionadoRepository) {
        this.conceptoRepository = conceptoRepository;
        this.reporteRepository = reporteRepository;
        this.registroRepository = registroRepository;
        this.archivoRepository = archivoRepository;
        this.provisionRegistroService = provisionRegistroService;
        this.objectMapper = objectMapper;
        this.pagoSeleccionadoRepository = pagoSeleccionadoRepository;
    }

    @GetMapping
    public String verProvisiones(HttpServletRequest request, Model model) {
        model.addAttribute("path", request.getRequestURI());

        List<ProvisionConcepto> conceptos = conceptoRepository.findByEstadoOrderByNombreConcepto("A");
        model.addAttribute("conceptos", conceptos);

        // Se manda armado como JSON para que el JS complete Gerencia/Área/Zona
        // al elegir el concepto sin ir de nuevo al servidor — mismo patrón que
        // conceptosManualJson en Flujo de Caja > Ingresos.
        List<Map<String, Object>> conceptosJson = new ArrayList<>();
        for (ProvisionConcepto c : conceptos) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", c.getIdConcepto());
            item.put("nombre", c.getNombreConcepto());
            item.put("zona", c.getZona());
            item.put("area", c.getArea() != null ? c.getArea().getNombreArea() : "");
            item.put("gerencia", c.getArea() != null && c.getArea().getGerencia() != null
                    ? c.getArea().getGerencia().getNombreGerencia() : "");
            conceptosJson.add(item);
        }
        model.addAttribute("conceptosJson", conceptosJson);

        // Los períodos de Provisiones deben ser los MISMOS que ya existen en
        // Ingresos/Egresos — alcanza con que exista el reporte (se crea
        // apenas se guarda Ingresos), no se exige que Egresos también esté
        // guardado. Si un mes tiene 2 semanas con Ingresos guardado, acá
        // solo van a aparecer esas 2; si no tiene ninguna, no aparece nada.
        List<String> periodosJson = new ArrayList<>();
        for (java.sql.Timestamp fechaInicio : reporteRepository.listarFechasInicio()) {
            periodosJson.add(fechaInicio.toLocalDateTime().toLocalDate().toString());
        }
        model.addAttribute("periodosJson", periodosJson);

        // Pagos a proveedores desde la vista real del ERP
        // (APPS.XXOCS_AP_CXP_PAGOS_PROV_V), para elegir en Anterior/Mixto.
        List<Map<String, Object>> pagosProveedorJson = new ArrayList<>();
        for (Object[] fila : provisionRegistroService.listarPagosProveedor()) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("vendorName", fila[0]);
            item.put("ruc", fila[1]);
            item.put("documento", fila[2]);
            item.put("monto", fila[3]);
            item.put("descripcion", fila[4]);
            item.put("fechaPago", fila[5]);
            pagosProveedorJson.add(item);
        }
        model.addAttribute("pagosProveedorJson", pagosProveedorJson);

        // Provisiones "Nueva" que siguen ABIERTAS (pendientes de cerrar con un
        // Pendiente/Mixto) — se muestran arriba del panel "Provisión Pendiente"
        // para elegir de una lista en vez de ir a ciegas por la cascada. Si el
        // mismo concepto tiene más de un Nuevo abierto (no debería pasar en un
        // flujo normal, pero el modelo no lo impide), se muestra solo el más
        // reciente — es el mismo que usa obtenerNuevoAbierto() al guardar.
        List<ProvisionRegistro> nuevosAbiertos =
                registroRepository.findByTipoAndEstadoOrderByFechaCreacionDesc(ProvisionRegistro.TIPO_NUEVO, "ABIERTO");
        List<Map<String, Object>> nuevosAbiertosJson = new ArrayList<>();
        Set<Long> conceptosYaListados = new HashSet<>();
        for (ProvisionRegistro r : nuevosAbiertos) {
            Long idConcepto = r.getConcepto().getIdConcepto();
            if (!conceptosYaListados.add(idConcepto)) {
                continue;
            }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("idConcepto", idConcepto);
            item.put("nombreConcepto", r.getConcepto().getNombreConcepto());
            item.put("zona", r.getConcepto().getZona());
            item.put("area", r.getConcepto().getArea() != null ? r.getConcepto().getArea().getNombreArea() : "");
            item.put("gerencia", r.getConcepto().getArea() != null && r.getConcepto().getArea().getGerencia() != null
                    ? r.getConcepto().getArea().getGerencia().getNombreGerencia() : "");
            item.put("valorNuevo", r.getValorNuevo());
            item.put("valorPendiente", provisionRegistroService.obtenerValorACubrir(idConcepto));
            nuevosAbiertosJson.add(item);
        }
        model.addAttribute("nuevosAbiertosJson", nuevosAbiertosJson);

        return "provisiones";
    }

    // "Consultar Provisiones": histórico de todos los registros guardados
    // (Nuevo/Anterior/Mixto), filtrable por año/mes del período de inicio.
    @GetMapping("/consultar")
    public String consultar(@RequestParam(defaultValue = "0") int page,
                             @RequestParam(required = false) Integer anio,
                             @RequestParam(required = false) Integer mes,
                             HttpServletRequest request, Model model) {
        Page<ProvisionRegistro> registrosPage = registroRepository.buscar(anio, mes, PageRequest.of(page, 10));

        // El PDF siempre se sube al crear un lote NUEVO (ver
        // ProvisionRegistroService.crearNuevoLote) — un solo PDF cubre todos
        // los conceptos de ese lote. Un registro ANTERIOR/MIXTO no tiene PDF
        // propio: el suyo es el del lote de su Nuevo de origen (que ya no se
        // lista aparte una vez CERRADO), así que acá se resuelve qué ID de
        // LOTE hay que usar para el link de descarga en cada fila.
        Map<Long, Long> idLotePdfPorRegistro = new HashMap<>();
        for (ProvisionRegistro r : registrosPage.getContent()) {
            Long idLoteConPdf = "NUEVO".equals(r.getTipo())
                    ? (r.getLote() != null ? r.getLote().getIdLote() : null)
                    : (r.getRegistroOrigen() != null && r.getRegistroOrigen().getLote() != null
                        ? r.getRegistroOrigen().getLote().getIdLote() : null);
            boolean tienePdf = idLoteConPdf != null
                    && archivoRepository.findByProvisionLote_IdLoteAndEstado(idLoteConPdf, "A").isPresent();
            idLotePdfPorRegistro.put(r.getIdRegistro(), tienePdf ? idLoteConPdf : null);
        }

        // Para que la pantalla pueda agrupar visualmente las filas que se
        // guardaron juntas en un mismo lote (varios conceptos, un solo clic
        // de "Guardar"): "inicio"/"medio"/"fin" según si la fila de
        // arriba/abajo (en el orden ya ordenado por el repositorio) comparte
        // el mismo ID_LOTE. Las filas ANTERIOR (sin lote) quedan "" (sueltas).
        Map<Long, String> posicionEnLote = new HashMap<>();
        List<ProvisionRegistro> contenido = registrosPage.getContent();
        for (int i = 0; i < contenido.size(); i++) {
            ProvisionRegistro actual = contenido.get(i);
            Long idLoteActual = actual.getLote() != null ? actual.getLote().getIdLote() : null;
            if (idLoteActual == null) {
                posicionEnLote.put(actual.getIdRegistro(), "");
                continue;
            }
            boolean coincideConAnterior = i > 0 && contenido.get(i - 1).getLote() != null
                    && idLoteActual.equals(contenido.get(i - 1).getLote().getIdLote());
            boolean coincideConSiguiente = i < contenido.size() - 1 && contenido.get(i + 1).getLote() != null
                    && idLoteActual.equals(contenido.get(i + 1).getLote().getIdLote());
            String posicion;
            if (!coincideConAnterior && !coincideConSiguiente) {
                posicion = ""; // lote de un solo concepto: se ve igual que uno suelto
            } else if (!coincideConAnterior) {
                posicion = "inicio";
            } else if (!coincideConSiguiente) {
                posicion = "fin";
            } else {
                posicion = "medio";
            }
            posicionEnLote.put(actual.getIdRegistro(), posicion);
        }

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("registrosPage", registrosPage);
        model.addAttribute("anio", anio);
        model.addAttribute("mes", mes);
        model.addAttribute("idLotePdfPorRegistro", idLotePdfPorRegistro);
        model.addAttribute("posicionEnLote", posicionEnLote);
        return "provisiones-consultar";
    }

    // Descarga el PDF de respaldo de un LOTE (ver
    // ProvisionRegistroService.crearNuevoLote / TipoArchivo.COMPROBANTE_PROVISION).
    // Un solo PDF cubre todos los conceptos que se guardaron juntos en ese lote.
    @GetMapping("/lote/{idLote}/pdf")
    public void descargarPdf(@PathVariable Long idLote, HttpServletResponse response) throws IOException {
        Archivo archivo = archivoRepository.findByProvisionLote_IdLoteAndEstado(idLote, "A").orElse(null);
        if (archivo == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Este lote no tiene PDF adjunto");
            return;
        }
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "inline; filename=" + archivo.getNombreArchivo());
        response.getOutputStream().write(archivo.getContenido());
    }

    // NUEVO: uno o varios Conceptos con su propio valor cada uno, guardados
    // juntos como un lote con un solo PDF de respaldo. "items" viaja como
    // texto JSON dentro del multipart (no como campos indexados) para no
    // andar armando listas paralelas a mano en el navegador — el resto del
    // formulario (fechas, PDF) es compartido por todo el lote.
    @PostMapping(value = "/nuevo", consumes = "multipart/form-data")
    @ResponseBody
    public ResponseEntity<?> crearNuevo(@RequestParam String fechaInicioPeriodo,
                                         @RequestParam String fechaFinPeriodo,
                                         @RequestParam String items,
                                         @RequestParam("pdf") MultipartFile pdf) {
        try {
            List<ItemProvisionNuevaRequest> itemsRequest = objectMapper.readValue(items,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, ItemProvisionNuevaRequest.class));
            List<ProvisionRegistro> registros = provisionRegistroService.crearNuevoLote(
                    LocalDate.parse(fechaInicioPeriodo), LocalDate.parse(fechaFinPeriodo), itemsRequest, pdf);
            return ResponseEntity.ok(respuestaRegistros(registros));
        } catch (Exception e) {
            log.error("Error al crear lote Nuevo de Provisiones", e);
            return ResponseEntity.badRequest().body(respuestaError(e));
        }
    }

    // Lo que ya se guardó (Nuevo/Pendiente/Mixto) para un período puntual —
    // se consulta apenas se elige la Semana en pantalla, para mostrar el
    // historial de ese período en vez de un formulario vacío como si nunca
    // se hubiera guardado nada ahí. "editable" sale de la MISMA regla que ya
    // usa Flujo de Caja (ver FlujoCajaReporteService.verificarDatosNoBloqueados):
    // no Autorizado, no Elaborado, no Aprobado — Provisiones comparte semana
    // con Ingresos/Egresos, así que comparte también su candado de edición.
    @GetMapping("/historial-periodo")
    @ResponseBody
    public ResponseEntity<?> obtenerHistorialPeriodo(@RequestParam String fechaInicio) {
        try {
            LocalDate fecha = LocalDate.parse(fechaInicio);
            // Se busca el reporte UNA vez y se usa tanto para "editable" como para
            // traer los registros por ID_REPORTE (relación real, ver
            // ProvisionRegistro.reporte) en vez de matchear la fecha a mano.
            Optional<FlujoCajaReporte> reporteOpt = reporteRepository.findByFechaInicio(fecha);

            List<ProvisionRegistro> registros = reporteOpt
                    .map(r -> registroRepository.findByReporte_IdReporteOrderByFechaCreacionDesc(r.getIdReporte()))
                    .orElse(new ArrayList<>());

            boolean editable = reporteOpt
                    .map(reporte -> !"A".equals(reporte.getEstado())
                            && (reporte.getElaboradoPor() == null || reporte.getElaboradoPor().trim().isEmpty())
                            && !"APROBADO".equals(reporte.getEstadoProceso()))
                    .orElse(true); // Sin reporte de Flujo de Caja todavía para esta semana: nada que bloquee.

            List<Map<String, Object>> registrosJson = new ArrayList<>();
            for (ProvisionRegistro r : registros) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("tipo", r.getTipo());
                // idConcepto/gerencia/area/zona: "Servicios Básicos" (y varios otros
                // nombres) se repite como concepto DISTINTO en más de una Gerencia/Área
                // (ver PROVISION_CONCEPTO en reset_bd.sql) — sin esto, la pantalla no
                // puede distinguir ni agrupar bien entre dos provisiones que comparten
                // nombre pero son presupuestos distintos.
                item.put("idConcepto", r.getConcepto() != null ? r.getConcepto().getIdConcepto() : null);
                item.put("nombreConcepto", r.getConcepto() != null ? r.getConcepto().getNombreConcepto() : null);
                item.put("gerencia", r.getConcepto() != null && r.getConcepto().getArea() != null && r.getConcepto().getArea().getGerencia() != null
                        ? r.getConcepto().getArea().getGerencia().getNombreGerencia() : null);
                item.put("area", r.getConcepto() != null && r.getConcepto().getArea() != null
                        ? r.getConcepto().getArea().getNombreArea() : null);
                item.put("zona", r.getConcepto() != null ? r.getConcepto().getZona() : null);
                item.put("valorNuevo", r.getValorNuevo());
                item.put("valorFacturas", r.getValorFacturas());
                item.put("valorPendiente", r.getValorPendiente());
                item.put("fechaCreacion", r.getFechaCreacion() != null ? r.getFechaCreacion().toString() : null);

                // Facturas pagadas con esta ronda (solo aplica a Pendiente/Mixto,
                // un Nuevo no tiene pagos todavía) — para mostrarlas en pantalla
                // con el mismo detalle que ya usa "Información Consorcios".
                List<Map<String, Object>> pagosJson = new ArrayList<>();
                for (ProvisionPagoSeleccionado pago : pagoSeleccionadoRepository.findByRegistro_IdRegistro(r.getIdRegistro())) {
                    Map<String, Object> pagoItem = new LinkedHashMap<>();
                    pagoItem.put("vendorName", pago.getVendorName());
                    pagoItem.put("ruc", pago.getRuc());
                    pagoItem.put("documento", pago.getDocumento());
                    pagoItem.put("descripcion", pago.getDescripcion());
                    pagoItem.put("montoPagado", pago.getMontoPagado());
                    pagoItem.put("fechaPago", pago.getFechaPago() != null ? pago.getFechaPago().toString() : null);
                    pagosJson.add(pagoItem);
                }
                item.put("pagos", pagosJson);

                registrosJson.add(item);
            }

            Map<String, Object> respuesta = new LinkedHashMap<>();
            respuesta.put("editable", editable);
            respuesta.put("registros", registrosJson);
            return ResponseEntity.ok(respuesta);
        } catch (Exception e) {
            log.error("Error al obtener el historial de Provisiones del período", e);
            return ResponseEntity.badRequest().body(respuestaError(e));
        }
    }

    // Cuánto queda por cubrir del Nuevo abierto de un concepto — se consulta
    // apenas se elige el Concepto en los paneles Pendiente/Mixto, para que
    // el usuario sepa contra qué monto se van a validar las facturas.
    @GetMapping("/valor-cobertura")
    @ResponseBody
    public ResponseEntity<?> obtenerValorCobertura(@RequestParam Long idConcepto) {
        try {
            BigDecimal valor = provisionRegistroService.obtenerValorACubrir(idConcepto);
            Map<String, Object> respuesta = new LinkedHashMap<>();
            respuesta.put("valor", valor);
            return ResponseEntity.ok(respuesta);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(respuestaError(e));
        }
    }

    // PENDIENTE (tipo ANTERIOR): uno o varios Conceptos a la vez, cada uno con
    // sus propios pagos elegidos, guardados juntos como un lote — mismo
    // patrón que /provisiones/nuevo, para no repetir la pantalla una vez por
    // concepto (ver ProvisionRegistroService.crearAnteriorLote).
    @PostMapping(value = "/anterior-lote", consumes = "application/json")
    @ResponseBody
    public ResponseEntity<?> crearAnteriorLote(@RequestBody ProvisionAnteriorLoteRequest request) {
        try {
            List<ProvisionRegistro> registros = provisionRegistroService.crearAnteriorLote(
                    LocalDate.parse(request.getFechaInicioPeriodo()), LocalDate.parse(request.getFechaFinPeriodo()),
                    request.getConceptos());
            return ResponseEntity.ok(respuestaRegistros(registros));
        } catch (Exception e) {
            log.error("Error al crear lote Pendiente de Provisiones", e);
            return ResponseEntity.badRequest().body(respuestaError(e));
        }
    }

    // MIXTO: en un mismo guardado, uno o varios Conceptos que se cierran con
    // sus facturas ("cierres", puede venir vacío) Y uno o varios Conceptos
    // NUEVO con su propio valor ("nuevos", siempre al menos uno) — son
    // independientes entre sí, el usuario elige cada lista por separado.
    // Va como multipart (como /provisiones/nuevo) porque lleva un PDF de
    // respaldo único para todo el lote; "cierres" y "nuevos" viajan como
    // texto JSON dentro del multipart, no como campos indexados.
    @PostMapping(value = "/mixto-lote", consumes = "multipart/form-data")
    @ResponseBody
    public ResponseEntity<?> crearMixtoLote(@RequestParam String fechaInicioPeriodo,
                                             @RequestParam String fechaFinPeriodo,
                                             @RequestParam String cierres,
                                             @RequestParam String nuevos,
                                             @RequestParam("pdf") MultipartFile pdf) {
        try {
            List<ConceptoConPagosRequest> cierresRequest = objectMapper.readValue(cierres,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, ConceptoConPagosRequest.class));
            List<ItemProvisionNuevaRequest> nuevosRequest = objectMapper.readValue(nuevos,
                    objectMapper.getTypeFactory().constructCollectionType(List.class, ItemProvisionNuevaRequest.class));
            List<ProvisionRegistro> registros = provisionRegistroService.crearMixtoLote(
                    LocalDate.parse(fechaInicioPeriodo), LocalDate.parse(fechaFinPeriodo),
                    cierresRequest, nuevosRequest, pdf);
            return ResponseEntity.ok(respuestaRegistros(registros));
        } catch (Exception e) {
            log.error("Error al crear lote Mixto de Provisiones", e);
            return ResponseEntity.badRequest().body(respuestaError(e));
        }
    }

    // Cuerpo de error en JSON (no texto plano) para que el fetch del
    // navegador siempre pueda leer resp.json() y mostrar el mensaje real —
    // antes se mandaba un String suelto y el navegador no lo podía parsear,
    // así que siempre terminaba mostrando el genérico "No se pudo guardar".
    private Map<String, String> respuestaError(Exception e) {
        Map<String, String> error = new LinkedHashMap<>();
        error.put("mensaje", e.getMessage() != null ? e.getMessage() : "No se pudo guardar");
        return error;
    }

    private Map<String, Object> respuestaRegistro(ProvisionRegistro registro) {
        Map<String, Object> respuesta = new LinkedHashMap<>();
        respuesta.put("idRegistro", registro.getIdRegistro());
        respuesta.put("valorNuevo", registro.getValorNuevo());
        // Para Anterior/Mixto, el "Valor Nuevo" que se restó no vive en este
        // registro (solo lo tiene el registro Nuevo de origen) — se manda
        // aparte para que la pantalla pueda mostrar los 3 números juntos.
        respuesta.put("valorNuevoOrigen", registro.getRegistroOrigen() != null
                ? registro.getRegistroOrigen().getValorNuevo() : null);
        respuesta.put("valorFacturas", registro.getValorFacturas());
        respuesta.put("valorPendiente", registro.getValorPendiente());
        return respuesta;
    }

    private List<Map<String, Object>> respuestaRegistros(List<ProvisionRegistro> registros) {
        List<Map<String, Object>> respuesta = new ArrayList<>();
        for (ProvisionRegistro registro : registros) {
            respuesta.add(respuestaRegistro(registro));
        }
        return respuesta;
    }
}
