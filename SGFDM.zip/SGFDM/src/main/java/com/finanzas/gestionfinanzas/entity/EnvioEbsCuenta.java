package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ENVIO_EBS_CUENTA")
public class EnvioEbsCuenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_DETALLE")
    private Long idDetalle;

    @ManyToOne
    @JoinColumn(name = "ID_ENVIO_EBS")
    private EnvioEbs envioEbs;

    @ManyToOne
    @JoinColumn(name = "ID_CUENTA")
    private Cuenta cuenta;

    @Column(name = "SUBTOTAL")
    private Double subtotal;

    public Long getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(Long idDetalle) {
        this.idDetalle = idDetalle;
    }

    public EnvioEbs getEnvioEbs() {
        return envioEbs;
    }

    public void setEnvioEbs(EnvioEbs envioEbs) {
        this.envioEbs = envioEbs;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(Double subtotal) {
        this.subtotal = subtotal;
    }
}
