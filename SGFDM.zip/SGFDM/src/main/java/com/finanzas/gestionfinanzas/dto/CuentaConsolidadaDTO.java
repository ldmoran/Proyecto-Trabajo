package com.finanzas.gestionfinanzas.dto;

public class CuentaConsolidadaDTO {

    private final String numeroCuenta;
    private final String descripcion;
    private final Double totalRecolectado;

    public CuentaConsolidadaDTO(String numeroCuenta, String descripcion, Double totalRecolectado) {
        this.numeroCuenta = numeroCuenta;
        this.descripcion = descripcion;
        this.totalRecolectado = totalRecolectado;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Double getTotalRecolectado() {
        return totalRecolectado;
    }
}
