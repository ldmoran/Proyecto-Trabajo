package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaReporte;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


public interface FlujoCajaReporteRepository extends JpaRepository<FlujoCajaReporte, Long> {
    Page<FlujoCajaReporte> findByEstadoOrderByFechaInicioDesc(String estado, Pageable pageable);
    Optional<FlujoCajaReporte> findByFechaInicio(LocalDate fechaInicio);

    // Para el widget "Pendientes de tu firma" del Dashboard: reportes que ya
    // pasaron una etapa pero todavía no la siguiente.
    List<FlujoCajaReporte> findByElaboradoPorIsNotNullAndAprobadoPorIsNullOrderByFechaInicio();
    List<FlujoCajaReporte> findByAprobadoPorIsNotNullAndAutorizadoPorIsNullOrderByFechaInicio();

    // Pantalla "Consultar Flujo de Caja": busca por año/mes/día (de FECHA_INICIO,
    // que siempre es el lunes de la semana). Cualquiera de los 3 puede venir vacío.
    @Query(value = "SELECT * FROM FC_REPORTE r WHERE " +
            "(:anio IS NULL OR EXTRACT(YEAR FROM r.FECHA_INICIO) = :anio) AND " +
            "(:mes IS NULL OR EXTRACT(MONTH FROM r.FECHA_INICIO) = :mes) AND " +
            "(:dia IS NULL OR EXTRACT(DAY FROM r.FECHA_INICIO) = :dia) " +
            "ORDER BY r.FECHA_INICIO DESC",
            countQuery = "SELECT COUNT(*) FROM FC_REPORTE r WHERE " +
            "(:anio IS NULL OR EXTRACT(YEAR FROM r.FECHA_INICIO) = :anio) AND " +
            "(:mes IS NULL OR EXTRACT(MONTH FROM r.FECHA_INICIO) = :mes) AND " +
            "(:dia IS NULL OR EXTRACT(DAY FROM r.FECHA_INICIO) = :dia)",
            nativeQuery = true)
    Page<FlujoCajaReporte> buscarPorFecha(@Param("anio") Integer anio,
                                          @Param("mes") Integer mes,
                                          @Param("dia") Integer dia,
                                          Pageable pageable);

    // Provisiones reutiliza los mismos períodos (semanas) que ya existen en
    // Ingresos/Egresos en vez de inventar semanas propias. Alcanza con que
    // exista el reporte (se crea apenas se guarda Ingresos) — no se exige
    // que Egresos también esté guardado, ambos manejan el mismo período.
    // Devuelve Timestamp (no LocalDate): así mapea el driver de Oracle la
    // columna DATE en una consulta nativa; se convierte a LocalDate en el
    // controlador.
    @Query(value = "SELECT r.FECHA_INICIO FROM FC_REPORTE r ORDER BY r.FECHA_INICIO",
            nativeQuery = true)
    List<java.sql.Timestamp> listarFechasInicio();
}