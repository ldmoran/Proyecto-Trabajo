package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// Mapeo fijo de código crudo de GRUPO_PAGO del ERP -> etiqueta de "Gerencia" a
// mostrar (ver reset_bd.sql y FlujoCajaReporteController.obtenerResumenGrupoPago).
// Solo tiene fila para los códigos que se quieren agrupar bajo una etiqueta
// distinta a la descripción de FND_LOOKUP_VALUES_VL.
@Entity
@Table(name = "FC_EGR_GRUPO_PAGO_GERENCIA")
public class GrupoPagoGerencia {

    @Id
    @Column(name = "CODIGO_FC_EGR_GRUPO_PAGO")
    private String codigoGrupoPago;

    @Column(name = "GERENCIA")
    private String gerencia;

    public String getCodigoGrupoPago() { return codigoGrupoPago; }
    public void setCodigoGrupoPago(String codigoGrupoPago) { this.codigoGrupoPago = codigoGrupoPago; }

    public String getGerencia() { return gerencia; }
    public void setGerencia(String gerencia) { this.gerencia = gerencia; }
}
