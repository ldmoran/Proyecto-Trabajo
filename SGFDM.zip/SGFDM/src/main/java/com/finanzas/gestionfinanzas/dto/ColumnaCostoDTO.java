package com.finanzas.gestionfinanzas.dto;

// Una columna de costo del reporte de Control de Ingresos. Se separa por ENTIDAD
// (Petroecuador / Ministerio) porque el mismo nombre de costo existe en las dos y
// no debe mezclarse; además lleva la cuenta contable a la que se imputa.
public class ColumnaCostoDTO {

    private final String clave;
    private final String nombreCosto;
    private final String entidad;
    private final String numeroCuenta;

    public ColumnaCostoDTO(String nombreCosto, String entidad, String numeroCuenta) {
        this.nombreCosto = nombreCosto;
        this.entidad = entidad;
        this.numeroCuenta = numeroCuenta;
        this.clave = entidad + "|" + nombreCosto;
    }

    public String getClave() {
        return clave;
    }

    public String getNombreCosto() {
        return nombreCosto;
    }

    public String getEntidad() {
        return entidad;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }
}
