package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.Archivo;
import com.finanzas.gestionfinanzas.entity.TipoArchivo;
import com.finanzas.gestionfinanzas.repository.bdd.ArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoArchivoRepository;
import com.finanzas.gestionfinanzas.service.impl.ArchivoService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

// Subir/eliminar archivo son AJAX (no redirigen), así el modal desde el que se
// llaman (facturas.html / facturas-distribuciones.html) se queda abierto; el
// JS del lado del cliente refresca la lista llamando a /archivos-fragment.
@Controller
public class ArchivoController {

    private final ArchivoService archivoService;
    private final ArchivoRepository archivoRepository;
    private final FacturasBDDRepository facturasBDDRepository;
    private final TipoArchivoRepository tipoArchivoRepository;

    public ArchivoController(ArchivoService archivoService,
                             ArchivoRepository archivoRepository,
                             FacturasBDDRepository facturasBDDRepository,
                             TipoArchivoRepository tipoArchivoRepository) {
        this.archivoService = archivoService;
        this.archivoRepository = archivoRepository;
        this.facturasBDDRepository = facturasBDDRepository;
        this.tipoArchivoRepository = tipoArchivoRepository;
    }

    @PostMapping("/facturas/{idFactura}/archivos/subir")
    @ResponseBody
    public ResponseEntity<String> subirArchivo(@PathVariable Long idFactura,
                                               @RequestParam Long idTipoArchivo,
                                               @RequestParam("archivo") MultipartFile archivo) {
        try {
            archivoService.subirArchivo(idFactura, idTipoArchivo, archivo);
            return ResponseEntity.ok("OK");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo subir el archivo");
        }
    }

    @PostMapping("/archivos/{idArchivo}/eliminar")
    @ResponseBody
    public ResponseEntity<String> eliminarArchivo(@PathVariable Long idArchivo) {
        try {
            archivoService.eliminarArchivo(idArchivo);
            return ResponseEntity.ok("OK");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo eliminar el archivo");
        }
    }

    // Devuelve la caja de archivos ya actualizada, para refrescarla sin recargar
    // la página ni cerrar el modal donde vive (facturas.html / distribuciones).
    @GetMapping("/facturas/{idFactura}/archivos-fragment")
    public String archivosFragment(@PathVariable Long idFactura, Model model) {
        boolean aprobada = facturasBDDRepository.findById(idFactura)
                .map(f -> "A".equalsIgnoreCase(f.getEstado()))
                .orElse(false);

        model.addAttribute("idFactura", idFactura);
        model.addAttribute("aprobada", aprobada);
        model.addAttribute("archivosFactura", archivoRepository.findActivosResumenByFactura(idFactura));
        model.addAttribute("tiposArchivo",
                tipoArchivoRepository.findByNombreTipoArchivoAndEstado(TipoArchivo.COMPROBANTE_DISTRIBUCION, "A"));

        return "fragments/archivos :: archivosFragment";
    }

    @GetMapping("/archivos/{idArchivo}/descargar")
    public ResponseEntity<byte[]> descargarArchivo(@PathVariable Long idArchivo) {
        Archivo archivo = archivoRepository.findById(idArchivo)
                .orElseThrow(() -> new RuntimeException("Archivo no encontrado"));

        String nombre = archivo.getNombreArchivo() != null
                ? archivo.getNombreArchivo().replaceAll("[\\r\\n\"]", "_")
                : ("archivo-" + idArchivo);

        return ResponseEntity.ok()
                .contentType(mediaTypeSegun(archivo.getExtension()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + nombre + "\"")
                .body(archivo.getContenido());
    }

    private MediaType mediaTypeSegun(String extension) {
        if ("WORD".equalsIgnoreCase(extension)) {
            return MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        }
        if ("EXCEL".equalsIgnoreCase(extension)) {
            return MediaType.valueOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }
        return MediaType.APPLICATION_PDF;
    }
}
