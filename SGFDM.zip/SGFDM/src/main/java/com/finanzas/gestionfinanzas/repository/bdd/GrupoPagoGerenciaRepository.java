package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.GrupoPagoGerencia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface GrupoPagoGerenciaRepository extends JpaRepository<GrupoPagoGerencia, String> {

    // Etiquetas de gerencia "agrupada" (ej. "GERENCIA DE EXPLORACIÓN Y PRODUCCIÓN"),
    // una por cada grupo distinto — para agregarlas como opción extra en el combo
    // "Gerencia" del buscador (ver FlujoCajaReporteController.obtenerGerenciasDisponibles).
    @Query("SELECT DISTINCT g.gerencia FROM GrupoPagoGerencia g ORDER BY g.gerencia")
    List<String> findGerenciasDistintas();

    // Códigos crudos de GRUPO_PAGO que caen bajo una etiqueta de gerencia agrupada
    // — para resolver la selección del combo a la lista real de códigos que hay
    // que buscar (ver FlujoCajaReporteController.buscarPagablesCxp).
    List<GrupoPagoGerencia> findByGerencia(String gerencia);
}
