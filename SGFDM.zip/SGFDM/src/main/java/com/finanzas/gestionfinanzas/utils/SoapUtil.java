package com.finanzas.gestionfinanzas.utils;
import org.w3c.dom.Element;

import javax.xml.bind.JAXBElement;

public class SoapUtil {
    public static <T> T getValue(JAXBElement<T> element) {
        return element != null ? element.getValue() : null;
    }

    public static String getTagValue(Element parent, String tagName) {

        if (parent.getElementsByTagName(tagName).getLength() == 0) {
            return null;
        }

        return parent.getElementsByTagName(tagName)
                .item(0)
                .getTextContent();
    }
}