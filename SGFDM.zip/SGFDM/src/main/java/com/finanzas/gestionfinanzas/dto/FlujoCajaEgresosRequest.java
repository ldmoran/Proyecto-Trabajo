package com.finanzas.gestionfinanzas.dto;

import java.util.List;

// Payload de la pantalla "Flujo de Caja > Egresos" (secciones 3-8, Consorcios y
// Observaciones). Hermano liviano de FlujoCajaReporteRequest — reutiliza sus
// mismas clases internas de ítem (PriorizadoItem/TransferenciaItem/
// ConsorcioItem) para no duplicarlas. El reporte YA tiene que existir (lo crea
// la pantalla de Ingresos).
public class FlujoCajaEgresosRequest {

    private Long idReporte;
    private String observacion1;
    private String observacion2;
    private String observacion3;

    private List<FlujoCajaReporteRequest.PriorizadoItem> priorizados;
    private List<FlujoCajaReporteRequest.TransferenciaItem> transferencias;
    private List<FlujoCajaReporteRequest.ConsorcioItem> consorcios;

    public Long getIdReporte() { return idReporte; }
    public void setIdReporte(Long idReporte) { this.idReporte = idReporte; }
    public String getObservacion1() { return observacion1; }
    public void setObservacion1(String observacion1) { this.observacion1 = observacion1; }
    public String getObservacion2() { return observacion2; }
    public void setObservacion2(String observacion2) { this.observacion2 = observacion2; }
    public String getObservacion3() { return observacion3; }
    public void setObservacion3(String observacion3) { this.observacion3 = observacion3; }
    public List<FlujoCajaReporteRequest.PriorizadoItem> getPriorizados() { return priorizados; }
    public void setPriorizados(List<FlujoCajaReporteRequest.PriorizadoItem> priorizados) { this.priorizados = priorizados; }
    public List<FlujoCajaReporteRequest.TransferenciaItem> getTransferencias() { return transferencias; }
    public void setTransferencias(List<FlujoCajaReporteRequest.TransferenciaItem> transferencias) { this.transferencias = transferencias; }
    public List<FlujoCajaReporteRequest.ConsorcioItem> getConsorcios() { return consorcios; }
    public void setConsorcios(List<FlujoCajaReporteRequest.ConsorcioItem> consorcios) { this.consorcios = consorcios; }
}
