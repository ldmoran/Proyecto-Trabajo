package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaSaldoInicial;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FlujoCajaSaldoInicialRepository extends JpaRepository<FlujoCajaSaldoInicial, Long> {
    List<FlujoCajaSaldoInicial> findByReporte_IdReporte(Long idReporte);
}