package com.finanzas.gestionfinanzas.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

import javax.sql.DataSource;

// Instancia Oracle APARTE de "primary" (APPS/PRODEBS) y "second" (SFINGRESO/
// APLDB19T1): solo tiene la tabla XX_PAM.PAM_ASIGNA_FACTURAS_TMP del ERP, ya en
// producción — ver FlujoCajaCxpPagableService.enviarAsignacionPam.
@Configuration
@EnableJpaRepositories(
        basePackages = "com.finanzas.gestionfinanzas.repository.pam",
        entityManagerFactoryRef = "pamEntityManagerFactory",
        transactionManagerRef = "pamTransactionManager"
)
public class PamDataSourceConfig {

    @Bean
    @ConfigurationProperties("spring.pam-datasource")
    public DataSourceProperties pamDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    public DataSource pamDataSource() {
        return pamDataSourceProperties().initializeDataSourceBuilder().build();
    }

    @Bean(name = "pamEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean pamEntityManagerFactory(
            @Qualifier("pamDataSource") DataSource dataSource) {

        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource);
        em.setPackagesToScan("com.finanzas.gestionfinanzas.entity");
        em.setPersistenceUnitName("pam");

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);

        return em;
    }

    @Bean(name = "pamTransactionManager")
    public JpaTransactionManager pamTransactionManager(
            @Qualifier("pamEntityManagerFactory") LocalContainerEntityManagerFactoryBean pamEntityManagerFactory) {
        return new JpaTransactionManager(pamEntityManagerFactory.getObject());
    }
}
