package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.dto.ActualizarPagablesResultDTO;
import com.finanzas.gestionfinanzas.dto.FlujoCajaEgresosRequest;
import com.finanzas.gestionfinanzas.dto.FlujoCajaIngresosRequest;
import com.finanzas.gestionfinanzas.dto.FlujoCajaReporteRequest;
import com.finanzas.gestionfinanzas.dto.ResumenCxpFuenteDTO;
import com.finanzas.gestionfinanzas.dto.PagablesResultDTO;
import com.finanzas.gestionfinanzas.dto.ResumenGrupoPagoDTO;
import com.finanzas.gestionfinanzas.entity.GrupoPago;
import com.finanzas.gestionfinanzas.entity.GrupoPagoGerencia;
import com.finanzas.gestionfinanzas.repository.bdd.GrupoPagoGerenciaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.GrupoPagoRepository;
import com.finanzas.gestionfinanzas.entity.*;
import com.finanzas.gestionfinanzas.repository.bdd.*;
import com.finanzas.gestionfinanzas.service.impl.FlujoCajaReporteService;
import com.finanzas.gestionfinanzas.service.impl.FlujoCajaExcelExportService;
import com.finanzas.gestionfinanzas.service.impl.FlujoCajaCxpExcelExportService;
import com.finanzas.gestionfinanzas.service.impl.ArchivoService;
import com.finanzas.gestionfinanzas.service.impl.FlujoCajaExcelImportService;
import com.finanzas.gestionfinanzas.service.impl.FlujoCajaFirmaService;
import com.finanzas.gestionfinanzas.service.impl.EgresoCxpService;
import com.finanzas.gestionfinanzas.service.impl.ConsorcioCxpService;
import com.finanzas.gestionfinanzas.service.impl.FlujoCajaCxpPagableService;
import com.finanzas.gestionfinanzas.utils.FlujoCajaFechaUtils;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/flujo-caja")
public class FlujoCajaReporteController {

    private static final Logger log = LoggerFactory.getLogger(FlujoCajaReporteController.class);

    private final FlujoCajaReporteRepository reporteRepository;
    private final FlujoCajaSaldoInicialRepository saldoInicialRepository;
    private final FlujoCajaIngresoRepository ingresoRepository;
    private final FlujoCajaPriorizadoRepository priorizadoRepository;
    private final FlujoCajaTransferenciaRepository transferenciaRepository;
    private final ConceptoTransferenciaRepository conceptoTransferenciaRepository;
    private final ConsorcioCatalogoRepository consorcioCatalogoRepository;
    private final FlujoCajaConsorcioRepository consorcioRepository;
    private final CuentaBancariaRepository cuentaBancariaRepository;
    private final CategoriaEgresoRepository categoriaEgresoRepository;
    private final ConceptoIngresoRepository conceptoIngresoRepository;
    private final FlujoCajaReporteService flujoCajaReporteService;
    private final FlujoCajaExcelImportService flujoCajaExcelImportService;
    private final ArchivoService archivoService;
    private final FlujoCajaExcelExportService flujoCajaExcelExportService;
    private final FlujoCajaCxpExcelExportService flujoCajaCxpExcelExportService;
    private final FlujoCajaFirmaService flujoCajaFirmaService;
    private final FlujoCajaReportePdfRepository flujoCajaReportePdfRepository;
    private final EgresoCxpService egresoCxpService;
    private final ConsorcioCxpService consorcioCxpService;
    private final FlujoCajaCxpPagableService flujoCajaCxpPagableService;
    private final FlujoCajaCxpPagableRepository flujoCajaCxpPagableRepository;
    private final GrupoPagoGerenciaRepository grupoPagoGerenciaRepository;
    private final GrupoPagoRepository grupoPagoRepository;
    private final UsuarioRepository usuarioRepository;
    private final FlujoCajaResponsableRepository flujoCajaResponsableRepository;

    public FlujoCajaReporteController(FlujoCajaReporteRepository reporteRepository,
                                       FlujoCajaSaldoInicialRepository saldoInicialRepository,
                                       FlujoCajaIngresoRepository ingresoRepository,
                                       FlujoCajaPriorizadoRepository priorizadoRepository,
                                       FlujoCajaTransferenciaRepository transferenciaRepository,
                                       ConceptoTransferenciaRepository conceptoTransferenciaRepository,
                                       ConsorcioCatalogoRepository consorcioCatalogoRepository,
                                       FlujoCajaConsorcioRepository consorcioRepository,
                                       CuentaBancariaRepository cuentaBancariaRepository,
                                       CategoriaEgresoRepository categoriaEgresoRepository,
                                       ConceptoIngresoRepository conceptoIngresoRepository,
                                       FlujoCajaReporteService flujoCajaReporteService,
                                       FlujoCajaExcelImportService flujoCajaExcelImportService,
                                       ArchivoService archivoService,
                                       FlujoCajaExcelExportService flujoCajaExcelExportService,
                                       FlujoCajaCxpExcelExportService flujoCajaCxpExcelExportService,
                                       FlujoCajaFirmaService flujoCajaFirmaService,
                                       FlujoCajaReportePdfRepository flujoCajaReportePdfRepository,
                                       EgresoCxpService egresoCxpService,
                                       ConsorcioCxpService consorcioCxpService,
                                       FlujoCajaCxpPagableService flujoCajaCxpPagableService,
                                       FlujoCajaCxpPagableRepository flujoCajaCxpPagableRepository,
                                       GrupoPagoGerenciaRepository grupoPagoGerenciaRepository,
                                       GrupoPagoRepository grupoPagoRepository,
                                       UsuarioRepository usuarioRepository,
                                       FlujoCajaResponsableRepository flujoCajaResponsableRepository) {
        this.reporteRepository = reporteRepository;
        this.saldoInicialRepository = saldoInicialRepository;
        this.ingresoRepository = ingresoRepository;
        this.priorizadoRepository = priorizadoRepository;
        this.transferenciaRepository = transferenciaRepository;
        this.conceptoTransferenciaRepository = conceptoTransferenciaRepository;
        this.consorcioCatalogoRepository = consorcioCatalogoRepository;
        this.consorcioRepository = consorcioRepository;
        this.cuentaBancariaRepository = cuentaBancariaRepository;
        this.categoriaEgresoRepository = categoriaEgresoRepository;
        this.conceptoIngresoRepository = conceptoIngresoRepository;
        this.flujoCajaReporteService = flujoCajaReporteService;
        this.flujoCajaExcelImportService = flujoCajaExcelImportService;
        this.archivoService = archivoService;
        this.flujoCajaFirmaService = flujoCajaFirmaService;
        this.flujoCajaExcelExportService = flujoCajaExcelExportService;
        this.flujoCajaCxpExcelExportService = flujoCajaCxpExcelExportService;
        this.flujoCajaReportePdfRepository = flujoCajaReportePdfRepository;
        this.egresoCxpService = egresoCxpService;
        this.consorcioCxpService = consorcioCxpService;
        this.flujoCajaCxpPagableService = flujoCajaCxpPagableService;
        this.flujoCajaCxpPagableRepository = flujoCajaCxpPagableRepository;
        this.grupoPagoGerenciaRepository = grupoPagoGerenciaRepository;
        this.grupoPagoRepository = grupoPagoRepository;
        this.usuarioRepository = usuarioRepository;
        this.flujoCajaResponsableRepository = flujoCajaResponsableRepository;
    }

    // Rol (Elaborador/Aprobador/Autorizador) del usuario logueado, según lo que
    // tenga marcado en Mantenimiento > Responsables Flujo de Caja — null si no
    // está marcado con ninguno. Usado en verFirmar() para que en la pantalla de
    // firmar solo le salga el formulario editable de SU propio rol; lo que ya
    // esté firmado se sigue mostrando a todos, sin importar el rol de quien mira.
    private FlujoCajaResponsable obtenerResponsableActual() {
        com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO usuarioActual = SecurityUtils.getUsuarioActual();
        if (usuarioActual == null) {
            return null;
        }
        return usuarioRepository.findByUsuario(usuarioActual.getUsuario())
                .flatMap(u -> flujoCajaResponsableRepository.findByUsuario_IdUsuario(u.getIdUsuario()))
                .orElse(null);
    }

    // Sin parámetro: trae/crea el reporte de la semana actual (lunes de esta semana).
    @GetMapping
    public String verSemanaActual(HttpServletRequest request, Model model) {
        LocalDate lunesActual = LocalDate.now().with(WeekFields.of(new Locale("es", "EC")).dayOfWeek(), 1);
        return cargarReporte(lunesActual, request, model);
    }

    // Con parámetro: navega a la semana que empieza en esa fecha (lunes).
    @GetMapping("/semana")
    public String verSemana(@RequestParam("fechaInicio") String fechaInicioStr,
                             HttpServletRequest request, Model model) {
        LocalDate fechaInicio = LocalDate.parse(fechaInicioStr);
        return cargarReporte(fechaInicio, request, model);
    }

    // ---- Ingresos / Egresos: mismo reporte de siempre, partido en 2 pantallas
    // (ver plan de la sesión). A propósito NO tocan cargarReporte ni la pantalla
    // combinada de arriba (/flujo-caja, /flujo-caja/semana) — esas quedan intactas
    // como red de seguridad, solo se desconectan del menú. ----

    @GetMapping("/ingresos")
    public String verIngresos(@RequestParam(value = "fechaInicio", required = false) String fechaInicioStr,
                               HttpServletRequest request, Model model) {
        LocalDate fechaInicio = fechaInicioStr != null
                ? LocalDate.parse(fechaInicioStr)
                : LocalDate.now().with(WeekFields.of(new Locale("es", "EC")).dayOfWeek(), 1);

        Optional<FlujoCajaReporte> existente = reporteRepository.findByFechaInicio(fechaInicio);
        FlujoCajaReporte reporte;
        List<FlujoCajaSaldoInicial> saldosIniciales;
        List<FlujoCajaIngreso> ingresos;
        if (existente.isPresent()) {
            reporte = existente.get();
            saldosIniciales = saldoInicialRepository.findByReporte_IdReporte(reporte.getIdReporte());
            ingresos = ingresoRepository.findByReporte_IdReporte(reporte.getIdReporte());
        } else {
            reporte = new FlujoCajaReporte();
            reporte.setFechaInicio(fechaInicio);
            reporte.setFechaFin(fechaInicio.plusDays(6));
            reporte.setFechaSaldoInicial(fechaInicio);
            saldosIniciales = Collections.emptyList();
            ingresos = Collections.emptyList();
        }

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("reporte", reporte);
        model.addAttribute("periodosExistentes", periodosExistentes());
        model.addAttribute("bloqueado", "A".equals(reporte.getEstado()));
        // Se bloquea en cuanto el proceso queda Aprobado (ver aprobarProceso) —
        // no hace falta esperar a la firma real de Elaborado.
        model.addAttribute("datosBloqueados",
                "APROBADO".equals(reporte.getEstadoProceso()) || reporte.getElaboradoPor() != null || "A".equals(reporte.getEstado()));

        List<CuentaBancaria> cuentasBancarias = cuentaBancariaRepository.findByEstadoOrderByNombreCuenta("A");
        model.addAttribute("cuentasBancarias", cuentasBancarias);
        List<ConceptoIngreso> conceptosIngreso = conceptoIngresoRepository.findByEstadoOrderByNombreConcepto("A");
        model.addAttribute("conceptosIngreso", conceptosIngreso);

        List<Map<String, Object>> cuentasBancariasJson = new ArrayList<>();
        for (CuentaBancaria c : cuentasBancarias) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", c.getIdCuentaBancaria());
            item.put("nombre", c.getNombreCuenta());
            item.put("numero", c.getNumeroCuenta());
            cuentasBancariasJson.add(item);
        }
        model.addAttribute("cuentasBancariasJson", cuentasBancariasJson);

        List<Map<String, Object>> saldosInicialesJson = new ArrayList<>();
        for (FlujoCajaSaldoInicial s : saldosIniciales) {
            if (s.getCuentaBancaria() != null) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id", s.getCuentaBancaria().getIdCuentaBancaria());
                item.put("nombre", s.getCuentaBancaria().getNombreCuenta());
                item.put("numero", s.getCuentaBancaria().getNumeroCuenta());
                item.put("valor", s.getValor());
                saldosInicialesJson.add(item);
            }
        }
        model.addAttribute("saldosInicialesJson", saldosInicialesJson);

        List<Map<String, Object>> conceptosManualJson = new ArrayList<>();
        for (ConceptoIngreso c : conceptosIngreso) {
            if (!c.isAutomatico()) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id", c.getIdConcepto());
                item.put("nombre", c.getNombreConcepto());
                conceptosManualJson.add(item);
            }
        }
        model.addAttribute("conceptosManualJson", conceptosManualJson);

        List<Map<String, Object>> ingresosManualJson = new ArrayList<>();
        for (FlujoCajaIngreso i : ingresos) {
            if (i.getConcepto() != null && !i.getConcepto().isAutomatico()) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id", i.getConcepto().getIdConcepto());
                item.put("nombre", i.getConcepto().getNombreConcepto());
                item.put("valor", i.getValor());
                ingresosManualJson.add(item);
            }
        }
        model.addAttribute("ingresosManualJson", ingresosManualJson);

        model.addAttribute("semanaAnterior", fechaInicio.minusWeeks(1));
        model.addAttribute("semanaSiguiente", fechaInicio.plusWeeks(1));

        Map<Long, BigDecimal> valorPorCuentaBancaria = new HashMap<>();
        for (FlujoCajaSaldoInicial s : saldosIniciales) {
            valorPorCuentaBancaria.put(s.getCuentaBancaria().getIdCuentaBancaria(), redondear(s.getValor()));
        }
        model.addAttribute("valorPorCuentaBancaria", valorPorCuentaBancaria);

        Map<Long, BigDecimal> valorPorConcepto = new HashMap<>();
        for (FlujoCajaIngreso i : ingresos) {
            if (!i.getConcepto().isAutomatico()) {
                valorPorConcepto.put(i.getConcepto().getIdConcepto(), redondear(i.getValor()));
            }
        }
        for (ConceptoIngreso concepto : conceptosIngreso) {
            if (concepto.isAutomatico()) {
                valorPorConcepto.put(concepto.getIdConcepto(),
                        flujoCajaReporteService.calcularValorAutomatico(concepto, reporte.getFechaInicio()));
            }
        }
        model.addAttribute("valorPorConcepto", valorPorConcepto);

        return "flujo-caja/flujo-caja-ingresos";
    }

    @GetMapping("/egresos")
    public String verEgresos(@RequestParam(value = "fechaInicio", required = false) String fechaInicioStr,
                              HttpServletRequest request, Model model) {
        LocalDate fechaInicio = fechaInicioStr != null
                ? LocalDate.parse(fechaInicioStr)
                : LocalDate.now().with(WeekFields.of(new Locale("es", "EC")).dayOfWeek(), 1);

        Optional<FlujoCajaReporte> existente = reporteRepository.findByFechaInicio(fechaInicio);

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("semanaAnterior", fechaInicio.minusWeeks(1));
        model.addAttribute("semanaSiguiente", fechaInicio.plusWeeks(1));
        model.addAttribute("periodosExistentes", periodosExistentes());

        if (!existente.isPresent()) {
            // Todavía no hay reporte para esta semana: primero hay que cargar
            // Ingresos (esa pantalla es la que lo crea).
            FlujoCajaReporte reporteVacio = new FlujoCajaReporte();
            reporteVacio.setFechaInicio(fechaInicio);
            reporteVacio.setFechaFin(fechaInicio.plusDays(6));
            model.addAttribute("reporte", reporteVacio);
            model.addAttribute("reporteExiste", false);
            return "flujo-caja/flujo-caja-egresos";
        }

        FlujoCajaReporte reporte = existente.get();
        model.addAttribute("reporte", reporte);
        model.addAttribute("reporteExiste", true);
        model.addAttribute("bloqueado", "A".equals(reporte.getEstado()));
        // Se bloquea en cuanto el proceso queda Aprobado (ver aprobarProceso) —
        // no hace falta esperar a la firma real de Elaborado.
        model.addAttribute("datosBloqueados",
                "APROBADO".equals(reporte.getEstadoProceso()) || reporte.getElaboradoPor() != null || "A".equals(reporte.getEstado()));

        List<FlujoCajaPriorizado> priorizados = priorizadoRepository.findByReporte_IdReporte(reporte.getIdReporte());
        List<FlujoCajaTransferencia> transferencias = transferenciaRepository.findByReporte_IdReporte(reporte.getIdReporte());
        List<FlujoCajaConsorcio> consorcios = consorcioRepository.findByReporte_IdReporte(reporte.getIdReporte());

        model.addAttribute("priorizados", priorizados);
        model.addAttribute("transferencias", transferencias);
        model.addAttribute("consorcios", consorcios);
        model.addAttribute("totalEgresosCxp", obtenerTotalEgresosCxp());
        model.addAttribute("resumenGrupoPago", obtenerResumenGrupoPago());
        model.addAttribute("gerenciasDisponibles", obtenerGerenciasDisponibles());

        List<CategoriaEgreso> categoriasEgreso = categoriaEgresoRepository.findByEstadoOrderByNombreCategoria("A");
        model.addAttribute("categoriasEgreso", categoriasEgreso);

        Map<String, FlujoCajaPriorizado> priorizadoPorClave = new HashMap<>();
        for (FlujoCajaPriorizado p : priorizados) {
            priorizadoPorClave.put(p.getSeccion() + "_" + p.getCategoriaEgreso().getIdCategoriaEgreso(), p);
        }
        model.addAttribute("priorizadoPorClave", priorizadoPorClave);

        Map<String, Map<String, ResumenCxpFuenteDTO>> resumenCxpSinFiltrar =
                flujoCajaCxpPagableService.resumenPorFuenteSinFiltrar(reporte.getIdReporte());
        model.addAttribute("automaticoPriorizadoPorCategoria",
                mapearPorCategoria(categoriasEgreso, resumenCxpSinFiltrar.get("NO")));
        model.addAttribute("automaticoPendienteSemanaActualPorCategoria",
                mapearPorCategoria(categoriasEgreso, resumenCxpSinFiltrar.get("SI")));

        // 6) 7) 8) Transferencias: mismo patrón "catálogo + filas ya guardadas"
        // que Ingresos manual — cada sección (SRI/SHAYA_BOC2/HEDGE) admite
        // varias filas, el JS filtra el catálogo por tipo para cada selector.
        List<ConceptoTransferencia> conceptosTransferencia = conceptoTransferenciaRepository.findByEstadoOrderByNombreConcepto("A");
        List<Map<String, Object>> conceptosTransferenciaJson = new ArrayList<>();
        for (ConceptoTransferencia c : conceptosTransferencia) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", c.getIdConcepto());
            item.put("nombre", c.getNombreConcepto());
            item.put("tipo", c.getTipo());
            conceptosTransferenciaJson.add(item);
        }
        model.addAttribute("conceptosTransferenciaJson", conceptosTransferenciaJson);

        List<Map<String, Object>> transferenciasGuardadasJson = new ArrayList<>();
        for (FlujoCajaTransferencia t : transferencias) {
            if (t.getConcepto() == null) {
                continue;
            }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", t.getConcepto().getIdConcepto());
            item.put("nombre", t.getConcepto().getNombreConcepto());
            item.put("tipo", t.getConcepto().getTipo());
            item.put("valor", t.getValor());
            transferenciasGuardadasJson.add(item);
        }
        model.addAttribute("transferenciasGuardadasJson", transferenciasGuardadasJson);
        model.addAttribute("consorciosList", consorcios);
        model.addAttribute("consorciosCatalogo", consorcioCatalogoRepository.findByEstadoOrderByNombreConsorcio("A"));

        // Facturas de Shaya/Shushufindi que vencen en la semana de este reporte
        // (vista APPS.XXOCS_AP_CXP_CONSORCIOS_V) — solo de referencia para
        // ayudar a llenar Descripción/Saldo estimado a mano en "Información
        // Consorcios", ver ConsorcioCxpService.
        List<Map<String, Object>> facturasConsorciosJson = new ArrayList<>();
        for (Object[] fila : consorcioCxpService.obtenerFacturasConsorcios(reporte.getFechaInicio(), reporte.getFechaFin())) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("fuente", fila[0]);
            item.put("invoiceId", fila[1]);
            item.put("proveedor", fila[2]);
            item.put("tipoDocumento", fila[3]);
            item.put("documento", fila[4]);
            item.put("fechaDocumento", fila[5]);
            item.put("fechaVencimiento", fila[6]);
            item.put("importeAPagar", fila[7]);
            item.put("descripcion", fila[8]);
            item.put("contrato", fila[9]);
            item.put("terminoPago", fila[10]);
            item.put("grupoPago", fila[11]);
            item.put("metodoPago", fila[12]);
            facturasConsorciosJson.add(item);
        }
        model.addAttribute("facturasConsorciosJson", facturasConsorciosJson);

        return "flujo-caja/flujo-caja-egresos";
    }

    // "Ver / Firmar": resumen de SOLO LECTURA con Ingresos y Egresos juntos +
    // el bloque Responsables (firmas) + PDF — es la acción de reporte completo,
    // por eso vive aparte de las pantallas de edición (Ingresos/Egresos). Se
    // llega acá desde Consultar Flujo de Caja, el dashboard ("Pendientes de tu
    // firma") y la campanita de notificaciones — todos ya trabajan con
    // fechaInicio, así que esta ruta sigue ese mismo patrón en vez de usar el ID.
    @GetMapping("/firmar")
    public String verFirmar(@RequestParam("fechaInicio") String fechaInicioStr,
                             HttpServletRequest request, Model model) {
        LocalDate fechaInicio = LocalDate.parse(fechaInicioStr);
        Optional<FlujoCajaReporte> existente = reporteRepository.findByFechaInicio(fechaInicio);

        model.addAttribute("path", request.getRequestURI());

        if (!existente.isPresent()) {
            FlujoCajaReporte reporteVacio = new FlujoCajaReporte();
            reporteVacio.setFechaInicio(fechaInicio);
            reporteVacio.setFechaFin(fechaInicio.plusDays(6));
            model.addAttribute("reporte", reporteVacio);
            model.addAttribute("reporteExiste", false);
            return "flujo-caja/flujo-caja-firmar";
        }

        FlujoCajaReporte reporte = existente.get();
        Long idReporte = reporte.getIdReporte();

        model.addAttribute("reporte", reporte);
        model.addAttribute("reporteExiste", true);
        model.addAttribute("bloqueado", "A".equals(reporte.getEstado()));
        model.addAttribute("datosBloqueados",
                "APROBADO".equals(reporte.getEstadoProceso()) || reporte.getElaboradoPor() != null || "A".equals(reporte.getEstado()));

        model.addAttribute("saldosIniciales", saldoInicialRepository.findByReporte_IdReporte(idReporte));
        model.addAttribute("ingresos", ingresoRepository.findByReporte_IdReporte(idReporte));
        model.addAttribute("priorizados", priorizadoRepository.findByReporte_IdReporte(idReporte));
        model.addAttribute("transferencias", transferenciaRepository.findByReporte_IdReporte(idReporte));
        model.addAttribute("consorcios", consorcioRepository.findByReporte_IdReporte(idReporte));

        // Rol del usuario logueado (ver Mantenimiento > Responsables Flujo de
        // Caja): en el bloque "Responsables" de la vista, el formulario editable
        // de cada etapa solo le sale a quien tenga marcado ESE rol puntual — lo
        // que ya esté firmado se sigue mostrando a todos, sin importar el rol.
        FlujoCajaResponsable responsableActual = obtenerResponsableActual();
        model.addAttribute("esElaboradorActual", responsableActual != null && responsableActual.isElaborador());
        model.addAttribute("esAprobadorActual", responsableActual != null && responsableActual.isAprobador());
        model.addAttribute("esAutorizadorActual", responsableActual != null && responsableActual.isAutorizador());

        return "flujo-caja/flujo-caja-firmar";
    }

    // Para el buscador "Buscar flujo de caja" de Ingresos/Egresos/Flujo de Caja:
    // solo los períodos que YA existen en el sistema (nada de elegir un día
    // cualquiera y quizás caer en una semana vacía) — mismo criterio que ya usa
    // Provisiones con listarFechasInicio(), pero acá con la etiqueta completa
    // ("PERÍODO DEL...") y del más reciente al más antiguo.
    private Map<String, String> periodosExistentes() {
        List<java.sql.Timestamp> fechas = reporteRepository.listarFechasInicio();
        Map<String, String> periodos = new LinkedHashMap<>();
        for (int i = fechas.size() - 1; i >= 0; i--) {
            LocalDate inicio = fechas.get(i).toLocalDateTime().toLocalDate();
            periodos.put(inicio.toString(), FlujoCajaFechaUtils.tituloCompleto(inicio, inicio.plusDays(6)));
        }
        return periodos;
    }

    private String cargarReporte(LocalDate fechaInicio, HttpServletRequest request, Model model) {
        Optional<FlujoCajaReporte> existente = reporteRepository.findByFechaInicio(fechaInicio);

        FlujoCajaReporte reporte;
        List<FlujoCajaSaldoInicial> saldosIniciales;
        List<FlujoCajaIngreso> ingresos;
        List<FlujoCajaPriorizado> priorizados;
        List<FlujoCajaTransferencia> transferencias;
        List<FlujoCajaConsorcio> consorcios;

        if (existente.isPresent()) {
            reporte = existente.get();
            saldosIniciales = saldoInicialRepository.findByReporte_IdReporte(reporte.getIdReporte());
            ingresos = ingresoRepository.findByReporte_IdReporte(reporte.getIdReporte());
            priorizados = priorizadoRepository.findByReporte_IdReporte(reporte.getIdReporte());
            transferencias = transferenciaRepository.findByReporte_IdReporte(reporte.getIdReporte());
            consorcios = consorcioRepository.findByReporte_IdReporte(reporte.getIdReporte());
        } else {
            // Reporte "en blanco" todavía no guardado: solo para pintar el formulario vacío
            reporte = new FlujoCajaReporte();
            reporte.setFechaInicio(fechaInicio);
            reporte.setFechaFin(fechaInicio.plusDays(6));
            reporte.setFechaSaldoInicial(fechaInicio);
            saldosIniciales = Collections.emptyList();
            ingresos = Collections.emptyList();
            priorizados = Collections.emptyList();
            transferencias = Collections.emptyList();
            consorcios = Collections.emptyList();
        }

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("reporte", reporte);
        model.addAttribute("periodosExistentes", periodosExistentes());
        // El reporte se crea desde Ingresos: esta pantalla (Flujo de Caja) ya no
        // sirve para armarlo desde cero, solo para revisar/corregir uno que ya
        // exista (mismas tablas que Ingresos/Egresos, así que un cambio hecho
        // acá se ve reflejado ahí también sin nada extra que sincronizar).
        model.addAttribute("reporteExiste", existente.isPresent());
        // Autorizado = bloqueado: el template desactiva TODO (incluidas las
        // firmas ya innecesarias) cuando esto es true.
        model.addAttribute("bloqueado", "A".equals(reporte.getEstado()));
        // Elaborado (o Autorizado, o proceso ya Aprobado) = datosBloqueados: ya
        // no se pueden tocar los datos del reporte (Guardar, Agregar, Importar
        // Excel), para que no queden desactualizados respecto al PDF que ya se
        // firmó — pero las firmas que faltan (Aprobar, Autorizar) siguen activas.
        model.addAttribute("datosBloqueados",
                "APROBADO".equals(reporte.getEstadoProceso()) || reporte.getElaboradoPor() != null || "A".equals(reporte.getEstado()));
        model.addAttribute("saldosIniciales", saldosIniciales);
        model.addAttribute("ingresos", ingresos);
        model.addAttribute("priorizados", priorizados);
        model.addAttribute("transferencias", transferencias);
        model.addAttribute("consorcios", consorcios);
        model.addAttribute("totalEgresosCxp", obtenerTotalEgresosCxp());
        model.addAttribute("resumenGrupoPago", obtenerResumenGrupoPago());
        model.addAttribute("gerenciasDisponibles", obtenerGerenciasDisponibles());

        // Rol del usuario logueado (ver Mantenimiento > Responsables Flujo de
        // Caja): en el bloque "Responsables" de esta misma pantalla, el
        // formulario editable de cada etapa solo le sale a quien tenga marcado
        // ESE rol puntual — ver el mismo criterio en verFirmar().
        FlujoCajaResponsable responsableActual = obtenerResponsableActual();
        model.addAttribute("esElaboradorActual", responsableActual != null && responsableActual.isElaborador());
        model.addAttribute("esAprobadorActual", responsableActual != null && responsableActual.isAprobador());
        model.addAttribute("esAutorizadorActual", responsableActual != null && responsableActual.isAutorizador());

        // Catálogos para armar los combos/filas del formulario
        List<CuentaBancaria> cuentasBancarias = cuentaBancariaRepository.findByEstadoOrderByNombreCuenta("A");
        model.addAttribute("cuentasBancarias", cuentasBancarias);
        List<CategoriaEgreso> categoriasEgreso = categoriaEgresoRepository.findByEstadoOrderByNombreCategoria("A");
        model.addAttribute("categoriasEgreso", categoriasEgreso);
        List<ConceptoIngreso> conceptosIngreso = conceptoIngresoRepository.findByEstadoOrderByNombreConcepto("A");
        model.addAttribute("conceptosIngreso", conceptosIngreso);

        // Saldo Inicial: mismo patrón "agregar de a una" que Ingresos manual, eligiendo
        // la cuenta bancaria desde este catálogo.
        List<Map<String, Object>> cuentasBancariasJson = new ArrayList<>();
        for (CuentaBancaria c : cuentasBancarias) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", c.getIdCuentaBancaria());
            item.put("nombre", c.getNombreCuenta());
            item.put("numero", c.getNumeroCuenta());
            cuentasBancariasJson.add(item);
        }
        model.addAttribute("cuentasBancariasJson", cuentasBancariasJson);

        // Filas ya guardadas para este reporte, para precargar la grilla al abrir.
        List<Map<String, Object>> saldosInicialesJson = new ArrayList<>();
        for (FlujoCajaSaldoInicial s : saldosIniciales) {
            if (s.getCuentaBancaria() != null) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id", s.getCuentaBancaria().getIdCuentaBancaria());
                item.put("nombre", s.getCuentaBancaria().getNombreCuenta());
                item.put("numero", s.getCuentaBancaria().getNumeroCuenta());
                item.put("valor", s.getValor());
                saldosInicialesJson.add(item);
            }
        }
        model.addAttribute("saldosInicialesJson", saldosInicialesJson);

        // Los conceptos Automático quedan siempre fijos en la grilla (se recalculan
        // solos al guardar). Los Manual se eligen de a uno desde este catálogo, y
        // el picker del template los va sacando de la lista a medida que se agregan.
        List<Map<String, Object>> conceptosManualJson = new ArrayList<>();
        for (ConceptoIngreso c : conceptosIngreso) {
            if (!c.isAutomatico()) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id", c.getIdConcepto());
                item.put("nombre", c.getNombreConcepto());
                conceptosManualJson.add(item);
            }
        }
        model.addAttribute("conceptosManualJson", conceptosManualJson);

        // Filas Manual ya guardadas para este reporte, para precargar la grilla al abrir.
        List<Map<String, Object>> ingresosManualJson = new ArrayList<>();
        for (FlujoCajaIngreso i : ingresos) {
            if (i.getConcepto() != null && !i.getConcepto().isAutomatico()) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id", i.getConcepto().getIdConcepto());
                item.put("nombre", i.getConcepto().getNombreConcepto());
                item.put("valor", i.getValor());
                ingresosManualJson.add(item);
            }
        }
        model.addAttribute("ingresosManualJson", ingresosManualJson);

        model.addAttribute("semanaAnterior", fechaInicio.minusWeeks(1));
        model.addAttribute("semanaSiguiente", fechaInicio.plusWeeks(1));

        // Mapas id→valor para que la vista no tenga que buscar fila por fila. Son
        // montos en dólares: en pantalla se redondean a 2 decimales aunque lo
        // guardado tenga más (arrastre de coma flotante de algún Excel importado
        // antes de este ajuste, por ejemplo).
        Map<Long, BigDecimal> valorPorCuentaBancaria = new HashMap<>();
        for (FlujoCajaSaldoInicial s : saldosIniciales) {
            valorPorCuentaBancaria.put(s.getCuentaBancaria().getIdCuentaBancaria(), redondear(s.getValor()));
        }

        Map<Long, BigDecimal> valorPorConcepto = new HashMap<>();
        for (FlujoCajaIngreso i : ingresos) {
            if (!i.getConcepto().isAutomatico()) {
                valorPorConcepto.put(i.getConcepto().getIdConcepto(), redondear(i.getValor()));
            }
        }
        // Los automáticos NO se leen de lo ya guardado: se calculan en vivo cada vez
        // que se abre la pantalla (a partir del envío a EBS de esa semana), para que
        // el usuario los vea apenas entra sin tener que guardar primero. Al guardar,
        // el service los recalcula igual y los persiste (ver recalcularIngresosAutomaticos).
        for (ConceptoIngreso concepto : conceptosIngreso) {
            if (concepto.isAutomatico()) {
                valorPorConcepto.put(concepto.getIdConcepto(),
                        flujoCajaReporteService.calcularValorAutomatico(concepto, reporte.getFechaInicio()));
            }
        }

        Map<String, FlujoCajaPriorizado> priorizadoPorClave = new HashMap<>();
        for (FlujoCajaPriorizado p : priorizados) {
            priorizadoPorClave.put(p.getSeccion() + "_" + p.getCategoriaEgreso().getIdCategoriaEgreso(), p);
        }

        // Secciones 3) Priorizado (Fondos Disponibles, PRIORIZADO='NO') y 4) Montos
        // Priorizados Pendientes de Ejecutar (PRIORIZADO='SI'): a diferencia de 5), estas
        // NO se llenan a mano — salen solas de TODA la Cuentas por Pagar disponible (ver
        // FlujoCajaCxpPagableService.resumenPorFuenteSinFiltrar), sin recortar por cuánto
        // alcanza a pagar (eso es aparte: la cobertura/lista de "Egresos — Cuentas por
        // Pagar" de más abajo). Se cruza acá por nombre de categoría porque el catálogo
        // es genérico (FC_EGR_CATEGORIA), no sabe nada de PAM/PEC.
        Map<String, Map<String, ResumenCxpFuenteDTO>> resumenCxpSinFiltrar =
                flujoCajaCxpPagableService.resumenPorFuenteSinFiltrar(reporte.getIdReporte());
        model.addAttribute("automaticoPriorizadoPorCategoria",
                mapearPorCategoria(categoriasEgreso, resumenCxpSinFiltrar.get("NO")));
        model.addAttribute("automaticoPendienteSemanaActualPorCategoria",
                mapearPorCategoria(categoriasEgreso, resumenCxpSinFiltrar.get("SI")));

        // 6) 7) 8) Transferencias: mismo patrón "catálogo + filas ya guardadas"
        // que Ingresos manual y que la pantalla de Egresos — ver verEgresos.
        List<ConceptoTransferencia> conceptosTransferencia = conceptoTransferenciaRepository.findByEstadoOrderByNombreConcepto("A");
        List<Map<String, Object>> conceptosTransferenciaJson = new ArrayList<>();
        for (ConceptoTransferencia c : conceptosTransferencia) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", c.getIdConcepto());
            item.put("nombre", c.getNombreConcepto());
            item.put("tipo", c.getTipo());
            conceptosTransferenciaJson.add(item);
        }
        model.addAttribute("conceptosTransferenciaJson", conceptosTransferenciaJson);

        List<Map<String, Object>> transferenciasGuardadasJson = new ArrayList<>();
        for (FlujoCajaTransferencia t : transferencias) {
            if (t.getConcepto() == null) {
                continue;
            }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", t.getConcepto().getIdConcepto());
            item.put("nombre", t.getConcepto().getNombreConcepto());
            item.put("tipo", t.getConcepto().getTipo());
            item.put("valor", t.getValor());
            transferenciasGuardadasJson.add(item);
        }
        model.addAttribute("transferenciasGuardadasJson", transferenciasGuardadasJson);

        model.addAttribute("valorPorCuentaBancaria", valorPorCuentaBancaria);
        model.addAttribute("valorPorConcepto", valorPorConcepto);
        model.addAttribute("priorizadoPorClave", priorizadoPorClave);
        model.addAttribute("consorciosList", consorcios);
        model.addAttribute("consorciosCatalogo", consorcioCatalogoRepository.findByEstadoOrderByNombreConsorcio("A"));

        // Facturas de Shaya/Shushufindi que vencen en la semana de este reporte
        // (vista APPS.XXOCS_AP_CXP_CONSORCIOS_V) — solo de referencia para ayudar
        // a llenar Descripción/Saldo estimado a mano en "Información Consorcios",
        // ver ConsorcioCxpService (mismo patrón que verEgresos).
        List<Map<String, Object>> facturasConsorciosJson = new ArrayList<>();
        for (Object[] fila : consorcioCxpService.obtenerFacturasConsorcios(reporte.getFechaInicio(), reporte.getFechaFin())) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("fuente", fila[0]);
            item.put("invoiceId", fila[1]);
            item.put("proveedor", fila[2]);
            item.put("tipoDocumento", fila[3]);
            item.put("documento", fila[4]);
            item.put("fechaDocumento", fila[5]);
            item.put("fechaVencimiento", fila[6]);
            item.put("importeAPagar", fila[7]);
            item.put("descripcion", fila[8]);
            item.put("contrato", fila[9]);
            item.put("terminoPago", fila[10]);
            item.put("grupoPago", fila[11]);
            item.put("metodoPago", fila[12]);
            facturasConsorciosJson.add(item);
        }
        model.addAttribute("facturasConsorciosJson", facturasConsorciosJson);

        return "flujo-caja/flujo-caja-semanal";
    }

    // Cruza el catálogo genérico FC_EGR_CATEGORIA con el resumen PAM/PEC (ver
    // FlujoCajaCxpPagableService.resumenPorFuente) por nombre de categoría, para que
    // el template solo tenga que buscar por idCategoriaEgreso como ya hace con
    // priorizadoPorClave. Se usa tanto al abrir la pantalla como al "Actualizar".
    private Map<Long, ResumenCxpFuenteDTO> mapearPorCategoria(List<CategoriaEgreso> categoriasEgreso,
                                                                Map<String, ResumenCxpFuenteDTO> resumenPorFuente) {
        Map<Long, ResumenCxpFuenteDTO> resultado = new HashMap<>();
        for (CategoriaEgreso cat : categoriasEgreso) {
            String nombre = cat.getNombreCategoria() != null ? cat.getNombreCategoria().toUpperCase() : "";
            String fuenteClave = nombre.contains("EXPLORA") ? "PAM" : nombre.contains("PETROECUADOR") ? "PEC" : null;
            if (fuenteClave != null) {
                resultado.put(cat.getIdCategoriaEgreso(), resumenPorFuente.get(fuenteClave));
            }
        }
        return resultado;
    }

    // Cuentas por Pagar del ERP (ver EgresoCxpService) va contra una base externa
    // (EBS/apps), distinta a la propia del sistema: si esa base no responde, no
    // tiene que tumbar toda la pantalla de Flujo de Caja por un dato que es solo
    // informativo. Si falla, el template muestra "No disponible" en su lugar.
    private BigDecimal obtenerTotalEgresosCxp() {
        try {
            return egresoCxpService.totalAdeudado();
        } catch (Exception e) {
            log.error("No se pudo obtener el total de Cuentas por Pagar (EBS)", e);
            return null;
        }
    }

    // Mismo motivo que obtenerTotalEgresosCxp: es un desglose informativo contra
    // la base externa (EBS/apps), no puede tumbar la pantalla si esa base falla.
    // Es el total SIN FILTRAR (toda la vista APPS.XXOCS_AP_CXP_CONS_V) — lo que se
    // pinta al abrir la pantalla. Después de "Actualizar lista de facturas a
    // pagar" se repinta con obtenerResumenGrupoPagoLocal, acotado a lo que alcanza
    // a cubrirse con los Ingresos (ver actualizarPagablesCxp).
    private List<ResumenGrupoPagoDTO> obtenerResumenGrupoPago() {
        List<ResumenGrupoPagoDTO> crudo;
        try {
            crudo = egresoCxpService.resumenPorGrupoPago();
        } catch (Exception e) {
            log.error("No se pudo obtener el resumen de Cuentas por Pagar por Grupo de Pago (EBS)", e);
            return null;
        }
        return aplicarGerencia(crudo);
    }

    // Mismo desglose "Adeudado por Grupo de Pago", pero calculado sobre la copia
    // local FC_EGR_CXP_PAGABLE (lo que "Actualizar" acaba de guardar: solo las
    // facturas que alcanzan a cubrirse con los Ingresos actuales) en vez de la
    // vista completa del ERP. Se llama justo después de guardarPagables (ver
    // actualizarPagablesCxp) para que la tabla de arriba quede acotada igual que
    // la de abajo.
    private List<ResumenGrupoPagoDTO> obtenerResumenGrupoPagoLocal() {
        Map<String, String> descripcionPorCodigo = new HashMap<>();
        for (GrupoPago g : grupoPagoRepository.findAll()) {
            descripcionPorCodigo.put(g.getCodigoGrupoPago(), g.getDescripcion());
        }

        List<ResumenGrupoPagoDTO> crudo = new ArrayList<>();
        for (Object[] fila : flujoCajaCxpPagableRepository.sumarPorGrupoPago()) {
            String codigo = fila[0] != null ? (String) fila[0] : "SIN GRUPO";
            BigDecimal total = fila[1] instanceof BigDecimal ? (BigDecimal) fila[1] : new BigDecimal(fila[1].toString());
            crudo.add(new ResumenGrupoPagoDTO(codigo, descripcionPorCodigo.getOrDefault(codigo, codigo), total));
        }
        return aplicarGerencia(crudo);
    }

    // Colapsa en una sola fila los códigos que tengan una fila en GRUPO_PAGO_GERENCIA
    // (ej. todos los "BCE *" -> "GERENCIA DE EXPLORACIÓN Y PRODUCCIÓN"), sumando sus
    // totales; el resto queda igual, con su descripción tal cual venía. Ordenado de
    // mayor a menor. Usado tanto por el total sin filtrar como por el acotado a lo
    // guardado en la copia local.
    private List<ResumenGrupoPagoDTO> aplicarGerencia(List<ResumenGrupoPagoDTO> crudo) {
        Map<String, String> gerenciaPorCodigo = new HashMap<>();
        for (GrupoPagoGerencia g : grupoPagoGerenciaRepository.findAll()) {
            gerenciaPorCodigo.put(g.getCodigoGrupoPago(), g.getGerencia());
        }

        Map<String, BigDecimal> totalPorEtiqueta = new LinkedHashMap<>();
        for (ResumenGrupoPagoDTO fila : crudo) {
            String etiqueta = gerenciaPorCodigo.getOrDefault(fila.getCodigoGrupo(), fila.getDescripcion());
            totalPorEtiqueta.merge(etiqueta, fila.getTotal(), BigDecimal::add);
        }

        return totalPorEtiqueta.entrySet().stream()
                .map(e -> new ResumenGrupoPagoDTO(e.getKey(), e.getKey(), e.getValue()))
                .sorted(Comparator.comparing(ResumenGrupoPagoDTO::getTotal).reversed())
                .collect(Collectors.toList());
    }

    // Opciones del combo "Gerencia" del buscador de facturas pagables: el catálogo
    // local GRUPO_PAGO (copia fija de FND_LOOKUP_VALUES_VL, ver reset_bd.sql), más
    // una opción extra por cada etiqueta agrupada de GRUPO_PAGO_GERENCIA (ej.
    // "GERENCIA DE EXPLORACIÓN Y PRODUCCIÓN", que junta varios códigos "BCE *" que
    // ni siquiera están en el catálogo oficial). A propósito NO depende del ERP en
    // vivo ni de la copia local volátil FC_EGR_CXP_PAGABLE (esa puede estar
    // vacía en cualquier momento y dejaba el combo sin opciones).
    private Map<String, String> obtenerGerenciasDisponibles() {
        Map<String, String> opciones = new LinkedHashMap<>();
        for (GrupoPago g : grupoPagoRepository.findAllByOrderByDescripcionAsc()) {
            opciones.put(g.getCodigoGrupoPago(), g.getDescripcion());
        }
        for (String gerencia : grupoPagoGerenciaRepository.findGerenciasDistintas()) {
            opciones.put(gerencia, gerencia);
        }
        return opciones;
    }

    // Se llama por AJAX desde la pantalla cada vez que cambia "Ingresos total" (ver
    // recalcularTotalesEnVivo() en flujo-caja-semanal.html), para saber hasta qué
    // factura de Cuentas por Pagar alcanzaría a pagar con ese monto — salteando las
    // que ya están comprometidas por otro reporte Autorizado (ver
    // FlujoCajaCxpPagableService). idReporte viene null si el reporte todavía no se
    // guardó ninguna vez. Puramente informativo/visual, no persiste nada.
    @GetMapping("/egresos-cxp/cobertura")
    @ResponseBody
    public ResponseEntity<?> coberturaCxp(@RequestParam BigDecimal monto,
                                           @RequestParam(required = false) Long idReporte) {
        try {
            return ResponseEntity.ok(flujoCajaCxpPagableService.calcularCobertura(monto, idReporte));
        } catch (Exception e) {
            log.error("No se pudo calcular la cobertura de Cuentas por Pagar (EBS)", e);
            return ResponseEntity.badRequest().body("No se pudo calcular la cobertura en este momento");
        }
    }

    // Botón "Actualizar" de la sección Egresos: trae de EBS todas las facturas que
    // alcanzan a pagarse con ese monto (salteando las ya comprometidas por otro
    // reporte) y las guarda en la copia local para navegar/buscar (ver
    // FlujoCajaCxpPagableService.guardarPagables) — todavía NO compromete nada de
    // forma permanente, eso solo pasa al Autorizar. A propósito no se llama en cada
    // recálculo en vivo (eso solo pega con calcularCobertura, mucho más liviano).
    @PostMapping("/egresos-cxp/actualizar-pagables")
    @ResponseBody
    public ResponseEntity<?> actualizarPagablesCxp(@RequestParam BigDecimal monto,
                                                     @RequestParam(required = false) Long idReporte) {
        try {
            flujoCajaCxpPagableService.guardarPagables(monto, idReporte);
            List<CategoriaEgreso> categoriasEgreso = categoriaEgresoRepository.findByEstadoOrderByNombreCategoria("A");
            // Secciones 3/4 se repintan con el mismo total SIN FILTRAR de siempre (no con
            // lo que acaba de guardar guardarPagables, que sí queda acotado por "monto") —
            // ver el comentario en cargarReporte.
            Map<String, Map<String, ResumenCxpFuenteDTO>> resumenCxpSinFiltrar =
                    flujoCajaCxpPagableService.resumenPorFuenteSinFiltrar(idReporte);
            ActualizarPagablesResultDTO resultado = new ActualizarPagablesResultDTO(
                    flujoCajaCxpPagableService.calcularCobertura(monto, idReporte),
                    mapearPorCategoria(categoriasEgreso, resumenCxpSinFiltrar.get("NO")),
                    mapearPorCategoria(categoriasEgreso, resumenCxpSinFiltrar.get("SI")),
                    obtenerResumenGrupoPagoLocal());
            return ResponseEntity.ok(resultado);
        } catch (Exception e) {
            log.error("No se pudo actualizar la lista de facturas pagables (EBS)", e);
            return ResponseEntity.badRequest().body("No se pudo actualizar la lista en este momento");
        }
    }

    // Lista/busca en la copia local (rápida, no vuelve a tocar EBS). Los 5 filtros
    // son opcionales; sin ninguno, trae las primeras (ordenadas por ORDEN = prioridad
    // de pago).
    @GetMapping("/egresos-cxp/pagables")
    @ResponseBody
    public PagablesResultDTO buscarPagablesCxp(@RequestParam(required = false) String fechaVencimiento,
                                                @RequestParam(required = false) String fechaDocumento,
                                                @RequestParam(required = false) String documento,
                                                @RequestParam(required = false) String proveedor,
                                                @RequestParam(required = false) String grupoPago,
                                                @RequestParam(defaultValue = "0") int page) {
        LocalDate fVenc = (fechaVencimiento != null && !fechaVencimiento.trim().isEmpty()) ? LocalDate.parse(fechaVencimiento) : null;
        LocalDate fDoc = (fechaDocumento != null && !fechaDocumento.trim().isEmpty()) ? LocalDate.parse(fechaDocumento) : null;
        String doc = (documento != null && !documento.trim().isEmpty()) ? documento.trim() : null;
        String prov = (proveedor != null && !proveedor.trim().isEmpty()) ? proveedor.trim() : null;
        String grupo = (grupoPago != null && !grupoPago.trim().isEmpty()) ? grupoPago.trim() : null;
        PageRequest pageable = PageRequest.of(page, 10);

        // Si lo elegido en el combo es una etiqueta agrupada (ej. "GERENCIA DE
        // EXPLORACIÓN Y PRODUCCIÓN"), hay que buscar por TODOS los códigos crudos
        // que caen bajo esa etiqueta (GRUPO_PAGO_GERENCIA), no por el texto literal
        // — que no es un GRUPO_PAGO real, así que un "=" exacto nunca matchearía. El
        // total filtrado (para el "Total filtrado" en vivo de la pantalla) se calcula
        // con la misma condición, sumando TODAS las que matchean, no solo la página.
        if (grupo != null) {
            List<GrupoPagoGerencia> codigosAgrupados = grupoPagoGerenciaRepository.findByGerencia(grupo);
            if (!codigosAgrupados.isEmpty()) {
                List<String> codigos = codigosAgrupados.stream().map(GrupoPagoGerencia::getCodigoGrupoPago).collect(Collectors.toList());
                Page<EgresoCxpPagable> pagina = flujoCajaCxpPagableRepository.buscarPorGrupoPagoEnLista(fVenc, fDoc, doc, prov, codigos, pageable);
                BigDecimal total = flujoCajaCxpPagableRepository.sumarImportePorGrupoPagoEnLista(fVenc, fDoc, doc, prov, codigos);
                return new PagablesResultDTO(pagina, total);
            }
        }

        Page<EgresoCxpPagable> pagina = flujoCajaCxpPagableRepository.buscar(fVenc, fDoc, doc, prov, grupo, pageable);
        BigDecimal total = flujoCajaCxpPagableRepository.sumarImporte(fVenc, fDoc, doc, prov, grupo);
        return new PagablesResultDTO(pagina, total);
    }

    // Excel con TODAS las facturas cubiertas con los Ingresos de este reporte
    // (todas las columnas, no solo las que se ven en el buscador paginado de
    // arriba). Se calcula en el momento con el mismo método que usa
    // marcarAutorizado — no se lee de la copia local FC_EGR_CXP_PAGABLE
    // porque esa es compartida entre TODOS los reportes (se reescribe cada vez
    // que cualquiera aprieta "Actualizar" en cualquier semana) y podría estar
    // desactualizada respecto a este reporte puntual.
    @GetMapping("/egresos-cxp/exportar-excel")
    public void exportarExcelPagables(@RequestParam Long idReporte, HttpServletResponse response) throws IOException {
        FlujoCajaReporte reporte = reporteRepository.findById(idReporte)
                .orElseThrow(() -> new RuntimeException("Reporte no encontrado"));
        List<Object[]> cubiertas = flujoCajaCxpPagableService.calcularCubiertasParaAutorizar(idReporte, reporte.getIngresosTotal());

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=cuentas-por-pagar-" + reporte.getFechaInicio() + ".xlsx");
        flujoCajaCxpExcelExportService.escribir(cubiertas, response.getOutputStream());
    }

    // Excel con TODAS las facturas de Cuentas por Pagar disponibles en el ERP
    // (mismas 16 columnas que el de arriba), SIN cortar por cuánto alcanza a
    // pagar con los Ingresos — para comparar contra lo que sí queda cubierto.
    // Sigue excluyendo lo ya comprometido por OTROS reportes (esas facturas ya
    // no están disponibles para nadie más, sin importar el corte de dinero).
    @GetMapping("/egresos-cxp/exportar-excel-todas")
    public void exportarExcelTodasLasFacturas(@RequestParam(required = false) Long idReporte, HttpServletResponse response) throws IOException {
        List<Object[]> todas = flujoCajaCxpPagableService.obtenerDisponibles(idReporte);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=cuentas-por-pagar-todas.xlsx");
        flujoCajaCxpExcelExportService.escribir(todas, response.getOutputStream());
    }

    @PostMapping("/guardar")
    @ResponseBody
    public ResponseEntity<?> guardar(@RequestBody FlujoCajaReporteRequest request) {
        try {
            return ResponseEntity.ok(flujoCajaReporteService.guardarCompleto(request));
        } catch (Exception e) {
            log.error("Error al guardar Flujo de Caja (idReporte={})", request.getIdReporte(), e);
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo guardar el reporte");
        }
    }

    @PostMapping("/ingresos/guardar")
    @ResponseBody
    public ResponseEntity<?> guardarIngresos(@RequestBody FlujoCajaIngresosRequest request) {
        try {
            return ResponseEntity.ok(flujoCajaReporteService.guardarIngresos(request));
        } catch (Exception e) {
            log.error("Error al guardar Ingresos de Flujo de Caja (idReporte={})", request.getIdReporte(), e);
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo guardar Ingresos");
        }
    }

    @PostMapping("/egresos/guardar")
    @ResponseBody
    public ResponseEntity<?> guardarEgresos(@RequestBody FlujoCajaEgresosRequest request) {
        try {
            return ResponseEntity.ok(flujoCajaReporteService.guardarEgresos(request));
        } catch (Exception e) {
            log.error("Error al guardar Egresos de Flujo de Caja (idReporte={})", request.getIdReporte(), e);
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo guardar Egresos");
        }
    }

    // ---- Estado de proceso: paso liviano (sin certificado), a nivel de todo
    // el reporte, antes de las 3 firmas reales. Mismo estilo simple de POST
    // que ya se usa arriba, sin multipart. ----

    @PostMapping("/{id}/revisar")
    @ResponseBody
    public ResponseEntity<?> revisarProceso(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(flujoCajaReporteService.revisarProceso(id));
        } catch (Exception e) {
            log.error("Error al marcar el reporte como Revisado (idReporte={})", id, e);
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo marcar como Revisado");
        }
    }

    @PostMapping("/{id}/aprobar")
    @ResponseBody
    public ResponseEntity<?> aprobarProceso(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(flujoCajaReporteService.aprobarProceso(id));
        } catch (Exception e) {
            log.error("Error al marcar el reporte como Aprobado (idReporte={})", id, e);
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo marcar como Aprobado");
        }
    }

    // Lee el Excel y devuelve las filas que logró matchear contra el catálogo de
    // cuentas bancarias, para que el navegador precargue el grid de Saldo Inicial.
    // Además guarda el archivo tal cual (ver ArchivoService.subirComprobanteSaldoInicial)
    // como Tipo de Archivo "Saldo Inicial", para control de auditoría de dónde
    // salieron esos valores — no queda ligado al reporte, es solo respaldo.
    @PostMapping("/saldo-inicial/importar-excel")
    @ResponseBody
    public ResponseEntity<?> importarSaldoInicialExcel(@RequestParam("archivo") MultipartFile archivo) {
        try {
            archivoService.subirComprobanteSaldoInicial(archivo);
            List<CuentaBancaria> cuentasActivas = cuentaBancariaRepository.findByEstadoOrderByNombreCuenta("A");
            List<Map<String, Object>> filas = flujoCajaExcelImportService.leerSaldosIniciales(archivo.getInputStream(), cuentasActivas);
            return ResponseEntity.ok(filas);
        } catch (Exception e) {
            log.error("Error al importar Excel de Saldo Inicial", e);
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo leer el archivo");
        }
    }

    // Mismo criterio que el de arriba, pero para los conceptos Manual de Ingresos
    // (los Automático no se importan: se calculan solos desde el envío a EBS), y
    // guardando el archivo como Tipo de Archivo "Ingresos por Recibir".
    @PostMapping("/ingresos/importar-excel")
    @ResponseBody
    public ResponseEntity<?> importarIngresosExcel(@RequestParam("archivo") MultipartFile archivo) {
        try {
            archivoService.subirComprobanteIngresos(archivo);
            List<ConceptoIngreso> conceptosManuales = conceptoIngresoRepository.findByEstadoOrderByNombreConcepto("A")
                    .stream()
                    .filter(c -> !c.isAutomatico())
                    .collect(Collectors.toList());
            List<Map<String, Object>> filas = flujoCajaExcelImportService.leerIngresosManuales(archivo.getInputStream(), conceptosManuales);
            return ResponseEntity.ok(filas);
        } catch (Exception e) {
            log.error("Error al importar Excel de Ingresos", e);
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo leer el archivo");
        }
    }

    // Los montos son dinero: en pantalla siempre a 2 decimales redondeados, aunque
    // lo guardado tenga más (arrastre de coma flotante de un Excel importado antes
    // de este ajuste, por ejemplo).
    private BigDecimal redondear(BigDecimal valor) {
        return valor == null ? null : valor.setScale(2, RoundingMode.HALF_UP);
    }

    // ---- Firmas: Elaborado -> Aprobado -> Autorizado. Autorizar bloquea el reporte. ----

    @PostMapping("/{id}/marcar-elaborado")
    @ResponseBody
    public ResponseEntity<?> marcarElaborado(@PathVariable Long id,
                                              @RequestParam("p12") MultipartFile p12,
                                              @RequestParam("clave") String clave,
                                              @RequestParam(value = "x", required = false) Integer x,
                                              @RequestParam(value = "y", required = false) Integer y) {
        return responderFirma(id, p12, clave, x, y, flujoCajaReporteService::marcarElaborado);
    }

    @PostMapping("/{id}/marcar-aprobado")
    @ResponseBody
    public ResponseEntity<?> marcarAprobado(@PathVariable Long id,
                                             @RequestParam("p12") MultipartFile p12,
                                             @RequestParam("clave") String clave,
                                             @RequestParam(value = "x", required = false) Integer x,
                                             @RequestParam(value = "y", required = false) Integer y) {
        return responderFirma(id, p12, clave, x, y, flujoCajaReporteService::marcarAprobado);
    }

    @PostMapping("/{id}/marcar-autorizado")
    @ResponseBody
    public ResponseEntity<?> marcarAutorizado(@PathVariable Long id,
                                               @RequestParam("p12") MultipartFile p12,
                                               @RequestParam("clave") String clave,
                                               @RequestParam(value = "x", required = false) Integer x,
                                               @RequestParam(value = "y", required = false) Integer y) {
        return responderFirma(id, p12, clave, x, y, flujoCajaReporteService::marcarAutorizado);
    }

    // El .p12 y la contraseña solo viven durante esta petición puntual: se leen,
    // se usan para firmar dentro de flujoCajaReporteService/FlujoCajaFirmaService,
    // y la contraseña se borra de memoria apenas se usa (ver FlujoCajaFirmaService).
    // No se guardan en ningún lado del servidor. x/y son la posición que eligió
    // el usuario haciendo clic sobre la vista previa del PDF (pueden venir null
    // si por algo no las mandó, ahí FlujoCajaFirmaService usa una de respaldo).
    private ResponseEntity<?> responderFirma(Long id, MultipartFile p12, String clave, Integer x, Integer y, FuncionFirma accion) {
        char[] password = clave != null ? clave.toCharArray() : new char[0];
        try (InputStream p12Stream = p12.getInputStream()) {
            return ResponseEntity.ok(accion.aplicar(id, p12Stream, password, x, y));
        } catch (Exception e) {
            log.error("Error al procesar una firma de Flujo de Caja", e);
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo completar la acción");
        }
    }

    @FunctionalInterface
    private interface FuncionFirma {
        FlujoCajaReporte aplicar(Long idReporte, InputStream p12Stream, char[] password, Integer x, Integer y) throws IOException;
    }

    // Descarga el PDF acumulado del reporte (sin firmas todavía si nadie firmó,
    // con 1 a 3 firmas incrementales según cuántas etapas se hayan completado).
    @GetMapping("/{id}/pdf-firmado")
    public void descargarPdfFirmado(@PathVariable Long id, HttpServletResponse response) throws IOException {
        byte[] pdf = flujoCajaFirmaService.obtenerPdf(id);
        if (pdf == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Este reporte todavía no tiene ninguna firma");
            return;
        }
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "inline; filename=flujo-caja-" + id + "-firmado.pdf");
        response.getOutputStream().write(pdf);
    }

    // Vista previa del PDF (genera el base si todavía no existe) para que el
    // usuario lo vea en el navegador y elija con un clic dónde va a caer su
    // firma, antes de subir el .p12. No pisa el PDF firmado si ya hay uno: usa
    // el mismo (acumulado con las firmas que ya haya).
    @GetMapping("/{id}/pdf-preview")
    public void previsualizarPdf(@PathVariable Long id, HttpServletResponse response) throws IOException {
        byte[] pdf = flujoCajaFirmaService.obtenerOGenerarPdfBase(id);
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "inline; filename=flujo-caja-" + id + "-preview.pdf");
        response.getOutputStream().write(pdf);
    }

    // ---- Consultar Flujo de Caja: histórico, búsqueda por año/mes/día ----

    @GetMapping("/consultar")
    public String consultar(@RequestParam(required = false) Integer anio,
                             @RequestParam(required = false) Integer mes,
                             @RequestParam(required = false) Integer dia,
                             @RequestParam(defaultValue = "0") int page,
                             HttpServletRequest request, Model model) {
        Page<FlujoCajaReporte> reportesPage = reporteRepository.buscarPorFecha(anio, mes, dia, PageRequest.of(page, 10));

        // Qué reportes de esta página ya tienen algún PDF firmado, para mostrar el
        // link de descarga solo ahí (sin cargar el contenido de ningún PDF).
        Map<Long, Boolean> tienePdfPorReporte = new HashMap<>();
        for (FlujoCajaReporte r : reportesPage.getContent()) {
            tienePdfPorReporte.put(r.getIdReporte(), flujoCajaReportePdfRepository.existsByReporte_IdReporte(r.getIdReporte()));
        }

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("reportesPage", reportesPage);
        model.addAttribute("tienePdfPorReporte", tienePdfPorReporte);
        model.addAttribute("anio", anio);
        model.addAttribute("mes", mes);
        model.addAttribute("dia", dia);
        return "flujo-caja/consultar";
    }

    // Ver detalles de un reporte ya guardado, de solo lectura (sin catálogos ni
    // JSON para pickers: eso es solo para la pantalla de edición).
    @GetMapping("/{id}/detalle")
    public String verDetalle(@PathVariable Long id, Model model) {
        FlujoCajaReporte reporte = reporteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reporte no encontrado"));

        model.addAttribute("reporte", reporte);
        model.addAttribute("saldosIniciales", saldoInicialRepository.findByReporte_IdReporte(id));
        model.addAttribute("ingresos", ingresoRepository.findByReporte_IdReporte(id));
        model.addAttribute("priorizados", priorizadoRepository.findByReporte_IdReporte(id));
        model.addAttribute("transferencias", transferenciaRepository.findByReporte_IdReporte(id));
        model.addAttribute("consorcios", consorcioRepository.findByReporte_IdReporte(id));
        return "fragments/flujo-caja-detalle :: flujoCajaDetalleFragment";
    }

    // Excel con el mismo contenido guardado, con el formato/estilo del resto de
    // exports del sistema (ver FlujoCajaExcelExportService).
    @GetMapping("/exportar-excel")
    public void exportarExcel(@RequestParam Long idReporte, HttpServletResponse response) throws IOException {
        FlujoCajaReporte reporte = reporteRepository.findById(idReporte)
                .orElseThrow(() -> new RuntimeException("Reporte no encontrado"));
        List<FlujoCajaSaldoInicial> saldosIniciales = saldoInicialRepository.findByReporte_IdReporte(idReporte);
        List<FlujoCajaIngreso> ingresos = ingresoRepository.findByReporte_IdReporte(idReporte);
        List<FlujoCajaPriorizado> priorizados = priorizadoRepository.findByReporte_IdReporte(idReporte);
        List<FlujoCajaTransferencia> transferencias = transferenciaRepository.findByReporte_IdReporte(idReporte);
        List<FlujoCajaConsorcio> consorcios = consorcioRepository.findByReporte_IdReporte(idReporte);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=flujo-caja-" + reporte.getFechaInicio() + ".xlsx");
        flujoCajaExcelExportService.escribir(reporte, saldosIniciales, ingresos, priorizados, transferencias, consorcios, response.getOutputStream());
    }
}