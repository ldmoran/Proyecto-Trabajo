package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.EgresoCxpPagable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface FlujoCajaCxpPagableRepository extends JpaRepository<EgresoCxpPagable, Long> {

    // Los 5 filtros son opcionales (cualquiera puede venir null) y se combinan con
    // AND — mismo patrón que FlujoCajaReporteRepository.buscarPorFecha. Documento y
    // Proveedor buscan "contiene" (no exacto): no todas las facturas tienen el mismo
    // formato de número de documento, así que exigir el número completo casi nunca
    // encontraba nada. Gerencia (grupoPago) es exacto: sale del combo armado con el
    // catálogo GRUPO_PAGO, no de texto libre.
    @Query("SELECT p FROM EgresoCxpPagable p WHERE " +
            "(:fechaVencimiento IS NULL OR p.fechaVencimiento = :fechaVencimiento) AND " +
            "(:fechaDocumento IS NULL OR p.fechaDocumento = :fechaDocumento) AND " +
            "(:documento IS NULL OR UPPER(p.documento) LIKE UPPER(CONCAT('%', :documento, '%'))) AND " +
            "(:proveedor IS NULL OR UPPER(p.proveedor) LIKE UPPER(CONCAT('%', :proveedor, '%'))) AND " +
            "(:grupoPago IS NULL OR p.grupoPago = :grupoPago) " +
            "ORDER BY p.orden")
    Page<EgresoCxpPagable> buscar(@Param("fechaVencimiento") LocalDate fechaVencimiento,
                                   @Param("fechaDocumento") LocalDate fechaDocumento,
                                   @Param("documento") String documento,
                                   @Param("proveedor") String proveedor,
                                   @Param("grupoPago") String grupoPago,
                                   Pageable pageable);

    // Mismos filtros, pero cuando el combo "Gerencia" eligió una etiqueta AGRUPADA
    // (ej. "GERENCIA DE EXPLORACIÓN Y PRODUCCIÓN" = varios códigos "BCE *" a la
    // vez, ver GRUPO_PAGO_GERENCIA) — ahí hace falta IN en vez de "=". Separado de
    // buscar() en vez de un solo método con "OR p.grupoPago IN :lista" para no
    // andar bindeando una lista null cuando no hay ese filtro (Hibernate no lo
    // banca bien con el patrón "IS NULL OR").
    @Query("SELECT p FROM EgresoCxpPagable p WHERE " +
            "(:fechaVencimiento IS NULL OR p.fechaVencimiento = :fechaVencimiento) AND " +
            "(:fechaDocumento IS NULL OR p.fechaDocumento = :fechaDocumento) AND " +
            "(:documento IS NULL OR UPPER(p.documento) LIKE UPPER(CONCAT('%', :documento, '%'))) AND " +
            "(:proveedor IS NULL OR UPPER(p.proveedor) LIKE UPPER(CONCAT('%', :proveedor, '%'))) AND " +
            "p.grupoPago IN :codigosGrupoPago " +
            "ORDER BY p.orden")
    Page<EgresoCxpPagable> buscarPorGrupoPagoEnLista(@Param("fechaVencimiento") LocalDate fechaVencimiento,
                                                       @Param("fechaDocumento") LocalDate fechaDocumento,
                                                       @Param("documento") String documento,
                                                       @Param("proveedor") String proveedor,
                                                       @Param("codigosGrupoPago") List<String> codigosGrupoPago,
                                                       Pageable pageable);

    // Mismos filtros que buscar(), pero solo el total de IMPORTE_A_PAGAR de TODAS
    // las facturas que matchean (no solo las 10 de la página visible) — para el
    // "Total filtrado" que se recalcula en vivo con cada búsqueda (ver
    // FlujoCajaReporteController.buscarPagablesCxp).
    @Query("SELECT COALESCE(SUM(p.importeAPagar), 0) FROM EgresoCxpPagable p WHERE " +
            "(:fechaVencimiento IS NULL OR p.fechaVencimiento = :fechaVencimiento) AND " +
            "(:fechaDocumento IS NULL OR p.fechaDocumento = :fechaDocumento) AND " +
            "(:documento IS NULL OR UPPER(p.documento) LIKE UPPER(CONCAT('%', :documento, '%'))) AND " +
            "(:proveedor IS NULL OR UPPER(p.proveedor) LIKE UPPER(CONCAT('%', :proveedor, '%'))) AND " +
            "(:grupoPago IS NULL OR p.grupoPago = :grupoPago)")
    BigDecimal sumarImporte(@Param("fechaVencimiento") LocalDate fechaVencimiento,
                             @Param("fechaDocumento") LocalDate fechaDocumento,
                             @Param("documento") String documento,
                             @Param("proveedor") String proveedor,
                             @Param("grupoPago") String grupoPago);

    // Misma idea que sumarImporte(), para cuando el filtro es una etiqueta
    // agrupada (ver buscarPorGrupoPagoEnLista).
    @Query("SELECT COALESCE(SUM(p.importeAPagar), 0) FROM EgresoCxpPagable p WHERE " +
            "(:fechaVencimiento IS NULL OR p.fechaVencimiento = :fechaVencimiento) AND " +
            "(:fechaDocumento IS NULL OR p.fechaDocumento = :fechaDocumento) AND " +
            "(:documento IS NULL OR UPPER(p.documento) LIKE UPPER(CONCAT('%', :documento, '%'))) AND " +
            "(:proveedor IS NULL OR UPPER(p.proveedor) LIKE UPPER(CONCAT('%', :proveedor, '%'))) AND " +
            "p.grupoPago IN :codigosGrupoPago")
    BigDecimal sumarImportePorGrupoPagoEnLista(@Param("fechaVencimiento") LocalDate fechaVencimiento,
                                                @Param("fechaDocumento") LocalDate fechaDocumento,
                                                @Param("documento") String documento,
                                                @Param("proveedor") String proveedor,
                                                @Param("codigosGrupoPago") List<String> codigosGrupoPago);

    // Subtotal por GRUPO_PAGO de TODO lo que hay guardado en la copia local en este
    // momento (sin filtros) — que es justo lo que "alcanza a pagar" con los
    // Ingresos con los que se apretó "Actualizar" (ver guardarPagables). Repinta
    // "Adeudado por Grupo de Pago" con este recorte en vez del total sin filtrar de
    // EgresoCxpService.resumenPorGrupoPago (ver
    // FlujoCajaReporteController.actualizarPagablesCxp).
    @Query("SELECT p.grupoPago, SUM(p.importeAPagar) FROM EgresoCxpPagable p GROUP BY p.grupoPago")
    List<Object[]> sumarPorGrupoPago();
}
