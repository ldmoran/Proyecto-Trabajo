package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

// Agrupa varias filas de ProvisionRegistro (cada una un Concepto de
// Provisión distinto, con su propio valor) que se cargaron juntas en un
// mismo clic de "Guardar" de Nueva (más adelante también Mixto). Ver el
// comentario de la tabla en reset_bd.sql.
@Entity
@Table(name = "PROVISION_LOTE")
public class ProvisionLote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_LOTE")
    private Long idLote;

    @Column(name = "TIPO")
    private String tipo;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdLote() { return idLote; }
    public void setIdLote(Long idLote) { this.idLote = idLote; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}
