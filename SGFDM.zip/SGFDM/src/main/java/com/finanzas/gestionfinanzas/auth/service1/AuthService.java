package com.finanzas.gestionfinanzas.auth.service1;


import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.auth.dto.response.MenuDTO;

import java.util.List;

public interface AuthService {
    AuthResponseDTO authenticate(String username, String password) throws Exception;
    List<MenuDTO> obtenerPerfilesUsuario(String idUsuario, String idAplicacion, String token);
}
