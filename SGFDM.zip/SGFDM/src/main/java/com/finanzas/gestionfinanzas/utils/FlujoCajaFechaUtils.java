package com.finanzas.gestionfinanzas.utils;

import java.time.LocalDate;

// Nombres de mes en español a mano (no vía Locale) para no depender de la
// configuración regional del servidor donde corra la app.
public class FlujoCajaFechaUtils {

    private static final String[] MESES = {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO",
            "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"};

    private FlujoCajaFechaUtils() {
    }

    // Ej. "PERÍODO DEL 17 AL 23 DE AGOSTO DE 2026" (o con los dos meses si la
    // semana cruza de uno a otro), igual al título del Excel original de Tesorería.
    public static String descripcionPeriodo(LocalDate inicio, LocalDate fin) {
        if (inicio == null || fin == null) {
            return "PERÍODO NO DEFINIDO";
        }

        String mesInicio = MESES[inicio.getMonthValue() - 1];
        String mesFin = MESES[fin.getMonthValue() - 1];

        if (inicio.getMonthValue() == fin.getMonthValue() && inicio.getYear() == fin.getYear()) {
            return String.format("PERÍODO DEL %d AL %d DE %s DE %d",
                    inicio.getDayOfMonth(), fin.getDayOfMonth(), mesInicio, inicio.getYear());
        }
        return String.format("PERÍODO DEL %d DE %s AL %d DE %s DE %d",
                inicio.getDayOfMonth(), mesInicio, fin.getDayOfMonth(), mesFin, fin.getYear());
    }

    // Título completo de una línea, como se usa en la lista de "Consultar Flujo de Caja".
    public static String tituloCompleto(LocalDate inicio, LocalDate fin) {
        return "FLUJO DE CAJA SEMANAL - " + descripcionPeriodo(inicio, fin);
    }
}
