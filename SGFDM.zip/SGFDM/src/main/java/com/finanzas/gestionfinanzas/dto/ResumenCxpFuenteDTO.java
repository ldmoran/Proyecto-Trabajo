package com.finanzas.gestionfinanzas.dto;

import java.math.BigDecimal;

// Suma de IMPORTE_A_PAGAR y cantidad de facturas de FC_EGR_CXP_PAGABLE (la
// copia local ya guardada con "Actualizar lista de facturas a pagar") agrupadas
// por FUENTE — PAM = Exploración y Producción, PEC = Gerencias Petroecuador. Ver
// FlujoCajaCxpPagableService.resumenPorFuente.
public class ResumenCxpFuenteDTO {

    private final BigDecimal valor;
    private final long nroProcesos;

    public ResumenCxpFuenteDTO(BigDecimal valor, long nroProcesos) {
        this.valor = valor;
        this.nroProcesos = nroProcesos;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public long getNroProcesos() {
        return nroProcesos;
    }
}
