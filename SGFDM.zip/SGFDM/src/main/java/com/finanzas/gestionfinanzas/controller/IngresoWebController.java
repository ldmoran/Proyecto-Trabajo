package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.dto.CostoLineaIngresoDTO;
import com.finanzas.gestionfinanzas.dto.CuentaConsolidadaDTO;
import com.finanzas.gestionfinanzas.dto.CuentaIngresoDTO;
import com.finanzas.gestionfinanzas.dto.FacturaIngresoDTO;
import com.finanzas.gestionfinanzas.entity.CostoFactura;
import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import com.finanzas.gestionfinanzas.entity.FlujoCajaReporte;
import com.finanzas.gestionfinanzas.entity.TipoCosto;
import com.finanzas.gestionfinanzas.repository.bdd.CostoFacturaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaReporteRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoCostoRepository;
import com.finanzas.gestionfinanzas.service.impl.EnvioEbsService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

// Pantalla de Ingresos (facturas ya Aprobadas) y el envío del consolidado a EBS.
// Antes vivía dentro de FacturaWebController; se separó porque es otro dominio
// (post-aprobación / contabilidad) con sus propias dependencias.
@Controller
public class IngresoWebController {

    private final FacturasBDDRepository facturasBDDRepository;
    private final TipoCostoRepository tipoCostoRepository;
    private final CostoFacturaRepository costoFacturaRepository;
    private final EnvioEbsService envioEbsService;
    private final FlujoCajaReporteRepository flujoCajaReporteRepository;

    public IngresoWebController(FacturasBDDRepository facturasBDDRepository,
                                TipoCostoRepository tipoCostoRepository,
                                CostoFacturaRepository costoFacturaRepository,
                                EnvioEbsService envioEbsService,
                                FlujoCajaReporteRepository flujoCajaReporteRepository) {
        this.facturasBDDRepository = facturasBDDRepository;
        this.tipoCostoRepository = tipoCostoRepository;
        this.costoFacturaRepository = costoFacturaRepository;
        this.envioEbsService = envioEbsService;
        this.flujoCajaReporteRepository = flujoCajaReporteRepository;
    }

    @GetMapping("/ingresos")
    public String verIngresos(@RequestParam(defaultValue = "0") int page,
                              @RequestParam(required = false) String ruc,
                              @RequestParam(required = false) String numFactura,
                              @RequestParam(required = false) String fecEmbarque,
                              @RequestParam(required = false) String fecDeposito,
                              @RequestParam(required = false) String fecFactura,
                              HttpServletRequest request,
                              Model model) {

        // Solo facturas ya Aprobadas ("A"): una vez guardados sus costos, la factura
        // pasa de "Ver distribuciones" a este listado de solo lectura.
        Page<FacturasBDD> facturasPage = facturasBDDRepository.buscar(
                normalizar(ruc),
                normalizar(numFactura),
                normalizar(fecEmbarque),
                normalizar(fecDeposito),
                normalizar(fecFactura),
                "A",
                PageRequest.of(page, 5)
        );

        model.addAttribute("facturasPage", facturasPage);
        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("todosTiposCostoJson", construirTiposCostoJson());

        // Opciones del selector "¿para qué semana es este envío?" de "Enviar a
        // Flujo" — si la semana actual ya tiene su Flujo de Caja firmado (al menos
        // Elaborado), no se deja elegirla, para no sumarle ingresos por detrás a un
        // reporte ya cerrado (ver EnvioEbsService.guardarEnvio).
        LocalDate lunesActual = LocalDate.now().with(WeekFields.of(new Locale("es", "EC")).dayOfWeek(), 1);
        LocalDate lunesSiguiente = lunesActual.plusDays(7);
        model.addAttribute("periodoActualInicio", lunesActual);
        model.addAttribute("periodoActualFin", lunesActual.plusDays(6));
        model.addAttribute("periodoActualBloqueado", estaFirmado(lunesActual));
        model.addAttribute("periodoSiguienteInicio", lunesSiguiente);
        model.addAttribute("periodoSiguienteFin", lunesSiguiente.plusDays(6));

        return "ingresos";
    }

    private boolean estaFirmado(LocalDate fechaInicioPeriodo) {
        Optional<FlujoCajaReporte> reporte = flujoCajaReporteRepository.findByFechaInicio(fechaInicioPeriodo);
        return reporte.isPresent() && (reporte.get().getElaboradoPor() != null || "A".equals(reporte.get().getEstado()));
    }

    @PostMapping("/ingresos/generar")
    public String generarIngreso(@RequestParam(required = false) List<Long> idsFactura, Model model) {
        model.addAttribute("facturasIngreso", construirIngresoPorFactura(idsFactura));
        return "fragments/ingreso-generado :: ingresoGeneradoFragment";
    }

    @PostMapping("/ingresos/preview-envio")
    public String previewEnvioEbs(@RequestParam(required = false) List<Long> idsFactura, Model model) {
        List<CuentaConsolidadaDTO> cuentas = envioEbsService.previsualizarConsolidado(idsFactura);
        double totalGeneral = cuentas.stream().mapToDouble(CuentaConsolidadaDTO::getTotalRecolectado).sum();

        model.addAttribute("cuentasConsolidadas", cuentas);
        model.addAttribute("totalGeneralConsolidado", totalGeneral);
        model.addAttribute("idsFactura", idsFactura);
        model.addAttribute("mostrarGuardar", true);
        return "fragments/envio-ebs-preview :: envioEbsPreviewFragment";
    }

    // Mismo consolidado por cuenta que el preview de "Enviar a EBS", pero solo para
    // mirarlo: no ofrece el botón Guardar, así que sirve para ver el total por cuenta
    // de cualquier selección (incluidas facturas marcadas como no enviar a EBS) sin
    // arriesgarse a mandar nada por accidente.
    @PostMapping("/ingresos/ver-consolidado")
    public String verConsolidado(@RequestParam(required = false) List<Long> idsFactura, Model model) {
        List<CuentaConsolidadaDTO> cuentas = envioEbsService.previsualizarConsolidado(idsFactura);
        double totalGeneral = cuentas.stream().mapToDouble(CuentaConsolidadaDTO::getTotalRecolectado).sum();

        model.addAttribute("cuentasConsolidadas", cuentas);
        model.addAttribute("totalGeneralConsolidado", totalGeneral);
        model.addAttribute("mostrarGuardar", false);
        return "fragments/envio-ebs-preview :: envioEbsPreviewFragment";
    }

    @PostMapping("/ingresos/guardar-envio")
    @ResponseBody
    public ResponseEntity<String> guardarEnvioEbs(@RequestParam(required = false) List<Long> idsFactura,
                                                   @RequestParam(required = false) String periodoDestino) {
        try {
            LocalDate periodo = (periodoDestino != null && !periodoDestino.trim().isEmpty())
                    ? LocalDate.parse(periodoDestino.trim()) : null;
            envioEbsService.guardarEnvio(idsFactura, periodo);
            return ResponseEntity.ok("OK");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage() != null ? e.getMessage() : "No se pudo guardar el envío a EBS");
        }
    }

    // Arma, por cada factura Aprobada seleccionada, el desglose de sus costos
    // agrupados por CUENTA contable (usando el snapshot ya guardado en
    // COSTOS_FACTURA al momento de aprobar, no los valores vigentes de COSTOS).
    private List<FacturaIngresoDTO> construirIngresoPorFactura(List<Long> idsFactura) {
        if (idsFactura == null || idsFactura.isEmpty()) {
            return Collections.emptyList();
        }

        List<CostoFactura> costos = costoFacturaRepository.findConCuentaByFacturaIn(idsFactura);

        Map<Long, String> numFacturaPorId = new LinkedHashMap<>();
        Map<String, String> descripcionPorCuenta = new LinkedHashMap<>();
        Map<Long, Map<String, Map<String, Double>>> acumulado = new LinkedHashMap<>();

        for (CostoFactura cf : costos) {
            if (cf.getFactura() == null || cf.getTipoCosto() == null || cf.getTotal() == null) {
                continue;
            }

            Long idFactura = cf.getFactura().getIdFactura();
            numFacturaPorId.putIfAbsent(idFactura, cf.getFactura().getNumFactura());

            String numeroCuenta = cf.getTipoCosto().getCuenta() != null
                    ? cf.getTipoCosto().getCuenta().getNumeroCuenta()
                    : "Sin cuenta asignada";
            descripcionPorCuenta.putIfAbsent(numeroCuenta,
                    cf.getTipoCosto().getCuenta() != null ? cf.getTipoCosto().getCuenta().getDescripcion() : null);

            acumulado.computeIfAbsent(idFactura, k -> new LinkedHashMap<>())
                    .computeIfAbsent(numeroCuenta, k -> new LinkedHashMap<>())
                    .merge(cf.getTipoCosto().getNombreCosto(), cf.getTotal(), Double::sum);
        }

        List<FacturaIngresoDTO> resultado = new ArrayList<>();
        for (Long idFactura : idsFactura) {
            Map<String, Map<String, Double>> porCuenta = acumulado.get(idFactura);

            List<CuentaIngresoDTO> cuentas = new ArrayList<>();
            double totalFactura = 0;

            if (porCuenta != null) {
                for (Map.Entry<String, Map<String, Double>> entradaCuenta : porCuenta.entrySet()) {
                    List<CostoLineaIngresoDTO> lineas = new ArrayList<>();
                    double subtotal = 0;

                    for (Map.Entry<String, Double> linea : entradaCuenta.getValue().entrySet()) {
                        lineas.add(new CostoLineaIngresoDTO(linea.getKey(), linea.getValue()));
                        subtotal += linea.getValue();
                    }

                    cuentas.add(new CuentaIngresoDTO(entradaCuenta.getKey(), descripcionPorCuenta.get(entradaCuenta.getKey()), lineas, subtotal));
                    totalFactura += subtotal;
                }
            }

            String numFactura = numFacturaPorId.get(idFactura);
            if (numFactura == null) {
                numFactura = facturasBDDRepository.findById(idFactura).map(FacturasBDD::getNumFactura).orElse("-");
            }

            resultado.add(new FacturaIngresoDTO(idFactura, numFactura, cuentas, totalFactura));
        }

        return resultado;
    }

    // Mismo criterio de listado que usa Facturas (facturas-web / facturas-distribuciones):
    // el combo de tipos de costo del filtro sale del catálogo completo.
    private List<Map<String, Object>> construirTiposCostoJson() {
        List<Map<String, Object>> resultado = new ArrayList<>();

        for (TipoCosto tc : tipoCostoRepository.findAllConCrudo()) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", tc.getIdTipoCosto());
            item.put("nombre", tc.getNombreCosto());
            item.put("idCrudo", tc.getCrudo() != null ? tc.getCrudo().getIdCrudo() : null);
            item.put("entidad", tc.getCrudoEntidad() != null ? tc.getCrudoEntidad().getNombreGrupo() : null);
            resultado.add(item);
        }

        return resultado;
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }

        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }
}
