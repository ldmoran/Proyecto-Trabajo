package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

// Catálogo de Gerencias para Provisiones (jerarquía Gerencia -> Área ->
// Concepto de Provisión) — distinto de GRUPO_PAGO_GERENCIA, que es solo un
// mapeo de etiquetas para Cuentas por Pagar, un concepto no relacionado.
@Entity
@Table(name = "PROVISION_GERENCIA")
public class ProvisionGerencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_GERENCIA")
    private Long idGerencia;

    @Column(name = "NOMBRE_GERENCIA")
    private String nombreGerencia;

    @Column(name = "ESTADO")
    private String estado;

    public Long getIdGerencia() { return idGerencia; }
    public void setIdGerencia(Long idGerencia) { this.idGerencia = idGerencia; }

    public String getNombreGerencia() { return nombreGerencia; }
    public void setNombreGerencia(String nombreGerencia) { this.nombreGerencia = nombreGerencia; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
