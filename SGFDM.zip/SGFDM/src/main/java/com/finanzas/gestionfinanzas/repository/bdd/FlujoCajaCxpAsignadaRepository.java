package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaCxpAsignada;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FlujoCajaCxpAsignadaRepository extends JpaRepository<FlujoCajaCxpAsignada, Long> {

    // Todas las facturas ya comprometidas por CUALQUIER reporte — se usa cuando
    // el reporte que se está armando todavía no tiene ID (nunca se guardó).
    @Query("SELECT a.invoiceId FROM FlujoCajaCxpAsignada a")
    List<Long> obtenerTodosLosInvoiceIds();

    // Facturas comprometidas por OTROS reportes (no el que se está armando ahora):
    // el propio reporte no se excluye a sí mismo si se recalcula.
    @Query("SELECT a.invoiceId FROM FlujoCajaCxpAsignada a WHERE a.idReporte <> :idReporte")
    List<Long> obtenerInvoiceIdsDeOtrosReportes(@Param("idReporte") Long idReporte);
}
