package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

// Catálogo de consorcios para "Información Consorcios" de Flujo de Caja >
// Egresos (ver FlujoCajaConsorcio, que es lo que se guarda por reporte).
@Entity
@Table(name = "FC_EGR_CONSORCIO_CAT")
public class ConsorcioCatalogo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CONSORCIO")
    private Long idConsorcio;

    @Column(name = "NOMBRE_CONSORCIO")
    private String nombreConsorcio;

    @Column(name = "ESTADO")
    private String estado;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdConsorcio() { return idConsorcio; }
    public void setIdConsorcio(Long idConsorcio) { this.idConsorcio = idConsorcio; }

    public String getNombreConsorcio() { return nombreConsorcio; }
    public void setNombreConsorcio(String nombreConsorcio) { this.nombreConsorcio = nombreConsorcio; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}
