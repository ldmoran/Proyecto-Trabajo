package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.FlujoCajaReporte;
import com.finanzas.gestionfinanzas.entity.FlujoCajaResponsable;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaResponsableRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.internet.MimeMessage;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

// Avisa por correo a quien le toca firmar la siguiente etapa de un reporte de
// Flujo de Caja: al marcar Elaborado se avisa a los Aprobadores, al marcar
// Aprobado se avisa a los Autorizadores (ver FlujoCajaReporteService). Los
// destinatarios salen de FC_RESPONSABLE (ver [[Mantenimiento >
// Responsables Flujo de Caja]]) porque el servicio de seguridad institucional
// todavía no tiene un rol propio para esta cadena de firmas.
//
// Nunca lanza una excepción hacia el que llama: un correo que no sale no debe
// tumbar la firma, que ya quedó guardada en la base antes de intentar avisar.
@Service
public class FlujoCajaNotificacionService {

    private static final Logger log = LoggerFactory.getLogger(FlujoCajaNotificacionService.class);

    private final JavaMailSender mailSender;
    private final FlujoCajaResponsableRepository responsableRepository;

    @Value("${app.mail.remitente}")
    private String remitente;

    @Value("${app.mail.nombreRemitente}")
    private String nombreRemitente;

    @Value("${app.base-url}")
    private String baseUrl;

    // Mismo logo horizontal que ya usa el header de la app (ver fragments/header.html),
    // mandado como adjunto "inline" (Content-ID) en vez de base64 en el <img src>:
    // varios clientes de correo corporativos (Outlook sobre todo) bloquean o no
    // renderizan imágenes en base64 dentro del HTML.
    private static final String LOGO_CID = "logoEpp";
    private final Resource logo = new ClassPathResource("static/images/logo_horizontal.png");

    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy", new Locale("es", "EC"));

    public FlujoCajaNotificacionService(JavaMailSender mailSender, FlujoCajaResponsableRepository responsableRepository) {
        this.mailSender = mailSender;
        this.responsableRepository = responsableRepository;
    }

    public void avisarAprobadores(FlujoCajaReporte reporte) {
        enviarAviso(reporte, responsableRepository.findByEsAprobador("S"), "aprobación");
    }

    public void avisarAutorizadores(FlujoCajaReporte reporte) {
        enviarAviso(reporte, responsableRepository.findByEsAutorizador("S"), "autorización");
    }

    // Paso previo liviano (sin certificado), antes de las 3 firmas reales — ver
    // FlujoCajaReporteService.revisarProceso. Mismos destinatarios (Aprobador)
    // que avisarAprobadores, pero avisando que el reporte quedó Revisado y
    // está listo para su aprobación, no de la firma real.
    public void avisarRevision(FlujoCajaReporte reporte) {
        enviarAviso(reporte, responsableRepository.findByEsAprobador("S"), "revisión");
    }

    // Se llama SOLO cuando el proceso queda Aprobado (ver
    // FlujoCajaReporteService.aprobarProceso): recién ahí tiene sentido
    // avisarle al Elaborador que ya puede firmar Elaborado de verdad.
    public void avisarElaboradores(FlujoCajaReporte reporte) {
        enviarAviso(reporte, responsableRepository.findByEsElaborador("S"), "firma de Elaborado (el reporte ya está Aprobado)");
    }

    private void enviarAviso(FlujoCajaReporte reporte, List<FlujoCajaResponsable> responsables, String accion) {
        for (FlujoCajaResponsable responsable : responsables) {
            if (responsable.getUsuario() == null) {
                continue;
            }
            String destinatario = responsable.getUsuario().getEmail();
            if (destinatario == null || destinatario.trim().isEmpty()) {
                continue;
            }
            String nombre = responsable.getUsuario().getNombreCompleto();
            try {
                enviarCorreo(destinatario, nombre, reporte, accion);
            } catch (Exception e) {
                log.error("No se pudo enviar el aviso de Flujo de Caja (idReporte={}) a {}", reporte.getIdReporte(), destinatario, e);
            }
        }
    }

    // accion siempre viene en sustantivo ("aprobación"/"autorización") para que
    // el texto quede gramaticalmente bien sin tener que conjugar un verbo
    // ("listo para su aprobación", nunca "listo para lo aprobar").
    private void enviarCorreo(String destinatario, String nombreDestinatario, FlujoCajaReporte reporte, String accion) throws Exception {
        MimeMessage mensaje = mailSender.createMimeMessage();
        // "true" = multipart, necesario para poder adjuntar el logo inline (cid)
        MimeMessageHelper helper = new MimeMessageHelper(mensaje, true, "UTF-8");
        helper.setFrom(remitente, nombreRemitente);
        helper.setTo(destinatario);
        helper.setSubject("Flujo de Caja Semanal — pendiente de " + accion);

        String link = baseUrl + "/flujo-caja/semana?fechaInicio=" + reporte.getFechaInicio();
        String periodo = FORMATO_FECHA.format(reporte.getFechaInicio()) + " al " + FORMATO_FECHA.format(reporte.getFechaFin());

        helper.setText(construirHtml(nombreDestinatario, periodo, accion, link), true);
        if (logo.exists()) {
            helper.addInline(LOGO_CID, logo);
        } else {
            // Si esto sale en el log, el correo se mandó SIN logo porque el .png no
            // se encontró en el classpath del deploy (revisar que static/images/logo.png
            // haya quedado empaquetado dentro del WAR, en WEB-INF/classes/static/images/).
            log.warn("No se encontró static/images/logo.png en el classpath: el correo de Flujo de Caja se mandó sin logo.");
        }

        mailSender.send(mensaje);
    }

    // Tabla en vez de flexbox/grid a propósito: es lo único que Outlook de
    // escritorio (motor de renderizado de Word) respeta de forma confiable en
    // un correo HTML. Misma paleta que el PDF del reporte (ver flujo-caja-pdf.html)
    // para que se sienta parte del mismo sistema. El logo es el mismo que ya usa
    // el header de la app (static/images/logo_horizontal.png) — no uno bajado de
    // internet, para no meter un sello sin poder garantizar que sea el real.
    private String construirHtml(String nombreDestinatario, String periodo, String accion, String link) {
        String saludo = (nombreDestinatario != null && !nombreDestinatario.trim().isEmpty())
                ? "Estimado/a <strong>" + nombreDestinatario + "</strong>,"
                : "Estimado/a,";

        return "<table role=\"presentation\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#eef2f5;padding:24px 0;font-family:Arial,Helvetica,sans-serif;\">"
            + "<tr><td align=\"center\">"
            + "<table role=\"presentation\" width=\"560\" cellpadding=\"0\" cellspacing=\"0\" style=\"background:#ffffff;border-radius:10px;overflow:hidden;border:1px solid #d8e0e6;\">"

            // Header: mismo azul que la barra de arriba de la app (.top-navbar en
            // base.css, #00527B — cabecera de la normalización EP Petroecuador),
            // para que el correo se sienta parte del mismo sistema.
            + "<tr><td style=\"background:#00527B;padding:22px 28px;\">"
            + "<table role=\"presentation\" cellpadding=\"0\" cellspacing=\"0\"><tr>"
            + "<td><img src=\"cid:" + LOGO_CID + "\" alt=\"EP Petroecuador\" height=\"28\" style=\"display:block;\"></td>"
            + "<td style=\"padding-left:16px;border-left:1px solid rgba(255,255,255,0.35);\">"
            + "<span style=\"display:inline-block;padding-left:16px;color:#ffffff;font-size:16px;font-weight:bold;vertical-align:middle;\">Sistema de Gesti&oacute;n de Finanzas</span>"
            + "</td>"
            + "</tr></table>"
            + "</td></tr>"

            // Franja de color con el título de la acción
            + "<tr><td style=\"background:#006699;padding:14px 28px;\">"
            + "<span style=\"color:#ffffff;font-size:15px;font-weight:bold;text-transform:capitalize;\">Flujo de Caja Semanal &mdash; pendiente de " + accion + "</span>"
            + "</td></tr>"

            // Cuerpo
            + "<tr><td style=\"padding:28px;color:#1a1a1a;font-size:14px;line-height:1.6;\">"
            + "<p style=\"margin:0 0 14px 0;\">" + saludo + "</p>"
            + "<p style=\"margin:0 0 16px 0;\">Se registró el reporte de <strong>Flujo de Caja Semanal</strong> "
            + "correspondiente al período <strong>" + periodo + "</strong> y se encuentra listo para su <strong>" + accion + "</strong>.</p>"

            + "<table role=\"presentation\" cellpadding=\"0\" cellspacing=\"0\" style=\"margin:8px 0 20px 0;\">"
            + "<tr><td style=\"background:#006699;border-radius:6px;\">"
            + "<a href=\"" + link + "\" style=\"display:inline-block;padding:11px 22px;color:#ffffff;font-size:14px;font-weight:bold;text-decoration:none;\">"
            + "Ir al reporte</a>"
            + "</td></tr>"
            + "</table>"

            + "<p style=\"margin:0;color:#5a6b74;font-size:12.5px;\">Si el botón no funciona, copiá y pegá este link en el navegador:<br>"
            + "<a href=\"" + link + "\" style=\"color:#006699;\">" + link + "</a></p>"
            + "</td></tr>"

            // Footer
            + "<tr><td style=\"padding:16px 28px;border-top:1px solid #e0e6ea;\">"
            + "<span style=\"color:#97a3aa;font-size:11.5px;\">Correo generado automáticamente por el Sistema de Gestión de Finanzas &mdash; EP Petroecuador. No respondas a este mensaje.</span>"
            + "</td></tr>"

            + "</table>"
            + "</td></tr>"
            + "</table>";
    }
}
