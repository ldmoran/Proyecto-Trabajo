package com.finanzas.gestionfinanzas.dto;

import java.util.List;

// Datos de los 3 gráficos de "Actividad" en el dashboard (ver AuthController),
// acotados a una ventana (última semana / último mes) para no tener que barrer
// todo el historial de FACTURAS cada vez que alguien abre la pantalla.
public class EstadisticasDashboardDTO {

    private final List<String> dias;
    private final List<Integer> cantidades;
    private final int[] estadoConteos;
    // "DIA" (Semana/Mes) o "MES" (Año/Todo) — para que el frontend sepa cómo
    // rotular el gráfico de picos sin tener que adivinarlo del tipo elegido.
    private final String granularidad;

    public EstadisticasDashboardDTO(List<String> dias, List<Integer> cantidades, int[] estadoConteos, String granularidad) {
        this.dias = dias;
        this.cantidades = cantidades;
        this.estadoConteos = estadoConteos;
        this.granularidad = granularidad;
    }

    public List<String> getDias() {
        return dias;
    }

    public List<Integer> getCantidades() {
        return cantidades;
    }

    public int[] getEstadoConteos() {
        return estadoConteos;
    }

    public String getGranularidad() {
        return granularidad;
    }
}
