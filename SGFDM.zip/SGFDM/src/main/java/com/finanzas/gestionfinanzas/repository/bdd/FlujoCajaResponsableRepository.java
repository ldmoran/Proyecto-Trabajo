package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaResponsable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FlujoCajaResponsableRepository extends JpaRepository<FlujoCajaResponsable, Long> {

    Optional<FlujoCajaResponsable> findByUsuario_IdUsuario(Long idUsuario);

    List<FlujoCajaResponsable> findByEsElaborador(String esElaborador);

    List<FlujoCajaResponsable> findByEsAprobador(String esAprobador);

    List<FlujoCajaResponsable> findByEsAutorizador(String esAutorizador);
}
