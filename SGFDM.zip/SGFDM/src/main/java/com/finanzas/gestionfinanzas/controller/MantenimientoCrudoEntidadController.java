package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.CrudoEntidad;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoEntidadRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoCostoRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/mantenimiento/entidades")
public class MantenimientoCrudoEntidadController {

    private final CrudoEntidadRepository crudoEntidadRepository;
    private final TipoCostoRepository tipoCostoRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoCrudoEntidadController(CrudoEntidadRepository crudoEntidadRepository,
                                               TipoCostoRepository tipoCostoRepository,
                                               AuditoriaSessionService auditoriaSessionService) {
        this.crudoEntidadRepository = crudoEntidadRepository;
        this.tipoCostoRepository = tipoCostoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) String nombre,
                         @RequestParam(required = false) String estado,
                         HttpServletRequest request, Model model) {
        Page<CrudoEntidad> entidadesPage =
                crudoEntidadRepository.buscar(normalizar(nombre), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("entidadesPage", entidadesPage);
        model.addAttribute("nombre", nombre);
        model.addAttribute("estado", estado);
        return "mantenimiento/entidades";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idGrupo,
                          @RequestParam String nombreGrupo,
                          @RequestParam String estado,
                          RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        boolean esNueva = idGrupo == null;
        CrudoEntidad crudoEntidad = !esNueva
                ? crudoEntidadRepository.findById(idGrupo).orElseThrow(() -> new RuntimeException("Entidad no encontrada"))
                : new CrudoEntidad();

        crudoEntidad.setNombreGrupo(nombreGrupo.trim());
        crudoEntidad.setEstado(estado);

        crudoEntidadRepository.save(crudoEntidad);
        auditoriaSessionService.registrarComentario("CRUDO_ENTIDAD", crudoEntidad.getIdGrupo(),
                esNueva ? "INSERT" : "UPDATE",
                (esNueva ? "Creó" : "Editó") + " la entidad " + crudoEntidad.getNombreGrupo() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/entidades";
    }

    @PostMapping("/eliminar/{idGrupo}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idGrupo, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        if (tipoCostoRepository.existsByCrudoEntidad_IdGrupo(idGrupo)) {
            redirectAttributes.addFlashAttribute("error",
                    "Esta entidad tiene tipos de costo asociados, no se puede eliminar");
            return "redirect:/mantenimiento/entidades";
        }

        String nombreEliminada = crudoEntidadRepository.findById(idGrupo).map(CrudoEntidad::getNombreGrupo).orElse("(desconocida)");
        try {
            crudoEntidadRepository.deleteById(idGrupo);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados");
            return "redirect:/mantenimiento/entidades";
        }
        auditoriaSessionService.registrarComentario("CRUDO_ENTIDAD", idGrupo, "DELETE",
                "Eliminó la entidad " + nombreEliminada + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/entidades";
    }
}
