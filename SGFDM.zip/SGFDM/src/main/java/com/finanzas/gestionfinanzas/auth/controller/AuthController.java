package com.finanzas.gestionfinanzas.auth.controller;

import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.config.AppProperties;
import com.finanzas.gestionfinanzas.dto.EstadisticasDashboardDTO;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;
import com.finanzas.gestionfinanzas.service.impl.PendienteFirmaService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class AuthController {
    private final AppProperties appProperties;
    private final FacturasBDDRepository facturasBDDRepository;
    private final PendienteFirmaService pendienteFirmaService;

    public AuthController(AppProperties appProperties, FacturasBDDRepository facturasBDDRepository,
                           PendienteFirmaService pendienteFirmaService) {
        this.appProperties = appProperties;
        this.facturasBDDRepository = facturasBDDRepository;
        this.pendienteFirmaService = pendienteFirmaService;
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("cipherClave", appProperties.getSeguridad().getCipherClave());
        model.addAttribute("cipherVector", appProperties.getSeguridad().getCipherVector());
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpServletRequest request,
                            Model model,
                            @AuthenticationPrincipal AuthResponseDTO user) {
        model.addAttribute("nombre", user.getNombre());

        // 👉 Aquí pasamos el path actual para que el menú no explote
        model.addAttribute("path", request.getRequestURI());

        EstadisticasDashboardDTO stats = construirEstadisticas("MES", null, null, null);
        model.addAttribute("diasAprobadas", stats.getDias());
        model.addAttribute("cantidadesAprobadas", stats.getCantidades());
        model.addAttribute("estadoConteos", stats.getEstadoConteos());
        model.addAttribute("pendientesFirma", pendienteFirmaService.obtenerPendientes(user.getUsuario()));

        return "dashboard";
    }

    // AJAX del selector de la sección Actividad (ver dashboard.html): repinta los 3
    // gráficos sin recargar toda la página. tipo=SEMANA usa fecha (cualquier día de
    // esa semana, yyyy-MM-dd); tipo=MES usa mes (yyyy-MM); tipo=ANIO usa anio;
    // tipo=TODO no necesita ningún parámetro extra (todo el historial).
    @GetMapping("/dashboard/estadisticas")
    @ResponseBody
    public EstadisticasDashboardDTO estadisticas(@RequestParam(defaultValue = "MES") String tipo,
                                                  @RequestParam(required = false) String fecha,
                                                  @RequestParam(required = false) String mes,
                                                  @RequestParam(required = false) Integer anio) {
        return construirEstadisticas(tipo, fecha, mes, anio);
    }

    // Acotado a propósito según lo que elija el usuario (ver
    // FacturasBDDRepository.contarAprobadasPorDiaEnRango/PorMesEnRango): Semana/Mes
    // se grafican por día, Año/Todo por mes (con años de historial, un punto por día
    // sería ilegible y la consulta más pesada). "Todo el historial" es la única
    // opción que de verdad recorre toda la tabla — el resto siempre queda acotado a
    // un rango chico, para que la pantalla no se vuelva lenta con el tiempo.
    private EstadisticasDashboardDTO construirEstadisticas(String tipo, String fechaStr, String mesStr, Integer anio) {
        LocalDate desde;
        LocalDate hasta;
        boolean porMes;

        String tipoNormalizado = tipo == null ? "MES" : tipo.toUpperCase();
        switch (tipoNormalizado) {
            case "SEMANA": {
                LocalDate base = parsearFecha(fechaStr, LocalDate.now());
                desde = base.with(WeekFields.of(new Locale("es", "EC")).dayOfWeek(), 1);
                hasta = desde.plusDays(6);
                porMes = false;
                break;
            }
            case "ANIO": {
                int anioElegido = anio != null ? anio : LocalDate.now().getYear();
                desde = LocalDate.of(anioElegido, 1, 1);
                hasta = LocalDate.of(anioElegido, 12, 31);
                porMes = true;
                break;
            }
            case "TODO": {
                desde = null;
                hasta = null;
                porMes = true;
                break;
            }
            case "MES":
            default: {
                YearMonth mesElegido = parsearMes(mesStr, YearMonth.now());
                desde = mesElegido.atDay(1);
                hasta = mesElegido.atEndOfMonth();
                porMes = false;
            }
        }

        List<String> dias;
        List<Integer> cantidades;
        if (porMes) {
            Map<YearMonth, Integer> serie = serieAprobadasPorMes(desde, hasta);
            dias = serie.keySet().stream()
                    .map(m -> m.format(DateTimeFormatter.ofPattern("MM/yyyy")))
                    .collect(Collectors.toList());
            cantidades = new ArrayList<>(serie.values());
        } else {
            Map<LocalDate, Integer> serie = serieAprobadasPorDia(desde, hasta);
            dias = serie.keySet().stream()
                    .map(d -> d.format(DateTimeFormatter.ofPattern("dd/MM")))
                    .collect(Collectors.toList());
            cantidades = new ArrayList<>(serie.values());
        }

        int[] estadoConteos = contarPorEstado(desde, hasta);

        return new EstadisticasDashboardDTO(dias, cantidades, estadoConteos, porMes ? "MES" : "DIA");
    }

    private LocalDate parsearFecha(String valor, LocalDate porDefecto) {
        if (valor == null || valor.trim().isEmpty()) {
            return porDefecto;
        }
        try {
            return LocalDate.parse(valor);
        } catch (Exception e) {
            return porDefecto;
        }
    }

    private YearMonth parsearMes(String valor, YearMonth porDefecto) {
        if (valor == null || valor.trim().isEmpty()) {
            return porDefecto;
        }
        try {
            return YearMonth.parse(valor);
        } catch (Exception e) {
            return porDefecto;
        }
    }

    // 0 en los días sin ninguna Aprobada, para que el gráfico muestre el hueco real
    // en vez de comprimirlo. desde/hasta siempre vienen no-nulos acá (Semana/Mes).
    private Map<LocalDate, Integer> serieAprobadasPorDia(LocalDate desde, LocalDate hasta) {
        Map<LocalDate, Integer> serie = new LinkedHashMap<>();
        for (LocalDate dia = desde; !dia.isAfter(hasta); dia = dia.plusDays(1)) {
            serie.put(dia, 0);
        }

        for (Object[] fila : facturasBDDRepository.contarAprobadasPorDiaEnRango(desde, hasta)) {
            LocalDate dia = aLocalDate(fila[0]);
            if (dia != null && serie.containsKey(dia)) {
                serie.put(dia, ((Number) fila[1]).intValue());
            }
        }

        return serie;
    }

    // Igual que serieAprobadasPorDia pero por mes. Para "Todo el historial"
    // (desde/hasta NULL) no se rellenan meses en cero de antemano — no hay forma de
    // saber desde cuándo hay datos sin otra consulta aparte, así que el gráfico
    // simplemente no dibuja los meses sin ninguna Aprobada.
    private Map<YearMonth, Integer> serieAprobadasPorMes(LocalDate desde, LocalDate hasta) {
        Map<YearMonth, Integer> serie = new LinkedHashMap<>();
        if (desde != null && hasta != null) {
            for (YearMonth mes = YearMonth.from(desde); !mes.isAfter(YearMonth.from(hasta)); mes = mes.plusMonths(1)) {
                serie.put(mes, 0);
            }
        }

        for (Object[] fila : facturasBDDRepository.contarAprobadasPorMesEnRango(desde, hasta)) {
            LocalDate inicioMes = aLocalDate(fila[0]);
            if (inicioMes != null) {
                serie.merge(YearMonth.from(inicioMes), ((Number) fila[1]).intValue(), Integer::sum);
            }
        }

        return serie;
    }

    private LocalDate aLocalDate(Object valor) {
        if (valor instanceof Timestamp) {
            return ((Timestamp) valor).toLocalDateTime().toLocalDate();
        }
        if (valor instanceof java.sql.Date) {
            return ((java.sql.Date) valor).toLocalDate();
        }
        return null;
    }

    // [0]=Pendientes (Registradas), [1]=Aprobadas enviables a EBS, [2]=Aprobadas
    // excluidas de EBS por destiempo, acotado al mismo rango del gráfico de picos
    // (desde/hasta NULL = todo el historial). SUM(...) siempre trae una fila (con
    // NULL si no hay nada en el rango), por eso el chequeo de null.
    private int[] contarPorEstado(LocalDate desde, LocalDate hasta) {
        List<Object[]> filas = facturasBDDRepository.contarPorEstadoEnRango(desde, hasta);
        if (filas.isEmpty() || filas.get(0)[0] == null) {
            return new int[]{0, 0, 0};
        }

        Object[] fila = filas.get(0);
        return new int[]{
                ((Number) fila[0]).intValue(),
                ((Number) fila[1]).intValue(),
                ((Number) fila[2]).intValue()
        };
    }
}
