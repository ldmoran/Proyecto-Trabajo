package com.finanzas.gestionfinanzas.auth.enums;

// Código con el que el servicio de seguridad institucional identifica a este
// sistema. Debe coincidir con el 'codigo' que llega en listaAplicacion.
public enum AppEnum {
    GFING
}
