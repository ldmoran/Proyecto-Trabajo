package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "FC_EGR_TRANSFERENCIA")
public class FlujoCajaTransferencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_TRANSFERENCIA")
    private Long idTransferencia;

    @ManyToOne
    @JoinColumn(name = "ID_REPORTE")
    private FlujoCajaReporte reporte;

    // Antes había columnas TIPO/DESCRIPCION propias (un solo valor con texto
    // libre por sección); ahora cada fila es un concepto elegido de
    // FC_EGR_CONCEPTO_TRANSF, así que una misma sección (SRI/SHAYA_BOC2/HEDGE)
    // puede tener varias filas. getTipo()/getDescripcion() quedan como
    // métodos derivados (delegan al concepto) para no tener que tocar el PDF,
    // el Excel ni la pantalla combinada vieja, que solo los LEEN.
    @ManyToOne
    @JoinColumn(name = "ID_CONCEPTO")
    private ConceptoTransferencia concepto;

    @Column(name = "VALOR")
    private BigDecimal valor;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdTransferencia() { return idTransferencia; }
    public void setIdTransferencia(Long idTransferencia) { this.idTransferencia = idTransferencia; }

    public FlujoCajaReporte getReporte() { return reporte; }
    public void setReporte(FlujoCajaReporte reporte) { this.reporte = reporte; }

    public ConceptoTransferencia getConcepto() { return concepto; }
    public void setConcepto(ConceptoTransferencia concepto) { this.concepto = concepto; }

    public String getTipo() { return concepto != null ? concepto.getTipo() : null; }

    public String getDescripcion() { return concepto != null ? concepto.getNombreConcepto() : null; }

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}