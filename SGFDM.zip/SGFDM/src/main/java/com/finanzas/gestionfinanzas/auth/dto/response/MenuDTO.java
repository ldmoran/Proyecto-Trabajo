package com.finanzas.gestionfinanzas.auth.dto.response;

public class MenuDTO {
    private String id;
    private String nombre;
    private String idAplicacion;

    public MenuDTO() {
    }

    public MenuDTO(String id, String nombre, String idAplicacion) {
        this.id = id;
        this.nombre = nombre;
        this.idAplicacion = idAplicacion;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIdAplicacion() {
        return idAplicacion;
    }

    public void setIdAplicacion(String idAplicacion) {
        this.idAplicacion = idAplicacion;
    }
}
