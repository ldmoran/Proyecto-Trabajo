package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.ConceptoIngreso;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ConceptoIngresoRepository extends JpaRepository<ConceptoIngreso, Long> {
    List<ConceptoIngreso> findByEstadoOrderByNombreConcepto(String estado);

    @Query("SELECT c FROM ConceptoIngreso c " +
            "WHERE (:nombre IS NULL OR UPPER(c.nombreConcepto) LIKE UPPER(CONCAT('%', :nombre, '%'))) " +
            "AND (:estado IS NULL OR c.estado = :estado) " +
            "ORDER BY c.nombreConcepto")
    Page<ConceptoIngreso> buscar(@Param("nombre") String nombre, @Param("estado") String estado, Pageable pageable);
}