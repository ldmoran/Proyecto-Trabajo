package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.CategoriaEgreso;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CategoriaEgresoRepository extends JpaRepository<CategoriaEgreso, Long> {
    List<CategoriaEgreso> findByEstadoOrderByNombreCategoria(String estado);

    @Query("SELECT c FROM CategoriaEgreso c " +
            "WHERE (:nombre IS NULL OR UPPER(c.nombreCategoria) LIKE UPPER(CONCAT('%', :nombre, '%'))) " +
            "AND (:estado IS NULL OR c.estado = :estado) " +
            "ORDER BY c.nombreCategoria")
    Page<CategoriaEgreso> buscar(@Param("nombre") String nombre, @Param("estado") String estado, Pageable pageable);
}