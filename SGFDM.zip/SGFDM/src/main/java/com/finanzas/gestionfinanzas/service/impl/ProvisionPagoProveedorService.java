package com.finanzas.gestionfinanzas.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

// Lectura cruda de pagos a proveedores del ERP (vista
// APPS.XXOCS_AP_CXP_PAGOS_PROV_V, datasource "primary", misma base que
// APPS.XXOCS_AP_CXP_CONS_V). Es lo que elige el usuario en Provisiones al
// marcar Anterior/Mixto (ver ProvisionRegistroService.crearAnteriorOMixto).
//
// SQL nativo directo en vez de mapear una @Entity completa para la vista,
// mismo patrón que EgresoCxpService.
@Service
public class ProvisionPagoProveedorService {

    // Fechas como texto ISO (TO_CHAR) para no lidiar con conversión de tipos
    // Oracle DATE -> Java en un resultado nativo de columnas sueltas.
    private static final String SQL_PAGOS =
            "SELECT VENDOR_NAME, RUC, DOCUMENTO, MONTO_PAGADO, DESCRIPCION, " +
            "       TO_CHAR(FECHA_PAGO, 'YYYY-MM-DD') AS FECHA_PAGO_STR " +
            "FROM APPS.XXOCS_AP_CXP_PAGOS_PROV_V " +
            "ORDER BY FECHA_PAGO DESC";

    @PersistenceContext(unitName = "primary")
    private EntityManager entityManager;

    // Fila: [0]=VENDOR_NAME, [1]=RUC, [2]=DOCUMENTO, [3]=MONTO_PAGADO,
    // [4]=DESCRIPCION, [5]=FECHA_PAGO_STR (yyyy-MM-dd).
    @Transactional("primaryTransactionManager")
    public List<Object[]> obtenerPagos() {
        @SuppressWarnings("unchecked")
        List<Object[]> filas = entityManager.createNativeQuery(SQL_PAGOS).getResultList();
        return filas;
    }
}
