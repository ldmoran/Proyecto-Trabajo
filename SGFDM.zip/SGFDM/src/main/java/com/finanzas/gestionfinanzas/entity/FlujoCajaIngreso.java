package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "FC_ING_RECIBIR")
public class FlujoCajaIngreso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_FLUJO_INGRESO")
    private Long idFlujoIngreso;

    @ManyToOne
    @JoinColumn(name = "ID_REPORTE")
    private FlujoCajaReporte reporte;

    @ManyToOne
    @JoinColumn(name = "ID_CONCEPTO")
    private ConceptoIngreso concepto;

    @Column(name = "VALOR")
    private BigDecimal valor;

    @Column(name = "TIPO_CAPTURA")
    private String tipoCaptura;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdFlujoIngreso() { return idFlujoIngreso; }
    public void setIdFlujoIngreso(Long idFlujoIngreso) { this.idFlujoIngreso = idFlujoIngreso; }

    public FlujoCajaReporte getReporte() { return reporte; }
    public void setReporte(FlujoCajaReporte reporte) { this.reporte = reporte; }

    public ConceptoIngreso getConcepto() { return concepto; }
    public void setConcepto(ConceptoIngreso concepto) { this.concepto = concepto; }

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }

    public String getTipoCaptura() { return tipoCaptura; }
    public void setTipoCaptura(String tipoCaptura) { this.tipoCaptura = tipoCaptura; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}