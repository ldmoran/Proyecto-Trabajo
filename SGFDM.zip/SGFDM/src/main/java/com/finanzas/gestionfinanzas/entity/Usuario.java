package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

// Ficha local de las personas que han entrado al sistema. Los usuarios viven en el
// LDAP institucional; aquí solo se guarda una copia de los datos que el servicio de
// seguridad devuelve al autenticarse, para poder consultarlos después desde
// Auditoría sin volver a llamar al servicio externo.
@Entity
@Table(name = "USUARIOS")
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_USUARIO")
    private Long idUsuario;

    @Column(name = "USUARIO")
    private String usuario;

    @Column(name = "NOMBRE_COMPLETO")
    private String nombreCompleto;

    @Column(name = "CEDULA")
    private String cedula;

    @Column(name = "EMAIL")
    private String email;

    // Identificador de la persona en el sistema de seguridad institucional.
    @Column(name = "ID_EXTERNO")
    private String idExterno;

    @Column(name = "FECHA_PRIMER_ACCESO")
    private LocalDateTime fechaPrimerAcceso;

    @Column(name = "FECHA_ULTIMO_ACCESO")
    private LocalDateTime fechaUltimoAcceso;

    @Column(name = "TOTAL_ACCESOS")
    private Integer totalAccesos;

    public Long getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Long idUsuario) { this.idUsuario = idUsuario; }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getIdExterno() { return idExterno; }
    public void setIdExterno(String idExterno) { this.idExterno = idExterno; }

    public LocalDateTime getFechaPrimerAcceso() { return fechaPrimerAcceso; }
    public void setFechaPrimerAcceso(LocalDateTime fechaPrimerAcceso) { this.fechaPrimerAcceso = fechaPrimerAcceso; }

    public LocalDateTime getFechaUltimoAcceso() { return fechaUltimoAcceso; }
    public void setFechaUltimoAcceso(LocalDateTime fechaUltimoAcceso) { this.fechaUltimoAcceso = fechaUltimoAcceso; }

    public Integer getTotalAccesos() { return totalAccesos; }
    public void setTotalAccesos(Integer totalAccesos) { this.totalAccesos = totalAccesos; }
}
