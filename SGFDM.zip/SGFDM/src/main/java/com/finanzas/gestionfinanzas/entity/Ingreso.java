package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;
import javax.persistence.Transient;


@Entity
@Table(name = "INGRESOS")

public class Ingreso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_INGRESO")
    private Long idIngreso;

    @ManyToOne
    @JoinColumn(name = "ID_DETALLE")
    private DetalleDistribucion detalleDistribucion;

    @ManyToOne
    @JoinColumn(name = "ID_TIPO_COSTO")
    private TipoCosto tipoCosto;

    // Solo para MEM/Ministerio, donde no se conoce el costo unitario: el usuario
    // teclea el total de este costo y se usa tal cual en vez de VALOR x VOLUMEN.
    // Si es null, el costo se calcula normal con el valor del catálogo COSTOS.
    @Column(name = "TOTAL_MANUAL")
    private Double totalManual;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    // Campo temporal para mostrar el valor
    @Transient
    private Double valorTemporal;

    public Long getIdIngreso() { return idIngreso; }
    public void setIdIngreso(Long idIngreso) { this.idIngreso = idIngreso; }

    public DetalleDistribucion getDetalleDistribucion() { return detalleDistribucion; }
    public void setDetalleDistribucion(DetalleDistribucion detalleDistribucion) { this.detalleDistribucion = detalleDistribucion; }

    public TipoCosto getTipoCosto() { return tipoCosto; }
    public void setTipoCosto(TipoCosto tipoCosto) { this.tipoCosto = tipoCosto; }

    public Double getTotalManual() { return totalManual; }
    public void setTotalManual(Double totalManual) { this.totalManual = totalManual; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public Double getValorTemporal() { return valorTemporal; }
    public void setValorTemporal(Double valorTemporal) { this.valorTemporal = valorTemporal; }
}


