package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "TIPO_COSTO")
public class TipoCosto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_TIPO_COSTO")
    private Long idTipoCosto;

    @ManyToOne
    @JoinColumn(name = "ID_CRUDO")
    private Crudo crudo;

    @ManyToOne
    @JoinColumn(name = "ID_GRUPO")
    private CrudoEntidad crudoEntidad;

    @ManyToOne
    @JoinColumn(name = "ID_CUENTA")
    private Cuenta cuenta;

    @Column(name = "NOMBRE_COSTO")
    private String nombreCosto;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdTipoCosto() {
        return idTipoCosto;
    }

    public void setIdTipoCosto(Long idTipoCosto) {
        this.idTipoCosto = idTipoCosto;
    }

    public Crudo getCrudo() {
        return crudo;
    }

    public void setCrudo(Crudo crudo) {
        this.crudo = crudo;
    }

    public CrudoEntidad getCrudoEntidad() {
        return crudoEntidad;
    }

    public void setCrudoEntidad(CrudoEntidad crudoEntidad) {
        this.crudoEntidad = crudoEntidad;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    public String getNombreCosto() {
        return nombreCosto;
    }

    public void setNombreCosto(String nombreCosto) {
        this.nombreCosto = nombreCosto;
    }

    public String getIdUsuarioCreacion() {
        return idUsuarioCreacion;
    }

    public void setIdUsuarioCreacion(String idUsuarioCreacion) {
        this.idUsuarioCreacion = idUsuarioCreacion;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
