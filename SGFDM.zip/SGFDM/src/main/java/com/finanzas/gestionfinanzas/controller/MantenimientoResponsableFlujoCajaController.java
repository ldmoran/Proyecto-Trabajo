package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.dto.ResponsableFlujoCajaDTO;
import com.finanzas.gestionfinanzas.entity.FlujoCajaResponsable;
import com.finanzas.gestionfinanzas.entity.Usuario;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaResponsableRepository;
import com.finanzas.gestionfinanzas.repository.bdd.UsuarioRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

// Quién es Aprobador y quién es Autorizador de Flujo de Caja (ver FlujoCajaResponsable).
// Se elige entre la gente que ya inició sesión alguna vez en SGFDM (tabla USUARIOS),
// no entre roles del servicio de seguridad institucional, porque ese servicio todavía
// no tiene perfiles para esta cadena de firmas.
@Controller
@RequestMapping("/mantenimiento/responsables-flujo-caja")
public class MantenimientoResponsableFlujoCajaController {

    private final UsuarioRepository usuarioRepository;
    private final FlujoCajaResponsableRepository responsableRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoResponsableFlujoCajaController(UsuarioRepository usuarioRepository,
                                                         FlujoCajaResponsableRepository responsableRepository,
                                                         AuditoriaSessionService auditoriaSessionService) {
        this.usuarioRepository = usuarioRepository;
        this.responsableRepository = responsableRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(HttpServletRequest request, Model model) {
        List<Usuario> usuarios = usuarioRepository.findAll(Sort.by("nombreCompleto"));
        List<FlujoCajaResponsable> responsables = responsableRepository.findAll();

        List<ResponsableFlujoCajaDTO> filas = usuarios.stream()
                .map(u -> {
                    FlujoCajaResponsable r = responsables.stream()
                            .filter(x -> x.getUsuario() != null && x.getUsuario().getIdUsuario().equals(u.getIdUsuario()))
                            .findFirst()
                            .orElse(null);
                    return new ResponsableFlujoCajaDTO(
                            u.getIdUsuario(), u.getUsuario(), u.getNombreCompleto(), u.getEmail(),
                            r != null && r.isElaborador(),
                            r != null && r.isAprobador(),
                            r != null && r.isAutorizador());
                })
                .collect(Collectors.toList());

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("filas", filas);
        return "mantenimiento/responsables-flujo-caja";
    }

    // Marca/desmarca un flag (aprobador/autorizador) para un usuario. Se llama por
    // AJAX desde cada checkbox de la tabla (ver responsables-flujo-caja.html), así
    // que responde JSON en vez de redirigir.
    @PostMapping("/toggle")
    @ResponseBody
    @Transactional("secondTransactionManager")
    public String toggle(@RequestParam Long idUsuario, @RequestParam String rol, @RequestParam boolean valor) {
        auditoriaSessionService.activarUsuarioActual();

        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        FlujoCajaResponsable responsable = responsableRepository.findByUsuario_IdUsuario(idUsuario)
                .orElseGet(() -> {
                    FlujoCajaResponsable nuevo = new FlujoCajaResponsable();
                    nuevo.setUsuario(usuario);
                    nuevo.setEsElaborador("N");
                    nuevo.setEsAprobador("N");
                    nuevo.setEsAutorizador("N");
                    nuevo.setIdUsuarioCreacion(obtenerUsuarioActual());
                    nuevo.setFechaCreacion(LocalDateTime.now());
                    return nuevo;
                });

        String flag = valor ? "S" : "N";
        if ("ELABORADOR".equals(rol)) {
            responsable.setEsElaborador(flag);
        } else if ("APROBADOR".equals(rol)) {
            responsable.setEsAprobador(flag);
        } else if ("AUTORIZADOR".equals(rol)) {
            responsable.setEsAutorizador(flag);
        } else {
            throw new RuntimeException("Rol inválido: " + rol);
        }

        responsableRepository.save(responsable);
        auditoriaSessionService.registrarComentario("FC_RESPONSABLE", responsable.getIdResponsable(), "UPDATE",
                (valor ? "Marcó" : "Desmarcó") + " a " + usuario.getNombreCompleto() + " como " + rol.toLowerCase() + " de Flujo de Caja.");
        return "ok";
    }

    // Alta manual de un usuario, SOLO para pruebas: mientras no hay gente distinta
    // logueada para cada rol, esto permite armar el caso Aprobador/Autorizador sin
    // depender de que esas personas ya hayan entrado al sistema real. No pisa un
    // usuario existente (evitaría corromper la ficha real de alguien que sí entró).
    @PostMapping("/usuarios/agregar-manual")
    @Transactional("secondTransactionManager")
    public String agregarUsuarioManual(@RequestParam String usuario, @RequestParam String nombreCompleto,
                                        @RequestParam String email, RedirectAttributes redirectAttributes) {
        if (usuarioRepository.findByUsuario(usuario.trim()).isPresent()) {
            redirectAttributes.addFlashAttribute("error", "Ya existe un usuario con ese nombre de usuario.");
            return "redirect:/mantenimiento/responsables-flujo-caja";
        }

        Usuario nuevo = new Usuario();
        nuevo.setUsuario(usuario.trim());
        nuevo.setNombreCompleto(nombreCompleto.trim());
        nuevo.setEmail(email.trim());
        nuevo.setFechaPrimerAcceso(LocalDateTime.now());
        nuevo.setFechaUltimoAcceso(LocalDateTime.now());
        nuevo.setTotalAccesos(0); // 0 = nunca inició sesión de verdad, se creó a mano para pruebas

        auditoriaSessionService.activarUsuarioActual();
        try {
            usuarioRepository.save(nuevo);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "Ya existe un usuario con ese nombre de usuario.");
            return "redirect:/mantenimiento/responsables-flujo-caja";
        }
        auditoriaSessionService.registrarComentario("USUARIOS", nuevo.getIdUsuario(), "INSERT",
                "Agregó manualmente al usuario " + nuevo.getNombreCompleto() + " (" + nuevo.getUsuario() + ").");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/responsables-flujo-caja";
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }
}
