package com.finanzas.gestionfinanzas.dto;

import java.math.BigDecimal;

// Subtotal de IMPORTE_A_PAGAR de APPS.XXOCS_AP_CXP_CONS_V agrupado por GRUPO_PAGO,
// con la descripción resuelta contra FND_LOOKUP_VALUES_VL (LOOKUP_TYPE = 'PAY
// GROUP'). Ver EgresoCxpService.resumenPorGrupoPago.
public class ResumenGrupoPagoDTO {

    private final String codigoGrupo;
    private final String descripcion;
    private final BigDecimal total;

    public ResumenGrupoPagoDTO(String codigoGrupo, String descripcion, BigDecimal total) {
        this.codigoGrupo = codigoGrupo;
        this.descripcion = descripcion;
        this.total = total;
    }

    public String getCodigoGrupo() {
        return codigoGrupo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public BigDecimal getTotal() {
        return total;
    }
}
