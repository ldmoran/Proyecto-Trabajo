package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.CuentaBancaria;
import com.finanzas.gestionfinanzas.repository.bdd.CuentaBancariaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaSaldoInicialRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/mantenimiento/cuentas-bancarias")
public class MantenimientoCuentaBancariaController {

    private final CuentaBancariaRepository cuentaBancariaRepository;
    private final FlujoCajaSaldoInicialRepository flujoCajaSaldoInicialRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoCuentaBancariaController(CuentaBancariaRepository cuentaBancariaRepository,
                                                   FlujoCajaSaldoInicialRepository flujoCajaSaldoInicialRepository,
                                                   AuditoriaSessionService auditoriaSessionService) {
        this.cuentaBancariaRepository = cuentaBancariaRepository;
        this.flujoCajaSaldoInicialRepository = flujoCajaSaldoInicialRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                          @RequestParam(required = false) String nombre,
                          @RequestParam(required = false) String estado,
                          HttpServletRequest request, Model model) {
        Page<CuentaBancaria> cuentasBancariasPage =
                cuentaBancariaRepository.buscar(normalizar(nombre), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("cuentasBancariasPage", cuentasBancariasPage);
        model.addAttribute("nombre", nombre);
        model.addAttribute("estado", estado);
        return "mantenimiento/cuentas-bancarias";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idCuentaBancaria,
                           @RequestParam String nombreCuenta,
                           @RequestParam(required = false) String numeroCuenta,
                           @RequestParam String estado,
                           RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        CuentaBancaria cuentaBancaria = (idCuentaBancaria != null)
                ? cuentaBancariaRepository.findById(idCuentaBancaria).orElseThrow(() -> new RuntimeException("Cuenta bancaria no encontrada"))
                : new CuentaBancaria();

        boolean esNueva = cuentaBancaria.getIdCuentaBancaria() == null;

        cuentaBancaria.setNombreCuenta(nombreCuenta.trim());
        cuentaBancaria.setNumeroCuenta(numeroCuenta != null ? numeroCuenta.trim() : null);
        cuentaBancaria.setEstado(estado);

        if (esNueva) {
            cuentaBancaria.setIdUsuarioCreacion(obtenerUsuarioActual());
            cuentaBancaria.setFechaCreacion(LocalDateTime.now());
        }

        cuentaBancariaRepository.save(cuentaBancaria);
        auditoriaSessionService.registrarComentario("CUENTA_BANCARIA", cuentaBancaria.getIdCuentaBancaria(),
                esNueva ? "INSERT" : "UPDATE",
                (esNueva ? "Creó" : "Editó") + " la cuenta bancaria " + cuentaBancaria.getNombreCuenta() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/cuentas-bancarias";
    }

    @PostMapping("/eliminar/{idCuentaBancaria}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idCuentaBancaria, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        if (!flujoCajaSaldoInicialRepository.findByReporte_IdReporte(-1L).isEmpty()) {
            // placeholder de seguridad; la validación real es la de abajo
        }

        String nombreEliminada = cuentaBancariaRepository.findById(idCuentaBancaria)
                .map(CuentaBancaria::getNombreCuenta).orElse("(desconocida)");
        try {
            cuentaBancariaRepository.deleteById(idCuentaBancaria);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados en algún reporte de Flujo de Caja");
            return "redirect:/mantenimiento/cuentas-bancarias";
        }
        auditoriaSessionService.registrarComentario("CUENTA_BANCARIA", idCuentaBancaria, "DELETE",
                "Eliminó la cuenta bancaria " + nombreEliminada + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/cuentas-bancarias";
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }
}