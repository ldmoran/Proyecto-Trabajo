package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional("secondTransactionManager") // usa el datasource SFINGRESO
public interface FacturasBDDRepository extends JpaRepository<FacturasBDD, Long> {
    boolean existsByCustomerTrxId(Long customerTrxId);

    boolean existsByCustomerTrxIdAndSecuencia(Long customerTrxId, Integer secuencia);

    boolean existsByNumFacturaAndRuc(String numFactura, String ruc);

    Optional<FacturasBDD> findByCustomerTrxId(Long customerTrxId);

    List<FacturasBDD> findByCustomerTrxIdIn(Collection<Long> customerTrxIds);

    // FEC_EMBARQUE/FEC_DEPOSITO/FEC_FACTURA son texto libre con formatos mezclados
    // (igual que en la vista del ERP, ver FacturaRepository.buscarTodasPorRangoEmbarque):
    // 'YYYY/MM/DD...', 'DD/MM/YYYY...', 'DD/MM/RR' sin hora, y filas en blanco. Antes se
    // comparaban como texto exacto contra el valor del <input type="date"> (siempre
    // 'YYYY-MM-DD'), así que casi nunca coincidía. Este CASE detecta cada formato por su
    // forma (REGEXP_LIKE) y lo convierte a DATE real antes de comparar; lo que no calza
    // con ningún formato queda NULL y no entra en el filtro. Es el mismo patrón ya probado
    // en FacturaRepository, aplicado acá a la tabla local FACTURAS.
    String FEC_EMBARQUE_A_DATE =
            "CASE " +
            "WHEN REGEXP_LIKE(f.FEC_EMBARQUE, '^[0-9]{4}/[0-9]{2}/[0-9]{2}') THEN TO_DATE(SUBSTR(f.FEC_EMBARQUE, 1, 10), 'YYYY/MM/DD') " +
            "WHEN REGEXP_LIKE(f.FEC_EMBARQUE, '^[0-9]{2}/[0-9]{2}/[0-9]{4}') THEN TO_DATE(SUBSTR(f.FEC_EMBARQUE, 1, 10), 'DD/MM/YYYY') " +
            "WHEN REGEXP_LIKE(f.FEC_EMBARQUE, '^[0-9]{2}/[0-9]{2}/[0-9]{2}$') THEN TO_DATE(f.FEC_EMBARQUE, 'DD/MM/RR') " +
            "ELSE NULL END";
    String FEC_DEPOSITO_A_DATE =
            "CASE " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{4}/[0-9]{2}/[0-9]{2}') THEN TO_DATE(SUBSTR(f.FEC_DEPOSITO, 1, 10), 'YYYY/MM/DD') " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{2}/[0-9]{2}/[0-9]{4}') THEN TO_DATE(SUBSTR(f.FEC_DEPOSITO, 1, 10), 'DD/MM/YYYY') " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{2}/[0-9]{2}/[0-9]{2}$') THEN TO_DATE(f.FEC_DEPOSITO, 'DD/MM/RR') " +
            "ELSE NULL END";
    String FEC_FACTURA_A_DATE =
            "CASE " +
            "WHEN REGEXP_LIKE(f.FEC_FACTURA, '^[0-9]{4}/[0-9]{2}/[0-9]{2}') THEN TO_DATE(SUBSTR(f.FEC_FACTURA, 1, 10), 'YYYY/MM/DD') " +
            "WHEN REGEXP_LIKE(f.FEC_FACTURA, '^[0-9]{2}/[0-9]{2}/[0-9]{4}') THEN TO_DATE(SUBSTR(f.FEC_FACTURA, 1, 10), 'DD/MM/YYYY') " +
            "WHEN REGEXP_LIKE(f.FEC_FACTURA, '^[0-9]{2}/[0-9]{2}/[0-9]{2}$') THEN TO_DATE(f.FEC_FACTURA, 'DD/MM/RR') " +
            "ELSE NULL END";
    String BUSCAR_WHERE =
            "(:ruc IS NULL OR f.RUC = :ruc) " +
            "AND (:numFactura IS NULL OR f.NUM_FACTURA = :numFactura) " +
            "AND (:fecEmbarque IS NULL OR (" + FEC_EMBARQUE_A_DATE + ") = TO_DATE(:fecEmbarque, 'YYYY-MM-DD')) " +
            "AND (:fecDeposito IS NULL OR (" + FEC_DEPOSITO_A_DATE + ") = TO_DATE(:fecDeposito, 'YYYY-MM-DD')) " +
            "AND (:fecFactura IS NULL OR (" + FEC_FACTURA_A_DATE + ") = TO_DATE(:fecFactura, 'YYYY-MM-DD')) " +
            "AND (:estado IS NULL OR UPPER(f.ESTADO) = UPPER(:estado)) " +
            // Una factura ya incluida en un envío a EBS guardado no debe volver a
            // aparecer aquí (evita seleccionarla/enviarla dos veces).
            "AND NOT EXISTS (SELECT 1 FROM ENVIO_EBS_FACTURA ef WHERE ef.ID_FACTURA = f.ID_FACTURA)";

    @Query(value = "SELECT f.* FROM FACTURAS f WHERE " + BUSCAR_WHERE +
            // Lo último trabajado primero: al guardar distribuciones o aprobar una
            // factura, ésta sube al tope del listado. El id sirve de desempate.
            " ORDER BY f.FECHA_MODIFICACION DESC NULLS LAST, f.ID_FACTURA DESC",
            countQuery = "SELECT COUNT(*) FROM FACTURAS f WHERE " + BUSCAR_WHERE,
            nativeQuery = true)
    Page<FacturasBDD> buscar(@Param("ruc") String ruc,
                             @Param("numFactura") String numFactura,
                             @Param("fecEmbarque") String fecEmbarque,
                             @Param("fecDeposito") String fecDeposito,
                             @Param("fecFactura") String fecFactura,
                             @Param("estado") String estado,
                             Pageable pageable);

    // Para el gráfico de picos del dashboard, cuando se elige Semana o Mes: cuántas
    // facturas se Aprobaron cada día en el rango [desde, hasta] (ambos inclusive; ver
    // AuthController.construirEstadisticas). desde/hasta NULL = sin ese límite (caso
    // "Todo el historial") — pero en ese caso el gráfico agrupa por MES, no por día,
    // así que este método casi no se usa con ambos NULL. Acotar el rango es a
    // propósito: sin esto, con el sistema corriendo un par de años la consulta (y el
    // gráfico) tendrían que recorrer todo el historial cada vez que alguien abre el
    // dashboard. Se usa FECHA_MODIFICACION (TIMESTAMP real, se actualiza al aprobar) y
    // no FEC_EMBARQUE/FEC_DEPOSITO porque esas vienen con formatos de texto mezclados
    // (ver BUSCAR_WHERE) y agruparlas sería repetir ese parseo solo para un gráfico.
    // Cada fila: [0]=día (java.sql.Date), [1]=cantidad.
    @Query(value = "SELECT TRUNC(FECHA_MODIFICACION) AS DIA, COUNT(*) AS CANTIDAD " +
            "FROM FACTURAS " +
            "WHERE ESTADO = 'A' " +
            "AND (:desde IS NULL OR FECHA_MODIFICACION >= :desde) " +
            "AND (:hasta IS NULL OR FECHA_MODIFICACION < :hasta + 1) " +
            "GROUP BY TRUNC(FECHA_MODIFICACION) " +
            "ORDER BY DIA",
            nativeQuery = true)
    List<Object[]> contarAprobadasPorDiaEnRango(@Param("desde") LocalDate desde, @Param("hasta") LocalDate hasta);

    // Mismo gráfico, cuando se elige Año o Todo el historial: agrupado por mes en vez
    // de por día (con años de datos, un punto por día sería ilegible). Cada fila:
    // [0]=primer día del mes (java.sql.Date), [1]=cantidad.
    @Query(value = "SELECT TRUNC(FECHA_MODIFICACION, 'MM') AS MES, COUNT(*) AS CANTIDAD " +
            "FROM FACTURAS " +
            "WHERE ESTADO = 'A' " +
            "AND (:desde IS NULL OR FECHA_MODIFICACION >= :desde) " +
            "AND (:hasta IS NULL OR FECHA_MODIFICACION < :hasta + 1) " +
            "GROUP BY TRUNC(FECHA_MODIFICACION, 'MM') " +
            "ORDER BY MES",
            nativeQuery = true)
    List<Object[]> contarAprobadasPorMesEnRango(@Param("desde") LocalDate desde, @Param("hasta") LocalDate hasta);

    // Para el pastel/velocímetro de estados del dashboard: una sola fila con los 3
    // conteos ya armados (evita 3 queries separadas), acotada al mismo rango que el
    // gráfico de picos. desde/hasta NULL = todo el historial (opción "Todo" del
    // selector). [0]=Pendientes (Registradas), [1]=Aprobadas (enviables a EBS),
    // [2]=Aprobadas pero excluidas de EBS por destiempo.
    @Query(value = "SELECT " +
            "SUM(CASE WHEN NVL(ESTADO, 'R') != 'A' THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN ESTADO = 'A' AND NVL(EXCLUIDA_EBS, 'N') != 'S' THEN 1 ELSE 0 END), " +
            "SUM(CASE WHEN ESTADO = 'A' AND EXCLUIDA_EBS = 'S' THEN 1 ELSE 0 END) " +
            "FROM FACTURAS " +
            "WHERE (:desde IS NULL OR FECHA_MODIFICACION >= :desde) " +
            "AND (:hasta IS NULL OR FECHA_MODIFICACION < :hasta + 1)",
            nativeQuery = true)
    List<Object[]> contarPorEstadoEnRango(@Param("desde") LocalDate desde, @Param("hasta") LocalDate hasta);
}
