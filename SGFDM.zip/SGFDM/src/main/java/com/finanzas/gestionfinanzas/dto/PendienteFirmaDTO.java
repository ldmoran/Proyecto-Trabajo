package com.finanzas.gestionfinanzas.dto;

import java.time.LocalDate;

public class PendienteFirmaDTO {

    private final LocalDate fechaInicio;
    private final LocalDate fechaFin;
    private final String accion;

    public PendienteFirmaDTO(LocalDate fechaInicio, LocalDate fechaFin, String accion) {
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.accion = accion;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public String getAccion() {
        return accion;
    }
}
