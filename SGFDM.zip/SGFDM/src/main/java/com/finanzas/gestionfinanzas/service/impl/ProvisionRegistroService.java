package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.ConceptoConPagosRequest;
import com.finanzas.gestionfinanzas.dto.ItemProvisionNuevaRequest;
import com.finanzas.gestionfinanzas.dto.PagoSeleccionadoRequest;
import com.finanzas.gestionfinanzas.entity.Archivo;
import com.finanzas.gestionfinanzas.entity.FlujoCajaReporte;
import com.finanzas.gestionfinanzas.entity.ProvisionConcepto;
import com.finanzas.gestionfinanzas.entity.ProvisionLote;
import com.finanzas.gestionfinanzas.entity.ProvisionPagoSeleccionado;
import com.finanzas.gestionfinanzas.entity.ProvisionRegistro;
import com.finanzas.gestionfinanzas.entity.TipoArchivo;
import com.finanzas.gestionfinanzas.repository.bdd.ArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaReporteRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionConceptoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionLoteRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionPagoSeleccionadoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionRegistroRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoArchivoRepository;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

// Lógica del flujo Nuevo/Anterior/Mixto de Provisiones. Ver el comentario de
// PROVISION_REGISTRO en reset_bd.sql para el detalle de negocio de cada tipo.
@Service
public class ProvisionRegistroService {

    private static final String ESTADO_ABIERTO = "ABIERTO";
    private static final String ESTADO_CERRADO = "CERRADO";

    private final ProvisionRegistroRepository registroRepository;
    private final ProvisionLoteRepository loteRepository;
    private final ProvisionConceptoRepository conceptoRepository;
    private final ProvisionPagoSeleccionadoRepository pagoSeleccionadoRepository;
    private final ProvisionPagoProveedorService pagoProveedorService;
    private final ArchivoRepository archivoRepository;
    private final TipoArchivoRepository tipoArchivoRepository;
    private final AuditoriaSessionService auditoriaSessionService;
    private final FlujoCajaReporteRepository flujoCajaReporteRepository;
    private final FlujoCajaReporteService flujoCajaReporteService;

    public ProvisionRegistroService(ProvisionRegistroRepository registroRepository,
                                     ProvisionLoteRepository loteRepository,
                                     ProvisionConceptoRepository conceptoRepository,
                                     ProvisionPagoSeleccionadoRepository pagoSeleccionadoRepository,
                                     ProvisionPagoProveedorService pagoProveedorService,
                                     ArchivoRepository archivoRepository,
                                     TipoArchivoRepository tipoArchivoRepository,
                                     AuditoriaSessionService auditoriaSessionService,
                                     FlujoCajaReporteRepository flujoCajaReporteRepository,
                                     FlujoCajaReporteService flujoCajaReporteService) {
        this.registroRepository = registroRepository;
        this.loteRepository = loteRepository;
        this.conceptoRepository = conceptoRepository;
        this.pagoSeleccionadoRepository = pagoSeleccionadoRepository;
        this.pagoProveedorService = pagoProveedorService;
        this.archivoRepository = archivoRepository;
        this.tipoArchivoRepository = tipoArchivoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
        this.flujoCajaReporteRepository = flujoCajaReporteRepository;
        this.flujoCajaReporteService = flujoCajaReporteService;
    }

    // Reporte de Flujo de Caja de esta semana, si ya existe — se resuelve UNA
    // vez por lote (no una vez por concepto) y se liga a cada registro que se
    // cree (ver ProvisionRegistro.reporte / ID_REPORTE), en vez de que cada
    // pantalla tenga que volver a matchear la fecha a mano. En la práctica
    // siempre existe: Provisiones solo deja elegir períodos que ya tienen
    // reporte (ver ProvisionesController.verProvisiones/periodosJson), pero
    // se maneja como null por las dudas en vez de asumirlo.
    private FlujoCajaReporte obtenerReporteDeLaSemana(LocalDate fechaInicioPeriodo) {
        return flujoCajaReporteRepository.findByFechaInicio(fechaInicioPeriodo).orElse(null);
    }

    // Provisiones comparte semana con Ingresos/Egresos, así que comparte
    // también su candado de edición (mismo criterio que
    // FlujoCajaReporteService.verificarDatosNoBloqueados: no Autorizado, no
    // Elaborado, no Aprobado) — sin esto, se podía seguir guardando/editando
    // Provisiones de una semana ya cerrada por firma, aunque Ingresos/Egresos
    // ya no dejaran tocar nada. Si todavía no hay reporte para esa semana, no
    // hay nada que bloquee (no debería pasar en la práctica, ver comentario
    // de obtenerReporteDeLaSemana).
    private void verificarSemanaEditable(FlujoCajaReporte reporte) {
        if (reporte != null) {
            flujoCajaReporteService.verificarDatosNoBloqueados(reporte);
        }
    }

    // NUEVO: uno o varios Conceptos, cada uno con su propio valor
    // provisionado del ciclo, guardados juntos como un LOTE con un solo PDF
    // de respaldo que cubre a todos. Cada Concepto queda ABIERTO por
    // separado hasta que un ANTERIOR o MIXTO posterior lo cierre.
    @Transactional("secondTransactionManager")
    public List<ProvisionRegistro> crearNuevoLote(LocalDate fechaInicioPeriodo, LocalDate fechaFinPeriodo,
                                                    List<ItemProvisionNuevaRequest> items, MultipartFile pdf) {
        auditoriaSessionService.activarUsuarioActual();
        String usuarioActual = usuarioActual();

        if (items == null || items.isEmpty()) {
            throw new RuntimeException("Debe agregar al menos un concepto con su valor");
        }

        FlujoCajaReporte reporte = obtenerReporteDeLaSemana(fechaInicioPeriodo);
        verificarSemanaEditable(reporte);

        ProvisionLote lote = new ProvisionLote();
        lote.setTipo(ProvisionRegistro.TIPO_NUEVO);
        lote.setIdUsuarioCreacion(usuarioActual);
        lote.setFechaCreacion(LocalDateTime.now());
        lote = loteRepository.save(lote);

        List<ProvisionRegistro> registros = new ArrayList<>();
        for (ItemProvisionNuevaRequest item : items) {
            registros.add(crearRegistroNuevo(item, fechaInicioPeriodo, fechaFinPeriodo, reporte, lote, usuarioActual));
        }

        guardarPdfDelLote(lote, pdf, usuarioActual);
        if (reporte != null) {
            flujoCajaReporteService.recalcularTotales(reporte);
        }
        auditoriaSessionService.registrarComentario("PROVISION_LOTE", lote.getIdLote(), "INSERT",
                "Registró un lote de Provisión Nuevo con " + items.size() + " concepto(s), semana del "
                        + fechaInicioPeriodo + " al " + fechaFinPeriodo + ".");

        return registros;
    }

    // Un Concepto + su Valor como registro NUEVO, ABIERTO — usado tanto por
    // crearNuevoLote como por crearMixtoLote (en Mixto, estos Nuevo son
    // independientes de los conceptos que se cierran con facturas en el
    // mismo guardado: el usuario los elige aparte, con su propio Concepto).
    private ProvisionRegistro crearRegistroNuevo(ItemProvisionNuevaRequest item, LocalDate fechaInicioPeriodo,
                                                  LocalDate fechaFinPeriodo, FlujoCajaReporte reporte,
                                                  ProvisionLote lote, String usuarioActual) {
        if (item.getIdConcepto() == null || item.getValor() == null) {
            throw new RuntimeException("Cada fila debe tener un concepto y un valor");
        }
        ProvisionConcepto concepto = conceptoRepository.findById(item.getIdConcepto())
                .orElseThrow(() -> new RuntimeException("Concepto de provisión no encontrado"));

        ProvisionRegistro registro = new ProvisionRegistro();
        registro.setConcepto(concepto);
        registro.setLote(lote);
        registro.setReporte(reporte);
        registro.setFechaInicioPeriodo(fechaInicioPeriodo);
        registro.setFechaFinPeriodo(fechaFinPeriodo);
        registro.setTipo(ProvisionRegistro.TIPO_NUEVO);
        registro.setValorNuevo(item.getValor());
        registro.setEstado(ESTADO_ABIERTO);
        registro.setIdUsuarioCreacion(usuarioActual);
        registro.setFechaCreacion(LocalDateTime.now());
        return registroRepository.save(registro);
    }

    // PENDIENTE (tipo ANTERIOR): uno o varios Conceptos a la vez, cada uno con
    // sus propias facturas elegidas, guardados juntos como un LOTE — igual
    // patrón que crearNuevoLote, para no tener que repetir la pantalla una
    // vez por concepto. Lo que sobre del valor a cubrir de cada concepto
    // queda igual que siempre (VALOR_PENDIENTE, ver crearRegistroAnteriorOMixto)
    // para la semana siguiente, hasta que un Mixto lo cierre.
    @Transactional("secondTransactionManager")
    public List<ProvisionRegistro> crearAnteriorLote(LocalDate fechaInicioPeriodo, LocalDate fechaFinPeriodo,
                                                       List<ConceptoConPagosRequest> conceptos) {
        auditoriaSessionService.activarUsuarioActual();
        String usuarioActual = usuarioActual();

        if (conceptos == null || conceptos.isEmpty()) {
            throw new RuntimeException("Debe agregar al menos un concepto con sus facturas");
        }

        FlujoCajaReporte reporte = obtenerReporteDeLaSemana(fechaInicioPeriodo);
        verificarSemanaEditable(reporte);

        ProvisionLote lote = new ProvisionLote();
        lote.setTipo(ProvisionRegistro.TIPO_ANTERIOR);
        lote.setIdUsuarioCreacion(usuarioActual);
        lote.setFechaCreacion(LocalDateTime.now());
        lote = loteRepository.save(lote);

        List<ProvisionRegistro> registros = new ArrayList<>();
        for (ConceptoConPagosRequest item : conceptos) {
            registros.add(crearRegistroAnteriorOMixto(ProvisionRegistro.TIPO_ANTERIOR, item.getIdConcepto(),
                    fechaInicioPeriodo, fechaFinPeriodo, reporte, item.getPagos(), lote, usuarioActual));
        }
        if (reporte != null) {
            flujoCajaReporteService.recalcularTotales(reporte);
        }
        auditoriaSessionService.registrarComentario("PROVISION_LOTE", lote.getIdLote(), "INSERT",
                "Registró un lote de Provisión Anterior con " + conceptos.size() + " concepto(s), semana del "
                        + fechaInicioPeriodo + " al " + fechaFinPeriodo + ".");
        return registros;
    }

    // MIXTO: en un mismo guardado, se cierran uno o varios Conceptos con sus
    // facturas (igual que Pendiente) Y se registra uno o varios Conceptos
    // NUEVO con su propio valor (igual que Nueva) — son dos listas
    // independientes entre sí: los Nuevo que se registran acá NO tienen que
    // ser los mismos Conceptos que se están cerrando, el usuario los elige
    // aparte. Todo comparte un solo lote y un solo PDF de respaldo.
    // "cierres" puede venir vacío (Mixto sin nada para cerrar todavía), pero
    // siempre debe haber al menos un "nuevo".
    @Transactional("secondTransactionManager")
    public List<ProvisionRegistro> crearMixtoLote(LocalDate fechaInicioPeriodo, LocalDate fechaFinPeriodo,
                                                   List<ConceptoConPagosRequest> cierres,
                                                   List<ItemProvisionNuevaRequest> nuevos, MultipartFile pdf) {
        auditoriaSessionService.activarUsuarioActual();
        String usuarioActual = usuarioActual();

        if (nuevos == null || nuevos.isEmpty()) {
            throw new RuntimeException("Debe agregar al menos un concepto Nuevo con su valor");
        }

        FlujoCajaReporte reporte = obtenerReporteDeLaSemana(fechaInicioPeriodo);
        verificarSemanaEditable(reporte);

        ProvisionLote lote = new ProvisionLote();
        lote.setTipo(ProvisionRegistro.TIPO_MIXTO);
        lote.setIdUsuarioCreacion(usuarioActual);
        lote.setFechaCreacion(LocalDateTime.now());
        lote = loteRepository.save(lote);

        List<ProvisionRegistro> registros = new ArrayList<>();
        if (cierres != null) {
            for (ConceptoConPagosRequest item : cierres) {
                registros.add(crearRegistroAnteriorOMixto(ProvisionRegistro.TIPO_MIXTO, item.getIdConcepto(),
                        fechaInicioPeriodo, fechaFinPeriodo, reporte, item.getPagos(), lote, usuarioActual));
            }
        }
        for (ItemProvisionNuevaRequest item : nuevos) {
            registros.add(crearRegistroNuevo(item, fechaInicioPeriodo, fechaFinPeriodo, reporte, lote, usuarioActual));
        }

        guardarPdfDelLote(lote, pdf, usuarioActual);
        if (reporte != null) {
            flujoCajaReporteService.recalcularTotales(reporte);
        }
        auditoriaSessionService.registrarComentario("PROVISION_LOTE", lote.getIdLote(), "INSERT",
                "Registró un lote de Provisión Mixto (" + (cierres != null ? cierres.size() : 0) + " cierre(s) + "
                        + nuevos.size() + " nuevo(s)), semana del " + fechaInicioPeriodo + " al " + fechaFinPeriodo + ".");

        return registros;
    }

    // Núcleo compartido de ANTERIOR/MIXTO (ver comentario de PROVISION_REGISTRO
    // en reset_bd.sql para el detalle de negocio): se eligen pagos de la vista
    // APPS.XXOCS_AP_CXP_PAGOS_PROV_V del ERP (el usuario los manda de vuelta
    // tal cual los vio en pantalla, porque esa vista es externa y de solo
    // lectura, no hay ID local contra el cual buscarlos), se suman, y se les
    // resta el "valor a cubrir" de esta ronda: si ya hubo una ronda
    // Pendiente/Mixto antes para este mismo Nuevo, es lo que quedó pendiente
    // de esa (para poder seguir descontando semana tras semana); si es la
    // primera ronda, es el VALOR_NUEVO original. El resultado (VALOR_PENDIENTE)
    // queda guardado como histórico. Solo un MIXTO cierra (CERRADO) el registro
    // NUEVO de origen — un Pendiente lo deja abierto para que la próxima
    // semana pueda seguir sobre el mismo. "lote" siempre viene de
    // crearAnteriorLote o crearMixtoLote (varios conceptos guardados juntos).
    private ProvisionRegistro crearRegistroAnteriorOMixto(String tipo, Long idConcepto, LocalDate fechaInicioPeriodo,
                                                           LocalDate fechaFinPeriodo, FlujoCajaReporte reporte,
                                                           List<PagoSeleccionadoRequest> pagos,
                                                           ProvisionLote lote, String usuarioActual) {
        if (pagos == null || pagos.isEmpty()) {
            throw new RuntimeException("Debe seleccionar al menos un pago");
        }

        ProvisionConcepto concepto = conceptoRepository.findById(idConcepto)
                .orElseThrow(() -> new RuntimeException("Concepto de provisión no encontrado"));

        ProvisionRegistro origen = obtenerNuevoAbierto(idConcepto);
        BigDecimal valorACubrir = resolverValorACubrir(origen);

        BigDecimal valorFacturas = BigDecimal.ZERO;
        for (PagoSeleccionadoRequest pago : pagos) {
            if (pago.getFechaPago() == null || pago.getFechaPago().trim().isEmpty()) {
                throw new RuntimeException("Un pago seleccionado no tiene fecha de pago");
            }
            if (pago.getMonto() != null) {
                valorFacturas = valorFacturas.add(pago.getMonto());
            }
        }

        if (valorFacturas.compareTo(valorACubrir) > 0) {
            throw new RuntimeException("La suma de las facturas seleccionadas (" + valorFacturas
                    + ") no puede ser mayor al valor pendiente de cobertura de este concepto (" + valorACubrir + ")");
        }

        ProvisionRegistro registro = new ProvisionRegistro();
        registro.setConcepto(concepto);
        registro.setLote(lote);
        registro.setReporte(reporte);
        registro.setFechaInicioPeriodo(fechaInicioPeriodo);
        registro.setFechaFinPeriodo(fechaFinPeriodo);
        registro.setTipo(tipo);
        registro.setRegistroOrigen(origen);
        registro.setEstado(ESTADO_ABIERTO);
        registro.setIdUsuarioCreacion(usuarioActual);
        registro.setFechaCreacion(LocalDateTime.now());
        registro = registroRepository.save(registro);

        for (PagoSeleccionadoRequest pago : pagos) {
            ProvisionPagoSeleccionado seleccionado = new ProvisionPagoSeleccionado();
            seleccionado.setRegistro(registro);
            seleccionado.setRuc(pago.getRuc());
            seleccionado.setDocumento(pago.getDocumento());
            seleccionado.setVendorName(pago.getVendorName());
            seleccionado.setDescripcion(pago.getDescripcion());
            seleccionado.setMontoPagado(pago.getMonto());
            seleccionado.setFechaPago(LocalDate.parse(pago.getFechaPago()));
            seleccionado.setIdUsuarioCreacion(usuarioActual);
            seleccionado.setFechaCreacion(LocalDateTime.now());
            pagoSeleccionadoRepository.save(seleccionado);
        }

        registro.setValorFacturas(valorFacturas);
        // Positivo: es lo que sobra del valor a cubrir después de pagar
        // estas facturas, y queda como saldo para la siguiente semana (la
        // validación de arriba ya garantiza que nunca sea negativo).
        registro.setValorPendiente(valorACubrir.subtract(valorFacturas));
        registroRepository.save(registro);

        if (ProvisionRegistro.TIPO_MIXTO.equals(tipo)) {
            origen.setEstado(ESTADO_CERRADO);
            registroRepository.save(origen);
        }

        return registro;
    }

    // El NUEVO abierto más reciente de un concepto (ver comentario del
    // repositorio) — lanza si no hay ninguno.
    private ProvisionRegistro obtenerNuevoAbierto(Long idConcepto) {
        return registroRepository
                .findFirstByConcepto_IdConceptoAndTipoAndEstadoOrderByFechaCreacionDesc(
                        idConcepto, ProvisionRegistro.TIPO_NUEVO, ESTADO_ABIERTO)
                .orElseThrow(() -> new RuntimeException(
                        "No hay un valor 'Nuevo' abierto para este concepto: primero hay que registrar uno"));
    }

    // Cuánto queda por cubrir contra este Nuevo: lo pendiente de la última
    // ronda Pendiente/Mixto ya guardada, o el Valor Nuevo original si
    // todavía no hubo ninguna.
    private BigDecimal resolverValorACubrir(ProvisionRegistro origen) {
        return registroRepository
                .findFirstByRegistroOrigen_IdRegistroOrderByFechaCreacionDesc(origen.getIdRegistro())
                .map(ProvisionRegistro::getValorPendiente)
                .orElse(origen.getValorNuevo() != null ? origen.getValorNuevo() : BigDecimal.ZERO);
    }

    // Para que la pantalla muestre, apenas se elige el Concepto en Pendiente/
    // Mixto, contra qué monto se van a validar las facturas que se elijan.
    public BigDecimal obtenerValorACubrir(Long idConcepto) {
        return resolverValorACubrir(obtenerNuevoAbierto(idConcepto));
    }

    // Fila: [0]=VENDOR_NAME, [1]=RUC, [2]=DOCUMENTO, [3]=MONTO_PAGADO,
    // [4]=DESCRIPCION, [5]=FECHA_PAGO_STR. Se descartan las que ya se hayan
    // pagado alguna vez desde Provisiones (ver PROVISION_PAGO_SELECCIONADO /
    // UQ_PROVISION_PAGO_FACTURA), sin importar en qué registro o semana —
    // para no ofrecerlas de nuevo como opción y terminar pagando lo mismo
    // dos veces.
    public List<Object[]> listarPagosProveedor() {
        Set<String> yaUsadas = new HashSet<>();
        for (Object[] usada : pagoSeleccionadoRepository.findRucDocumentoUsados()) {
            yaUsadas.add(clavePago(usada[0], usada[1]));
        }

        List<Object[]> pagos = new ArrayList<>();
        for (Object[] pago : pagoProveedorService.obtenerPagos()) {
            if (!yaUsadas.contains(clavePago(pago[1], pago[2]))) {
                pagos.add(pago);
            }
        }
        return pagos;
    }

    private String clavePago(Object ruc, Object documento) {
        return (ruc != null ? ruc.toString() : "") + "||" + (documento != null ? documento.toString() : "");
    }

    // Un solo PDF para TODO el lote (todos los conceptos que se guardaron
    // juntos en ese clic de "Guardar"), en vez de uno por concepto.
    private void guardarPdfDelLote(ProvisionLote lote, MultipartFile pdf, String usuarioActual) {
        if (pdf == null || pdf.isEmpty()) {
            throw new RuntimeException("Debe adjuntar el PDF de respaldo");
        }
        String nombre = pdf.getOriginalFilename() != null ? pdf.getOriginalFilename().toLowerCase() : "";
        String contentType = pdf.getContentType() != null ? pdf.getContentType().toLowerCase() : "";
        if (!"application/pdf".equals(contentType) && !nombre.endsWith(".pdf")) {
            throw new RuntimeException("El comprobante debe ser un archivo PDF");
        }

        TipoArchivo tipoArchivo = tipoArchivoRepository.findByNombreTipoArchivo(TipoArchivo.COMPROBANTE_PROVISION)
                .orElseThrow(() -> new RuntimeException(
                        "No existe el Tipo de Archivo '" + TipoArchivo.COMPROBANTE_PROVISION + "' en Mantenimiento > Tipos de archivo"));

        Archivo archivo = new Archivo();
        archivo.setProvisionLote(lote);
        archivo.setTipoArchivo(tipoArchivo);
        archivo.setNombreArchivo(pdf.getOriginalFilename());
        archivo.setExtension("PDF");
        try {
            archivo.setContenido(pdf.getBytes());
        } catch (IOException e) {
            throw new RuntimeException("No se pudo leer el PDF subido");
        }
        archivo.setEstado("A");
        archivo.setIdUsuarioCreacion(usuarioActual);
        archivo.setFechaCreacion(LocalDateTime.now());
        archivoRepository.save(archivo);
    }

    private String usuarioActual() {
        return SecurityUtils.getUsuarioActual() != null ? SecurityUtils.getUsuarioActual().getUsuario() : null;
    }
}
