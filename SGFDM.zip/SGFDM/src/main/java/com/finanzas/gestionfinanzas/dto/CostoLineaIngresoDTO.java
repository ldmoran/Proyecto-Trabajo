package com.finanzas.gestionfinanzas.dto;

public class CostoLineaIngresoDTO {

    private final String nombreCosto;
    private final Double valor;

    public CostoLineaIngresoDTO(String nombreCosto, Double valor) {
        this.nombreCosto = nombreCosto;
        this.valor = valor;
    }

    public String getNombreCosto() {
        return nombreCosto;
    }

    public Double getValor() {
        return valor;
    }
}
