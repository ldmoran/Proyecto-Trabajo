package com.finanzas.gestionfinanzas.dto;

import java.util.Map;

public class FilaCostoFacturaDTO {

    private final String nombreHija;
    private final Map<String, Double> valoresPorCosto;
    private final Double volumen;
    private final Double total;

    public FilaCostoFacturaDTO(String nombreHija, Map<String, Double> valoresPorCosto, Double volumen, Double total) {
        this.nombreHija = nombreHija;
        this.valoresPorCosto = valoresPorCosto;
        this.volumen = volumen;
        this.total = total;
    }

    public String getNombreHija() {
        return nombreHija;
    }

    public Map<String, Double> getValoresPorCosto() {
        return valoresPorCosto;
    }

    public Double getVolumen() {
        return volumen;
    }

    public Double getTotal() {
        return total;
    }
}
