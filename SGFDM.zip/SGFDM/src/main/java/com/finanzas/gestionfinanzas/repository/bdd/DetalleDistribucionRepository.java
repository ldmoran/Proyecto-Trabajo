package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.DetalleDistribucion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface DetalleDistribucionRepository extends JpaRepository<DetalleDistribucion, Long> {
    List<DetalleDistribucion> findByFactura_IdFacturaOrderByIdDetalleDesc(Long idFactura);

    boolean existsByDistribucionHija_IdDeta(Long idDeta);

    boolean existsByFactura_IdFacturaAndDistribucionHija_IdDeta(Long idFactura, Long idDeta);

    @Query("SELECT COALESCE(SUM(dd.volumen), 0) FROM DetalleDistribucion dd WHERE dd.factura.idFactura = :idFactura")
    Double sumVolumenByFactura(@Param("idFactura") Long idFactura);

    @Query("SELECT dd FROM DetalleDistribucion dd " +
            "LEFT JOIN FETCH dd.distribucionHija dh " +
            "LEFT JOIN FETCH dh.distribucionPadre dp " +
            "LEFT JOIN FETCH dp.crudo " +
            "LEFT JOIN FETCH dp.tipoDistribucion " +
            "LEFT JOIN FETCH dd.factura " +
            "WHERE dd.factura.idFactura = :idFactura " +
            "ORDER BY dd.idDetalle DESC")
    List<DetalleDistribucion> findConDetalleByFactura(@Param("idFactura") Long idFactura);

    @Query("SELECT dd FROM DetalleDistribucion dd " +
            "LEFT JOIN FETCH dd.distribucionHija dh " +
            "LEFT JOIN FETCH dh.distribucionPadre dp " +
            "LEFT JOIN FETCH dp.crudo " +
            "LEFT JOIN FETCH dp.tipoDistribucion " +
            "LEFT JOIN FETCH dd.factura " +
            "WHERE dd.factura.idFactura IN :idsFactura " +
            "ORDER BY dd.idDetalle DESC")
    List<DetalleDistribucion> findConDetalleByFacturaIn(@Param("idsFactura") List<Long> idsFactura);
}
