package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.ProvisionLote;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProvisionLoteRepository extends JpaRepository<ProvisionLote, Long> {
}
