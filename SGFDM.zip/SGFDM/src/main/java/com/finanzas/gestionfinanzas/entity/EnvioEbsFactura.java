package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ENVIO_EBS_FACTURA")
public class EnvioEbsFactura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_DETALLE")
    private Long idDetalle;

    @ManyToOne
    @JoinColumn(name = "ID_ENVIO_EBS")
    private EnvioEbs envioEbs;

    @ManyToOne
    @JoinColumn(name = "ID_FACTURA")
    private FacturasBDD factura;

    @Column(name = "TOTAL_FACTURA")
    private Double totalFactura;

    public Long getIdDetalle() {
        return idDetalle;
    }

    public void setIdDetalle(Long idDetalle) {
        this.idDetalle = idDetalle;
    }

    public EnvioEbs getEnvioEbs() {
        return envioEbs;
    }

    public void setEnvioEbs(EnvioEbs envioEbs) {
        this.envioEbs = envioEbs;
    }

    public FacturasBDD getFactura() {
        return factura;
    }

    public void setFactura(FacturasBDD factura) {
        this.factura = factura;
    }

    public Double getTotalFactura() {
        return totalFactura;
    }

    public void setTotalFactura(Double totalFactura) {
        this.totalFactura = totalFactura;
    }
}
