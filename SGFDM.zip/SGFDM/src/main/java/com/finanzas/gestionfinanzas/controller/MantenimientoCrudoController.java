package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.Crudo;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.DistribucionPadreRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoCostoRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/mantenimiento/crudos")
public class MantenimientoCrudoController {

    private final CrudoRepository crudoRepository;
    private final DistribucionPadreRepository padreRepo;
    private final TipoCostoRepository tipoCostoRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoCrudoController(CrudoRepository crudoRepository,
                                        DistribucionPadreRepository padreRepo,
                                        TipoCostoRepository tipoCostoRepository,
                                        AuditoriaSessionService auditoriaSessionService) {
        this.crudoRepository = crudoRepository;
        this.padreRepo = padreRepo;
        this.tipoCostoRepository = tipoCostoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) String nombre,
                         @RequestParam(required = false) String estado,
                         HttpServletRequest request, Model model) {
        Page<Crudo> crudosPage = crudoRepository.buscar(normalizar(nombre), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("crudosPage", crudosPage);
        model.addAttribute("nombre", nombre);
        model.addAttribute("estado", estado);
        return "mantenimiento/crudos";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idCrudo,
                          @RequestParam String nombreCrudo,
                          @RequestParam String estado,
                          RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        boolean esNuevo = idCrudo == null;
        Crudo crudo = !esNuevo
                ? crudoRepository.findById(idCrudo).orElseThrow(() -> new RuntimeException("Crudo no encontrado"))
                : new Crudo();

        crudo.setNombreCrudo(nombreCrudo.trim());
        crudo.setEstado(estado);

        crudoRepository.save(crudo);
        auditoriaSessionService.registrarComentario("CRUDO", crudo.getIdCrudo(),
                esNuevo ? "INSERT" : "UPDATE",
                (esNuevo ? "Creó" : "Editó") + " el crudo " + crudo.getNombreCrudo() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/crudos";
    }

    @PostMapping("/eliminar/{idCrudo}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idCrudo, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        if (padreRepo.existsByCrudo_IdCrudo(idCrudo) || tipoCostoRepository.existsByCrudo_IdCrudo(idCrudo)) {
            redirectAttributes.addFlashAttribute("error",
                    "Este crudo tiene distribuciones o tipos de costo asociados, no se puede eliminar");
            return "redirect:/mantenimiento/crudos";
        }

        String nombreEliminado = crudoRepository.findById(idCrudo).map(Crudo::getNombreCrudo).orElse("(desconocido)");
        try {
            crudoRepository.deleteById(idCrudo);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados");
            return "redirect:/mantenimiento/crudos";
        }
        auditoriaSessionService.registrarComentario("CRUDO", idCrudo, "DELETE",
                "Eliminó el crudo " + nombreEliminado + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/crudos";
    }
}
