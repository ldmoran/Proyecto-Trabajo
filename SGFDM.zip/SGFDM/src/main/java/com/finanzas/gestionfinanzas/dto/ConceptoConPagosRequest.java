package com.finanzas.gestionfinanzas.dto;

import java.util.List;

// Un Concepto de Provisión + los pagos que el usuario eligió para cubrirlo,
// dentro de un lote de "Pendiente" con varios conceptos a la vez (ver
// ProvisionesController.crearAnteriorLote / ProvisionRegistroService).
public class ConceptoConPagosRequest {

    private Long idConcepto;
    private List<PagoSeleccionadoRequest> pagos;

    public Long getIdConcepto() { return idConcepto; }
    public void setIdConcepto(Long idConcepto) { this.idConcepto = idConcepto; }

    public List<PagoSeleccionadoRequest> getPagos() { return pagos; }
    public void setPagos(List<PagoSeleccionadoRequest> pagos) { this.pagos = pagos; }
}
