package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.dto.ControlIngresoReporteDTO;
import com.finanzas.gestionfinanzas.entity.EnvioEbs;
import com.finanzas.gestionfinanzas.entity.EnvioEbsCuenta;
import com.finanzas.gestionfinanzas.entity.EnvioEbsFactura;
import com.finanzas.gestionfinanzas.repository.bdd.EnvioEbsCuentaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.EnvioEbsFacturaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.EnvioEbsRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturaCuentaRepository;
import com.finanzas.gestionfinanzas.service.impl.ControlIngresoExcelService;
import com.finanzas.gestionfinanzas.service.impl.ControlIngresoReporteService;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.xhtmlrenderer.pdf.ITextRenderer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Base64;
import java.util.List;

// Solo lectura: muestra el respaldo por factura/cuenta (FACTURA_CUENTA) y el
// historial de envíos a EBS ya guardados (ENVIO_EBS). No hay nada que
// crear/editar/eliminar desde acá.
@Controller
@RequestMapping("/reportes")
public class ReportesController {

    private final FacturaCuentaRepository facturaCuentaRepository;
    private final EnvioEbsRepository envioEbsRepository;
    private final EnvioEbsCuentaRepository envioEbsCuentaRepository;
    private final EnvioEbsFacturaRepository envioEbsFacturaRepository;
    private final ControlIngresoReporteService controlIngresoReporteService;
    private final ControlIngresoExcelService controlIngresoExcelService;
    private final SpringTemplateEngine templateEngine;
    private final String logoBase64;

    public ReportesController(FacturaCuentaRepository facturaCuentaRepository,
                              EnvioEbsRepository envioEbsRepository,
                              EnvioEbsCuentaRepository envioEbsCuentaRepository,
                              EnvioEbsFacturaRepository envioEbsFacturaRepository,
                              ControlIngresoReporteService controlIngresoReporteService,
                              ControlIngresoExcelService controlIngresoExcelService,
                              SpringTemplateEngine templateEngine) {
        this.facturaCuentaRepository = facturaCuentaRepository;
        this.envioEbsRepository = envioEbsRepository;
        this.envioEbsCuentaRepository = envioEbsCuentaRepository;
        this.envioEbsFacturaRepository = envioEbsFacturaRepository;
        this.controlIngresoReporteService = controlIngresoReporteService;
        this.controlIngresoExcelService = controlIngresoExcelService;
        this.templateEngine = templateEngine;
        this.logoBase64 = cargarLogoBase64();
    }

    private String cargarLogoBase64() {
        try {
            byte[] bytes = StreamUtils.copyToByteArray(new ClassPathResource("static/images/logo.png").getInputStream());
            return Base64.getEncoder().encodeToString(bytes);
        } catch (IOException e) {
            return null;
        }
    }

    @GetMapping
    public String reportes(@RequestParam(defaultValue = "0") int pageFacturaCuenta,
                           @RequestParam(defaultValue = "0") int pageEnvios,
                           HttpServletRequest request, Model model) {
        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("facturaCuentaPage", facturaCuentaRepository.findAllConDetalle(PageRequest.of(pageFacturaCuenta, 10)));
        model.addAttribute("enviosPage", envioEbsRepository.findAllOrdenado(PageRequest.of(pageEnvios, 10)));
        return "reportes";
    }

    @GetMapping("/envios/{idEnvioEbs}/detalle")
    public String detalleEnvio(@PathVariable Long idEnvioEbs, Model model) {
        List<EnvioEbsCuenta> cuentas = envioEbsCuentaRepository.findByEnvioEbs_IdEnvioEbs(idEnvioEbs);
        List<EnvioEbsFactura> facturas = envioEbsFacturaRepository.findByEnvioEbs_IdEnvioEbs(idEnvioEbs);

        model.addAttribute("cuentas", cuentas);
        model.addAttribute("facturas", facturas);
        return "fragments/envio-ebs-detalle :: envioEbsDetalleFragment";
    }

    @GetMapping("/envios/{idEnvioEbs}/pdf")
    public void descargarPdfEnvio(@PathVariable Long idEnvioEbs, HttpServletResponse response) throws IOException {
        EnvioEbs envio = envioEbsRepository.findById(idEnvioEbs)
                .orElseThrow(() -> new RuntimeException("Envío no encontrado"));
        List<EnvioEbsCuenta> cuentas = envioEbsCuentaRepository.findByEnvioEbs_IdEnvioEbs(idEnvioEbs);
        List<EnvioEbsFactura> facturas = envioEbsFacturaRepository.findByEnvioEbs_IdEnvioEbs(idEnvioEbs);

        Context context = new Context();
        context.setVariable("envio", envio);
        context.setVariable("cuentas", cuentas);
        context.setVariable("facturas", facturas);
        context.setVariable("logoBase64", logoBase64);

        String html = templateEngine.process("pdf/envio-ebs-pdf", context);

        ITextRenderer renderer = new ITextRenderer();
        renderer.setDocumentFromString(html);
        renderer.layout();

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "inline; filename=envio-ebs-" + idEnvioEbs + ".pdf");
        renderer.createPDF(response.getOutputStream());
    }

    // Control de Ingresos: una fila por distribución de cada factura Aprobada, con
    // su volumen, precio, valor del embarque y los costos congelados al aprobar.
    @GetMapping("/control-ingresos/pdf")
    public void controlIngresosPdf(@RequestParam(required = false) String desde,
                                   @RequestParam(required = false) String hasta,
                                   HttpServletResponse response) throws IOException {
        ControlIngresoReporteDTO reporte = controlIngresoReporteService.generar(desde, hasta);

        Context context = new Context();
        context.setVariable("reporte", reporte);
        context.setVariable("logoBase64", logoBase64);

        String html = templateEngine.process("pdf/control-ingresos-pdf", context);

        ITextRenderer renderer = new ITextRenderer();
        renderer.setDocumentFromString(html);
        renderer.layout();

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "inline; filename=control-ingresos.pdf");
        renderer.createPDF(response.getOutputStream());
    }

    @GetMapping("/control-ingresos/excel")
    public void controlIngresosExcel(@RequestParam(required = false) String desde,
                                     @RequestParam(required = false) String hasta,
                                     HttpServletResponse response) throws IOException {
        ControlIngresoReporteDTO reporte = controlIngresoReporteService.generar(desde, hasta);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=control-ingresos.xlsx");
        controlIngresoExcelService.escribir(reporte, response.getOutputStream());
    }
}
