package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.Costos;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CostoRepository extends JpaRepository<Costos, Long> {

    @Query("SELECT c FROM Costos c JOIN FETCH c.tipoCosto tc LEFT JOIN FETCH tc.crudo LEFT JOIN FETCH tc.crudoEntidad WHERE UPPER(c.estado) = UPPER(:estado)")
    List<Costos> findByEstadoIgnoreCase(@Param("estado") String estado);

    @Query("SELECT c FROM Costos c JOIN FETCH c.tipoCosto tc LEFT JOIN FETCH tc.crudo LEFT JOIN FETCH tc.crudoEntidad ORDER BY tc.crudo.nombreCrudo, tc.nombreCosto")
    List<Costos> findAllConTipoCosto();

    boolean existsByTipoCosto_IdTipoCosto(Long idTipoCosto);

    @Query(value = "SELECT c FROM Costos c " +
            "JOIN FETCH c.tipoCosto tc " +
            "LEFT JOIN FETCH tc.crudo cr " +
            "LEFT JOIN FETCH tc.crudoEntidad ce " +
            "WHERE (:idCrudo IS NULL OR cr.idCrudo = :idCrudo) " +
            "AND (:idGrupo IS NULL OR ce.idGrupo = :idGrupo) " +
            "AND (:idTipoCosto IS NULL OR tc.idTipoCosto = :idTipoCosto) " +
            "AND (:estado IS NULL OR UPPER(c.estado) = UPPER(:estado)) " +
            "ORDER BY cr.nombreCrudo, ce.nombreGrupo, tc.nombreCosto",
            countQuery = "SELECT COUNT(c) FROM Costos c " +
            "JOIN c.tipoCosto tc " +
            "LEFT JOIN tc.crudo cr " +
            "LEFT JOIN tc.crudoEntidad ce " +
            "WHERE (:idCrudo IS NULL OR cr.idCrudo = :idCrudo) " +
            "AND (:idGrupo IS NULL OR ce.idGrupo = :idGrupo) " +
            "AND (:idTipoCosto IS NULL OR tc.idTipoCosto = :idTipoCosto) " +
            "AND (:estado IS NULL OR UPPER(c.estado) = UPPER(:estado))")
    Page<Costos> buscar(@Param("idCrudo") Long idCrudo,
                        @Param("idGrupo") Long idGrupo,
                        @Param("idTipoCosto") Long idTipoCosto,
                        @Param("estado") String estado,
                        Pageable pageable);

    @Query("SELECT DISTINCT c FROM Costos c " +
            "JOIN FETCH c.tipoCosto tc " +
            "LEFT JOIN FETCH tc.crudo " +
            "LEFT JOIN FETCH tc.crudoEntidad " +
            "WHERE tc.idTipoCosto IN (" +
            "  SELECT i.tipoCosto.idTipoCosto FROM Ingreso i WHERE i.detalleDistribucion.factura.idFactura = :idFactura" +
            ") ORDER BY tc.crudo.nombreCrudo, tc.nombreCosto")
    List<Costos> findByFactura(@Param("idFactura") Long idFactura);
    @Query("SELECT c.valor FROM Costos c WHERE c.tipoCosto.idTipoCosto = :idTipoCosto")
Double findValorByTipoCosto(Long idTipoCosto);

    List<Costos> findByTipoCosto_IdTipoCostoIn(List<Long> idsTipoCosto);

    List<Costos> findByTipoCosto_IdTipoCostoInAndEstado(List<Long> idsTipoCosto, String estado);

    // Reactiva los costos que quedaron pendientes (no es por costo puntual) cuando
    // se sube el Comprobante de Costos global; ver ArchivoService.subirComprobanteCostos.
    // Se acota a los que NO están activos: si se tocaran todos, el trigger de
    // auditoría registraría una edición por cada costo del catálogo aunque no
    // hubiera cambiado nada.
    @Modifying
    @Query("UPDATE Costos c SET c.estado = 'ACTIVO' WHERE c.estado <> 'ACTIVO'")
    void activarTodos();

}
