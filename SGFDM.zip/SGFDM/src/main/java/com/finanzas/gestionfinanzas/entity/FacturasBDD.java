package com.finanzas.gestionfinanzas.entity;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "FACTURAS")
public class FacturasBDD {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_FACTURA")
    private Long idFactura;

    @Column(name = "CUSTOMER_TRX_ID")
    private Long customerTrxId;

    @Column(name = "NUM_FACTURA")
    private String numFactura;

    @Column(name = "FEC_EMBARQUE")
    private String fecEmbarque;

    @Column(name = "FEC_DEPOSITO")
    private String fecDeposito;

    @Column(name = "RUC")
    private String ruc;

    @Column(name = "COMPANIA")
    private String compania;

    @Column(name = "CONTRATO")
    private String contrato;

    @Column(name = "BUQUE")
    private String buque;

    @Column(name = "CANTIDAD")
    // Barriles del embarque. Viene con decimales desde el ERP (ej. 357051,76):
    // mapearlo como entero recortaba la parte decimal.
    private Double cantidad;

    @Column(name = "PRECIO")
    private Double precio;

    @Column(name = "SUBTOTAL")
    private Double subtotal;

    @Column(name = "DESCRIPCION")
    private String descripcion;

    @Column(name = "FEC_FACTURA")
    private String fecFactura;

    @Column(name = "ID_DISTRIBUCION")
    private Long idDistribucion;

    @Column(name = "ESTADO")
    private String estado;

    @Column(name = "VOLUMEN_TOTAL")
    private Double volumenTotal;

    @Column(name = "VOLUMEN_DISTRIBUIDO")
    private Double volumenDistribuido;

    @Column(name = "VOLUMEN_FALTANTE")
    private Double volumenFaltante;

    // Columna aparte del ESTADO (Registrada/Aprobada): null = nunca usó reparto
    // parcial, 'P' = Parcial (le falta volumen por distribuir), 'C' = Completado
    // (el volumen distribuido en todas sus rondas ya llegó a la CANTIDAD original).
    @Column(name = "ESTADO_PARCIAL")
    private String estadoParcial;

    // 0 = ronda activa/pendiente (Registrada), 1 = ronda ya Aprobada (cerrada).
    // Solo puede haber UNA fila con SECUENCIA = 0 por CUSTOMER_TRX_ID a la vez
    // (ver DistribucionService.crearNuevaRonda).
    @Column(name = "SECUENCIA")
    private Integer secuencia;

    // Última vez que se tocó la factura (se sincronizó, se le guardaron o editaron
    // distribuciones, o se aprobó). Es lo que ordena los listados: lo último
    // trabajado sale primero, en vez del orden en que llegaron del ERP.
    @Column(name = "FECHA_MODIFICACION")
    private LocalDateTime fechaModificacion;

    // Marcado manual (rol FACTURA o jefatura): la factura ya está Aprobada y su
    // cálculo se ve normal en Ingresos/reportes, pero llegó a destiempo y NO debe
    // ofrecerse para seleccionarla en un envío a EBS (ver EnvioEbsService).
    @Column(name = "EXCLUIDA_EBS")
    private String excluidaEbs;

    @Column(name = "MOTIVO_EXCLUSION_EBS")
    private String motivoExclusionEbs;

    @Column(name = "ID_USUARIO_EXCLUSION")
    private String idUsuarioExclusion;

    @Column(name = "FECHA_EXCLUSION")
    private LocalDateTime fechaExclusion;

    // Getters y setters correctos
    public Long getIdFactura() { return idFactura; }
    public void setIdFactura(Long idFactura) { this.idFactura = idFactura; }

    public Long getCustomerTrxId() { return customerTrxId; }
    public void setCustomerTrxId(Long customerTrxId) { this.customerTrxId = customerTrxId; }

    public String getNumFactura() { return numFactura; }
    public void setNumFactura(String numFactura) { this.numFactura = numFactura; }

    public String getFecEmbarque() { return fecEmbarque; }
    public void setFecEmbarque(String fecEmbarque) { this.fecEmbarque = fecEmbarque; }

    public String getFecDeposito() { return fecDeposito; }
    public void setFecDeposito(String fecDeposito) { this.fecDeposito = fecDeposito; }

    public String getRuc() { return ruc; }
    public void setRuc(String ruc) { this.ruc = ruc; }

    public String getCompania() { return compania; }
    public void setCompania(String compania) { this.compania = compania; }

    public String getContrato() { return contrato; }
    public void setContrato(String contrato) { this.contrato = contrato; }

    public String getBuque() { return buque; }
    public void setBuque(String buque) { this.buque = buque; }

    public Double getCantidad() { return cantidad; }
    public void setCantidad(Double cantidad) { this.cantidad = cantidad; }

    public Double getPrecio() { return precio; }
    public void setPrecio(Double precio) { this.precio = precio; }

    public Double getSubtotal() { return subtotal; }
    public void setSubtotal(Double subtotal) { this.subtotal = subtotal; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getFecFactura() { return fecFactura; }
    public void setFecFactura(String fecFactura) { this.fecFactura = fecFactura; }

    public Long getIdDistribucion() { return idDistribucion; }
    public void setIdDistribucion(Long idDistribucion) { this.idDistribucion = idDistribucion; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public Double getVolumenTotal() { return volumenTotal; }
    public void setVolumenTotal(Double volumenTotal) { this.volumenTotal = volumenTotal; }

    public Double getVolumenDistribuido() { return volumenDistribuido; }
    public void setVolumenDistribuido(Double volumenDistribuido) { this.volumenDistribuido = volumenDistribuido; }

    public Double getVolumenFaltante() { return volumenFaltante; }
    public void setVolumenFaltante(Double volumenFaltante) { this.volumenFaltante = volumenFaltante; }

    public String getEstadoParcial() { return estadoParcial; }
    public void setEstadoParcial(String estadoParcial) { this.estadoParcial = estadoParcial; }

    public Integer getSecuencia() { return secuencia; }
    public void setSecuencia(Integer secuencia) { this.secuencia = secuencia; }

    public LocalDateTime getFechaModificacion() { return fechaModificacion; }
    public void setFechaModificacion(LocalDateTime fechaModificacion) { this.fechaModificacion = fechaModificacion; }

    public String getExcluidaEbs() { return excluidaEbs; }
    public void setExcluidaEbs(String excluidaEbs) { this.excluidaEbs = excluidaEbs; }

    public String getMotivoExclusionEbs() { return motivoExclusionEbs; }
    public void setMotivoExclusionEbs(String motivoExclusionEbs) { this.motivoExclusionEbs = motivoExclusionEbs; }

    public String getIdUsuarioExclusion() { return idUsuarioExclusion; }
    public void setIdUsuarioExclusion(String idUsuarioExclusion) { this.idUsuarioExclusion = idUsuarioExclusion; }

    public LocalDateTime getFechaExclusion() { return fechaExclusion; }
    public void setFechaExclusion(LocalDateTime fechaExclusion) { this.fechaExclusion = fechaExclusion; }
}

