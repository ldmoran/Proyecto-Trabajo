package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.ResumenGrupoPagoDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Lectura cruda de Cuentas por Pagar del ERP (vista APPS.XXOCS_AP_CXP_CONS_V,
// datasource "apps"/primary). No sabe nada de "ya comprometida por otro
// reporte" ni de cobertura — eso lo resuelve FlujoCajaCxpPagableService, que
// cruza esto con nuestra base propia (dos Oracle físicamente distintos, no se
// pueden cruzar en un solo SELECT).
//
// SQL nativo directo en vez de mapear una @Entity completa para la vista
// (mismo patrón que EstadoFacturaErpService, que también pega contra "apps"
// con EntityManager crudo).
@Service
public class EgresoCxpService {

    private static final String SQL_TOTAL_ADEUDADO =
            "SELECT NVL(SUM(IMPORTE_A_PAGAR), 0) FROM APPS.XXOCS_AP_CXP_CONS_V";

    // Trae TODAS las facturas de la vista, en el orden de prioridad de pago
    // (columna ORDEN) que ya viene armado desde el ERP. Las fechas salen como
    // texto ISO (TO_CHAR) para no lidiar con conversión de tipos Oracle DATE ->
    // Java en un resultado nativo de columnas sueltas.
    private static final String SQL_TODAS_LAS_FACTURAS =
            "SELECT ORDEN, FUENTE, INVOICE_ID, PROVEEDOR, TIPO_DOCUMENTO, DOCUMENTO, " +
            "       TO_CHAR(FECHA_DOCUMENTO, 'YYYY-MM-DD') AS FECHA_DOC_STR, " +
            "       TERMINO_PAGO, GRUPO_PAGO, CATEGORIA, METODO_PAGO, " +
            "       TO_CHAR(FECHA_VENCIMIENTO, 'YYYY-MM-DD') AS FECHA_VENC_STR, " +
            "       IMPORTE_A_PAGAR, DESCRIPCION, PRIORIZADO " +
            "FROM APPS.XXOCS_AP_CXP_CONS_V " +
            "ORDER BY ORDEN";

    // Subtotal de IMPORTE_A_PAGAR agrupado por GRUPO_PAGO (código crudo del ERP, ej.
    // "GT_UI", "GCI_GCI"; algunos vienen ya con la descripción larga en vez de un
    // código, como "BCE INVERSION" — se dejan tal cual si no matchean con ningún
    // LOOKUP_CODE de abajo).
    private static final String SQL_RESUMEN_POR_GRUPO_PAGO =
            "SELECT NVL(GRUPO_PAGO, 'SIN GRUPO') AS GRUPO_PAGO, SUM(IMPORTE_A_PAGAR) AS TOTAL " +
            "FROM APPS.XXOCS_AP_CXP_CONS_V " +
            "GROUP BY GRUPO_PAGO " +
            "ORDER BY SUM(IMPORTE_A_PAGAR) DESC";

    // Catálogo de descripciones de "Grupo de Pago" del ERP (Oracle EBS,
    // FND_LOOKUP_VALUES_VL). Se consulta en vivo cada vez (no se copia a una tabla
    // propia) para no tener que mantenerla sincronizada a mano si el ERP agrega un
    // código nuevo.
    private static final String SQL_DESCRIPCIONES_GRUPO_PAGO =
            "SELECT LOOKUP_CODE, DESCRIPTION FROM FND_LOOKUP_VALUES_VL " +
            "WHERE LOOKUP_TYPE = 'PAY GROUP' AND ENABLED_FLAG = 'Y'";

    @PersistenceContext(unitName = "primary")
    private EntityManager entityManager;

    @Transactional("primaryTransactionManager")
    public BigDecimal totalAdeudado() {
        Object resultado = entityManager.createNativeQuery(SQL_TOTAL_ADEUDADO).getSingleResult();
        return resultado instanceof BigDecimal ? (BigDecimal) resultado : new BigDecimal(resultado.toString());
    }

    // Desglose del total adeudado por Grupo de Pago, para el resumen de la pantalla
    // de Flujo de Caja. Trae los dos SELECTs por separado (en vez de un JOIN) porque
    // no todo GRUPO_PAGO de la vista de CxP tiene necesariamente un LOOKUP_CODE
    // activo que lo matchee — un JOIN se comería esas filas; acá quedan con su
    // código/valor crudo como descripción.
    @Transactional("primaryTransactionManager")
    public List<ResumenGrupoPagoDTO> resumenPorGrupoPago() {
        @SuppressWarnings("unchecked")
        List<Object[]> totales = entityManager.createNativeQuery(SQL_RESUMEN_POR_GRUPO_PAGO).getResultList();
        Map<String, String> descripcionPorCodigo = descripcionesGrupoPago();

        List<ResumenGrupoPagoDTO> resultado = new ArrayList<>();
        for (Object[] fila : totales) {
            String codigo = (String) fila[0];
            BigDecimal total = fila[1] instanceof BigDecimal ? (BigDecimal) fila[1] : new BigDecimal(fila[1].toString());
            resultado.add(new ResumenGrupoPagoDTO(codigo, descripcionPorCodigo.getOrDefault(codigo, codigo), total));
        }
        return resultado;
    }

    // Código -> descripción de "Grupo de Pago" (FND_LOOKUP_VALUES_VL). Aparte de
    // resumenPorGrupoPago, lo usa el controller para armar el combo "Gerencia" del
    // buscador de facturas pagables (ver FlujoCajaReporteController.buscarPagablesCxp).
    @Transactional("primaryTransactionManager")
    public Map<String, String> descripcionesGrupoPago() {
        @SuppressWarnings("unchecked")
        List<Object[]> descripciones = entityManager.createNativeQuery(SQL_DESCRIPCIONES_GRUPO_PAGO).getResultList();
        Map<String, String> descripcionPorCodigo = new HashMap<>();
        for (Object[] fila : descripciones) {
            descripcionPorCodigo.put((String) fila[0], (String) fila[1]);
        }
        return descripcionPorCodigo;
    }

    // Fila: [0]=ORDEN, [1]=FUENTE, [2]=INVOICE_ID, [3]=PROVEEDOR, [4]=TIPO_DOCUMENTO,
    // [5]=DOCUMENTO, [6]=FECHA_DOC_STR, [7]=TERMINO_PAGO, [8]=GRUPO_PAGO, [9]=CATEGORIA,
    // [10]=METODO_PAGO, [11]=FECHA_VENC_STR, [12]=IMPORTE_A_PAGAR, [13]=DESCRIPCION, [14]=PRIORIZADO.
    // FUENTE es lo que distingue PAM ("EXPLORACIÓN Y PRODUCCIÓN") de PEC ("GERENCIAS
    // PETROECUADOR"). PRIORIZADO (SI/NO) es lo que distingue la sección 3) Priorizado
    // (Fondos Disponibles = NO) de la 4) Pendientes de Ejecutar (SI) — ver
    // FlujoCajaCxpPagableService.resumenPorFuente.
    @Transactional("primaryTransactionManager")
    public List<Object[]> obtenerTodasLasFacturas() {
        @SuppressWarnings("unchecked")
        List<Object[]> filas = entityManager.createNativeQuery(SQL_TODAS_LAS_FACTURAS).getResultList();
        return filas;
    }
}
