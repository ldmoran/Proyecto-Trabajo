package com.finanzas.gestionfinanzas.dto;

public class ResponsableFlujoCajaDTO {

    private final Long idUsuario;
    private final String usuario;
    private final String nombreCompleto;
    private final String email;
    private final boolean elaborador;
    private final boolean aprobador;
    private final boolean autorizador;

    public ResponsableFlujoCajaDTO(Long idUsuario, String usuario, String nombreCompleto, String email,
                                    boolean elaborador, boolean aprobador, boolean autorizador) {
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.nombreCompleto = nombreCompleto;
        this.email = email;
        this.elaborador = elaborador;
        this.aprobador = aprobador;
        this.autorizador = autorizador;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getEmail() {
        return email;
    }

    public boolean isElaborador() {
        return elaborador;
    }

    public boolean isAprobador() {
        return aprobador;
    }

    public boolean isAutorizador() {
        return autorizador;
    }
}
