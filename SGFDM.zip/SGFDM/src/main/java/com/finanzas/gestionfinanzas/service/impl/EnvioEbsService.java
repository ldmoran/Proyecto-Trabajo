package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.CuentaConsolidadaDTO;
import com.finanzas.gestionfinanzas.entity.Cuenta;
import com.finanzas.gestionfinanzas.entity.EnvioEbs;
import com.finanzas.gestionfinanzas.entity.EnvioEbsCuenta;
import com.finanzas.gestionfinanzas.entity.EnvioEbsFactura;
import com.finanzas.gestionfinanzas.entity.FactFlujoCaja;
import com.finanzas.gestionfinanzas.entity.FacturaCuenta;
import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import com.finanzas.gestionfinanzas.entity.FlujoCajaReporte;
import com.finanzas.gestionfinanzas.repository.bdd.EnvioEbsCuentaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.EnvioEbsFacturaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.EnvioEbsRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturaCuentaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaReporteRepository;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

// Consolida, por cuenta contable, el total recolectado entre varias facturas
// Aprobadas seleccionadas en la pantalla de Ingresos, y persiste ese consolidado
// como un "envío a EBS" cuando el usuario lo confirma.
@Service
public class EnvioEbsService {

    private final FacturaCuentaRepository facturaCuentaRepository;
    private final FacturasBDDRepository facturasBDDRepository;
    private final EnvioEbsRepository envioEbsRepository;
    private final EnvioEbsFacturaRepository envioEbsFacturaRepository;
    private final EnvioEbsCuentaRepository envioEbsCuentaRepository;
    private final FactFlujoCajaService factFlujoCajaService;
    private final AuditoriaSessionService auditoriaSessionService;
    private final FlujoCajaReporteRepository flujoCajaReporteRepository;

    public EnvioEbsService(FacturaCuentaRepository facturaCuentaRepository,
                           FacturasBDDRepository facturasBDDRepository,
                           EnvioEbsRepository envioEbsRepository,
                           EnvioEbsFacturaRepository envioEbsFacturaRepository,
                           EnvioEbsCuentaRepository envioEbsCuentaRepository,
                           FactFlujoCajaService factFlujoCajaService,
                           AuditoriaSessionService auditoriaSessionService,
                           FlujoCajaReporteRepository flujoCajaReporteRepository) {
        this.facturaCuentaRepository = facturaCuentaRepository;
        this.facturasBDDRepository = facturasBDDRepository;
        this.envioEbsRepository = envioEbsRepository;
        this.envioEbsFacturaRepository = envioEbsFacturaRepository;
        this.envioEbsCuentaRepository = envioEbsCuentaRepository;
        this.factFlujoCajaService = factFlujoCajaService;
        this.auditoriaSessionService = auditoriaSessionService;
        this.flujoCajaReporteRepository = flujoCajaReporteRepository;
    }

    public List<CuentaConsolidadaDTO> previsualizarConsolidado(List<Long> idsFactura) {
        Agregado agregado = agregar(idsFactura);

        List<CuentaConsolidadaDTO> resultado = new ArrayList<>();
        for (Map.Entry<Long, Double> entry : agregado.subtotalPorCuenta.entrySet()) {
            Cuenta cuenta = agregado.cuentasPorId.get(entry.getKey());
            resultado.add(new CuentaConsolidadaDTO(
                    cuenta != null ? cuenta.getNumeroCuenta() : "Sin cuenta asignada",
                    cuenta != null ? cuenta.getDescripcion() : null,
                    entry.getValue()));
        }
        return resultado;
    }

    @Transactional("secondTransactionManager")
    public EnvioEbs guardarEnvio(List<Long> idsFactura, LocalDate periodoDestino) {
        if (idsFactura == null || idsFactura.isEmpty()) {
            throw new RuntimeException("Selecciona al menos una factura");
        }
        if (periodoDestino == null) {
            throw new RuntimeException("Selecciona a qué semana va este envío");
        }

        // Si esa semana ya tiene su Flujo de Caja firmado (al menos "Elaborado"),
        // no se puede seguir sumándole ingresos por detrás sin que quede reflejado
        // en el reporte ya cerrado — hay que mandarlo para la semana siguiente.
        Optional<FlujoCajaReporte> reportePeriodo = flujoCajaReporteRepository.findByFechaInicio(periodoDestino);
        if (reportePeriodo.isPresent()) {
            FlujoCajaReporte reporte = reportePeriodo.get();
            boolean firmado = reporte.getElaboradoPor() != null || "A".equals(reporte.getEstado());
            if (firmado) {
                throw new RuntimeException("El Flujo de Caja de esa semana ya está firmado (Elaborado o Autorizado) — seleccione la semana siguiente");
            }
        }

        auditoriaSessionService.activarUsuarioActual();

        for (Long idFactura : idsFactura) {
            if (envioEbsFacturaRepository.existsByFactura_IdFactura(idFactura)) {
                throw new RuntimeException("Una de las facturas seleccionadas ya fue enviada a EBS anteriormente");
            }

            FacturasBDD factura = facturasBDDRepository.findById(idFactura)
                    .orElseThrow(() -> new RuntimeException("Factura no encontrada"));
            if ("S".equals(factura.getExcluidaEbs())) {
                throw new RuntimeException("Una de las facturas seleccionadas está marcada como no enviar a EBS (llegó a destiempo)");
            }
        }

        Agregado agregado = agregar(idsFactura);

        // Se manda primero al lado EBS (XXOCS_AR_FACT_FLUJO_CAJA): si esto falla, no debe
        // quedar registrado un envío local que en realidad nunca llegó a EBS.
        LocalDateTime ahora = LocalDateTime.now();
        List<FactFlujoCaja> filasFlujoCaja = new ArrayList<>();
        for (FacturaCuenta fc : agregado.filas) {
            if (fc.getFactura() == null || fc.getSubtotal() == null) {
                continue;
            }

            FactFlujoCaja fila = new FactFlujoCaja();
            fila.setCustomerTrxId(fc.getFactura().getCustomerTrxId());
            fila.setCuentaBanco(soloNumerico(fc.getCuenta() != null ? fc.getCuenta().getNumeroCuenta() : null));
            fila.setMonto(fc.getSubtotal());
            fila.setFechaCarga(ahora);
            filasFlujoCaja.add(fila);
        }
        factFlujoCajaService.guardarLote(filasFlujoCaja);

        String usuarioActual = SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;

        double totalGeneral = agregado.subtotalPorCuenta.values().stream().mapToDouble(Double::doubleValue).sum();

        EnvioEbs envio = new EnvioEbs();
        envio.setFechaEnvio(LocalDateTime.now());
        envio.setFechaPeriodo(periodoDestino);
        envio.setIdUsuarioCreacion(usuarioActual);
        envio.setTotalGeneral(totalGeneral);
        envioEbsRepository.save(envio);

        for (Long idFactura : idsFactura) {
            FacturasBDD factura = facturasBDDRepository.findById(idFactura)
                    .orElseThrow(() -> new RuntimeException("Factura no encontrada"));

            EnvioEbsFactura detalle = new EnvioEbsFactura();
            detalle.setEnvioEbs(envio);
            detalle.setFactura(factura);
            detalle.setTotalFactura(agregado.totalPorFactura.getOrDefault(idFactura, 0.0));
            envioEbsFacturaRepository.save(detalle);
        }

        for (Map.Entry<Long, Double> entry : agregado.subtotalPorCuenta.entrySet()) {
            EnvioEbsCuenta detalleCuenta = new EnvioEbsCuenta();
            detalleCuenta.setEnvioEbs(envio);
            detalleCuenta.setCuenta(agregado.cuentasPorId.get(entry.getKey()));
            detalleCuenta.setSubtotal(entry.getValue());
            envioEbsCuentaRepository.save(detalleCuenta);
        }

        auditoriaSessionService.registrarComentario("ENVIO_EBS", envio.getIdEnvioEbs(), "INSERT",
                "Envió a EBS " + idsFactura.size() + " factura(s) por $" + String.format("%,.2f", totalGeneral)
                        + " para la semana del " + periodoDestino);

        return envio;
    }

    // XXOCS_AR_FACT_FLUJO_CAJA.CUENTA_BANCO debe llevar solo la parte numérica del
    // número de cuenta (ej. "EC-1310101" -> "1310101"), sin el prefijo "EC-".
    private String soloNumerico(String numeroCuenta) {
        if (numeroCuenta == null) {
            return null;
        }
        String numerico = numeroCuenta.replaceAll("[^0-9]", "");
        return numerico.isEmpty() ? null : numerico;
    }

    private Agregado agregar(List<Long> idsFactura) {
        Agregado agregado = new Agregado();

        if (idsFactura == null || idsFactura.isEmpty()) {
            return agregado;
        }

        List<FacturaCuenta> filas = facturaCuentaRepository.findConCuentaByFacturaIn(idsFactura);
        agregado.filas = filas;

        for (FacturaCuenta fc : filas) {
            if (fc.getFactura() == null || fc.getSubtotal() == null) {
                continue;
            }

            Long idFactura = fc.getFactura().getIdFactura();
            agregado.totalPorFactura.merge(idFactura, fc.getSubtotal(), Double::sum);

            Cuenta cuenta = fc.getCuenta();
            Long idCuenta = cuenta != null ? cuenta.getIdCuenta() : -1L;
            agregado.cuentasPorId.putIfAbsent(idCuenta, cuenta);
            agregado.subtotalPorCuenta.merge(idCuenta, fc.getSubtotal(), Double::sum);
        }

        return agregado;
    }

    private static class Agregado {
        private final Map<Long, Double> totalPorFactura = new LinkedHashMap<>();
        private final Map<Long, Cuenta> cuentasPorId = new LinkedHashMap<>();
        private final Map<Long, Double> subtotalPorCuenta = new LinkedHashMap<>();
        private List<FacturaCuenta> filas = new ArrayList<>();
    }
}
