package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

// Catálogo de conceptos para las secciones 6) SRI, 7) SHAYA BOC2 y 8) HEDGE de
// Flujo de Caja > Egresos (ver FC_EGR_TRANSFERENCIA en reset_bd.sql).
@Entity
@Table(name = "FC_EGR_CONCEPTO_TRANSF")
public class ConceptoTransferencia {

    public static final String TIPO_SRI = "SRI";
    public static final String TIPO_SHAYA_BOC2 = "SHAYA_BOC2";
    public static final String TIPO_HEDGE = "HEDGE";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CONCEPTO")
    private Long idConcepto;

    @Column(name = "TIPO")
    private String tipo;

    @Column(name = "NOMBRE_CONCEPTO")
    private String nombreConcepto;

    @Column(name = "ESTADO")
    private String estado;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdConcepto() { return idConcepto; }
    public void setIdConcepto(Long idConcepto) { this.idConcepto = idConcepto; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getNombreConcepto() { return nombreConcepto; }
    public void setNombreConcepto(String nombreConcepto) { this.nombreConcepto = nombreConcepto; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}
