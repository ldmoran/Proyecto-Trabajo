package com.finanzas.gestionfinanzas.dto;

import java.util.List;
import java.util.Map;

// Respuesta del botón "Actualizar lista de facturas a pagar": además de la
// cobertura (ver CoberturaCxpDTO), trae ya calculados los resúmenes PAM/PEC de las
// secciones 3) Priorizado y 4) Pendientes de Ejecutar (por idCategoriaEgreso), para
// que el JS los pinte sin tener que recargar toda la página.
public class ActualizarPagablesResultDTO {

    private final CoberturaCxpDTO cobertura;
    private final Map<Long, ResumenCxpFuenteDTO> priorizadoPorCategoria;
    private final Map<Long, ResumenCxpFuenteDTO> pendienteSemanaActualPorCategoria;
    // Desglose "Adeudado por Grupo de Pago" acotado a lo que se acaba de guardar en
    // la copia local (solo lo que alcanza a cubrirse con los Ingresos actuales),
    // para repintar esa tabla sin recargar toda la página (ver
    // FlujoCajaReporteController.obtenerResumenGrupoPagoLocal).
    private final List<ResumenGrupoPagoDTO> resumenGrupoPago;

    public ActualizarPagablesResultDTO(CoberturaCxpDTO cobertura,
                                        Map<Long, ResumenCxpFuenteDTO> priorizadoPorCategoria,
                                        Map<Long, ResumenCxpFuenteDTO> pendienteSemanaActualPorCategoria,
                                        List<ResumenGrupoPagoDTO> resumenGrupoPago) {
        this.cobertura = cobertura;
        this.priorizadoPorCategoria = priorizadoPorCategoria;
        this.pendienteSemanaActualPorCategoria = pendienteSemanaActualPorCategoria;
        this.resumenGrupoPago = resumenGrupoPago;
    }

    public CoberturaCxpDTO getCobertura() {
        return cobertura;
    }

    public Map<Long, ResumenCxpFuenteDTO> getPriorizadoPorCategoria() {
        return priorizadoPorCategoria;
    }

    public Map<Long, ResumenCxpFuenteDTO> getPendienteSemanaActualPorCategoria() {
        return pendienteSemanaActualPorCategoria;
    }

    public List<ResumenGrupoPagoDTO> getResumenGrupoPago() {
        return resumenGrupoPago;
    }
}
