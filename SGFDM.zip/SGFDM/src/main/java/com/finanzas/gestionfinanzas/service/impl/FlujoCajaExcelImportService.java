package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.ConceptoIngreso;
import com.finanzas.gestionfinanzas.entity.CuentaBancaria;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Lee un Excel cualquiera (no se guarda el archivo) para precargar grids de la
// pantalla de Flujo de Caja Semanal, sin depender de en qué columna venga cada
// dato: reconoce la fila por su cuenta bancaria o su concepto de ingreso, y toma
// como valor el último número que encuentre en esa misma fila.
@Service
public class FlujoCajaExcelImportService {

    private static final Pattern PATRON_NUMERO_CUENTA = Pattern.compile("\\d{5,}");

    static {
        // Los Excel de Tesorería traen el logo institucional embebido (drawing/imagen),
        // que es puro XML/vectores muy repetitivos y comprime altísimo. POI lo confunde
        // con un "zip bomb" (protección pensada para archivos subidos por desconocidos)
        // y aborta la lectura. Como estos archivos vienen de gente autenticada del propio
        // sistema, no de internet, se sube el límite en vez de desactivar la protección.
        ZipSecureFile.setMinInflateRatio(0.001);
    }

    // 1) Saldo Inicial de Caja: busca dentro del texto de cualquier celda una
    // secuencia de dígitos que calce exacto con el número de alguna cuenta
    // bancaria activa (no exige que la celda sea SOLO el número: en la práctica
    // viene mezclado en una descripción larga, ej. "EP PETROECUADOR -
    // TRANSFERENCIAS - CTA 1310023").
    //
    // OJO: el mismo número de cuenta puede volver a aparecer más abajo en el
    // Excel, en la sección "2) Ingresos por Recibir" (ej. "RECUPERACIÓN DE
    // COSTOS... - EC 1310101" repite el "1310101" de la cuenta bancaria, pero
    // ese valor es un ingreso, no el saldo de esa cuenta). Por eso se deduplica
    // por cuenta quedándose con la PRIMERA fila que matchea — la sección 1
    // siempre viene antes que la 2 en este formato — y las apariciones
    // posteriores del mismo número se ignoran en vez de pisar el valor bueno.
    public List<Map<String, Object>> leerSaldosIniciales(InputStream excel, List<CuentaBancaria> cuentasActivas) throws IOException {
        Map<String, CuentaBancaria> cuentasPorNumero = new LinkedHashMap<>();
        for (CuentaBancaria c : cuentasActivas) {
            if (c.getNumeroCuenta() != null) {
                cuentasPorNumero.put(c.getNumeroCuenta().trim(), c);
            }
        }

        Map<Long, Map<String, Object>> resultado = new LinkedHashMap<>();

        try (Workbook libro = WorkbookFactory.create(excel)) {
            Sheet hoja = libro.getSheetAt(0);

            for (Row fila : hoja) {
                CuentaBancaria cuentaEncontrada = null;
                int columnaCuenta = -1;

                for (Cell celda : fila) {
                    CuentaBancaria match = buscarCuentaEnCelda(celda, cuentasPorNumero);
                    if (match != null) {
                        cuentaEncontrada = match;
                        columnaCuenta = celda.getColumnIndex();
                        break;
                    }
                }

                if (cuentaEncontrada == null || resultado.containsKey(cuentaEncontrada.getIdCuentaBancaria())) {
                    continue;
                }

                Double valorEncontrado = buscarValorEnFila(fila, columnaCuenta);
                if (valorEncontrado == null) {
                    continue;
                }

                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id", cuentaEncontrada.getIdCuentaBancaria());
                item.put("nombre", cuentaEncontrada.getNombreCuenta());
                item.put("numero", cuentaEncontrada.getNumeroCuenta());
                item.put("valor", redondear(valorEncontrado));
                resultado.put(cuentaEncontrada.getIdCuentaBancaria(), item);
            }
        }

        return new ArrayList<>(resultado.values());
    }

    // 2) Ingresos por Recibir (solo los conceptos "Manual"; los "Automático" se
    // calculan solos desde el envío a EBS, no se importan). Acá no hay un número
    // corto que buscar como con las cuentas: se compara el nombre completo del
    // concepto contra el texto de la celda, normalizando (sin tildes, sin
    // puntuación, mayúsculas) para no fallar por una coma o un acento de más.
    // Mismo cuidado que en leerSaldosIniciales: se deduplica por concepto
    // quedándose con la primera fila que matchea, por si el nombre llegara a
    // repetirse más abajo en el Excel.
    public List<Map<String, Object>> leerIngresosManuales(InputStream excel, List<ConceptoIngreso> conceptosManuales) throws IOException {
        Map<String, ConceptoIngreso> conceptosPorNombre = new LinkedHashMap<>();
        for (ConceptoIngreso c : conceptosManuales) {
            if (c.getNombreConcepto() != null) {
                conceptosPorNombre.put(normalizar(c.getNombreConcepto()), c);
            }
        }

        Map<Long, Map<String, Object>> resultado = new LinkedHashMap<>();

        try (Workbook libro = WorkbookFactory.create(excel)) {
            Sheet hoja = libro.getSheetAt(0);

            for (Row fila : hoja) {
                ConceptoIngreso conceptoEncontrado = null;
                int columnaConcepto = -1;

                for (Cell celda : fila) {
                    if (celda.getCellType() == CellType.STRING) {
                        ConceptoIngreso match = conceptosPorNombre.get(normalizar(celda.getStringCellValue()));
                        if (match != null) {
                            conceptoEncontrado = match;
                            columnaConcepto = celda.getColumnIndex();
                            break;
                        }
                    }
                }

                if (conceptoEncontrado == null || resultado.containsKey(conceptoEncontrado.getIdConcepto())) {
                    continue;
                }

                Double valorEncontrado = buscarValorEnFila(fila, columnaConcepto);
                if (valorEncontrado == null) {
                    continue;
                }

                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id", conceptoEncontrado.getIdConcepto());
                item.put("nombre", conceptoEncontrado.getNombreConcepto());
                item.put("valor", redondear(valorEncontrado));
                resultado.put(conceptoEncontrado.getIdConcepto(), item);
            }
        }

        return new ArrayList<>(resultado.values());
    }

    // Los montos son dinero: en pantalla y al guardar se manejan con 2 decimales,
    // no con el arrastre de coma flotante que trae Excel (ej. 1541631.8204163602).
    private Double redondear(Double valor) {
        return valor == null ? null : Math.round(valor * 100.0) / 100.0;
    }

    // El valor es el último número que aparezca en la fila, sin contar la celda
    // que ya identificó la cuenta/concepto.
    private Double buscarValorEnFila(Row fila, int columnaExcluida) {
        Double valorEncontrado = null;
        for (Cell celda : fila) {
            if (celda.getColumnIndex() == columnaExcluida) {
                continue;
            }
            Double numero = celdaComoNumero(celda);
            if (numero != null) {
                valorEncontrado = numero;
            }
        }
        return valorEncontrado;
    }

    // Si la celda es numérica, se compara el número completo (una celda numérica
    // 1310023.0 debe calzar con el texto "1310023"). Si es texto, se buscan TODAS
    // las secuencias de 5+ dígitos que contenga (puede venir con la cuenta metida
    // en medio de una frase) y se prueba cada una contra el catálogo.
    private CuentaBancaria buscarCuentaEnCelda(Cell celda, Map<String, CuentaBancaria> cuentasPorNumero) {
        if (celda == null) {
            return null;
        }

        if (celda.getCellType() == CellType.NUMERIC) {
            String texto = celdaComoTexto(celda);
            return texto != null ? cuentasPorNumero.get(texto) : null;
        }

        if (celda.getCellType() == CellType.STRING) {
            Matcher m = PATRON_NUMERO_CUENTA.matcher(celda.getStringCellValue());
            while (m.find()) {
                CuentaBancaria cuenta = cuentasPorNumero.get(m.group());
                if (cuenta != null) {
                    return cuenta;
                }
            }
        }

        return null;
    }

    // Deja solo letras y dígitos en mayúsculas, sin tildes: así "Recuperación de
    // Costos..." y "RECUPERACION DE COSTOS..." (con o sin coma/punto/espacio de
    // más) comparan igual.
    private String normalizar(String texto) {
        if (texto == null) {
            return "";
        }
        String sinAcentos = Normalizer.normalize(texto, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return sinAcentos.toUpperCase().replaceAll("[^A-Z0-9]", "");
    }

    // Normaliza cualquier celda a texto para comparar contra el número de cuenta:
    // una celda numérica 1310023.0 y una celda de texto "1310023" deben calzar igual.
    private String celdaComoTexto(Cell celda) {
        if (celda == null) {
            return null;
        }
        if (celda.getCellType() == CellType.STRING) {
            return celda.getStringCellValue().trim();
        }
        if (celda.getCellType() == CellType.NUMERIC) {
            double valor = celda.getNumericCellValue();
            if (valor == Math.floor(valor) && !Double.isInfinite(valor)) {
                return String.valueOf((long) valor);
            }
            return String.valueOf(valor);
        }
        return null;
    }

    private Double celdaComoNumero(Cell celda) {
        if (celda == null) {
            return null;
        }
        if (celda.getCellType() == CellType.NUMERIC) {
            return celda.getNumericCellValue();
        }
        if (celda.getCellType() == CellType.STRING) {
            String texto = celda.getStringCellValue().trim().replace(",", "");
            if (texto.isEmpty()) {
                return null;
            }
            try {
                return Double.parseDouble(texto);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }
}
