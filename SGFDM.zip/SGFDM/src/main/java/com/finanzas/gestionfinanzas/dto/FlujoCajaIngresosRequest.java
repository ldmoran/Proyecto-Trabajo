package com.finanzas.gestionfinanzas.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

// Payload de la pantalla "Flujo de Caja > Ingresos" (secciones 1 y 2 nada más).
// Hermano liviano de FlujoCajaReporteRequest — reutiliza sus mismas clases
// internas de ítem (SaldoInicialItem/IngresoItem) para no duplicarlas.
public class FlujoCajaIngresosRequest {

    private Long idReporte; // null = reporte nuevo (esta pantalla es la que lo crea)
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private LocalDate fechaSaldoInicial;

    private List<FlujoCajaReporteRequest.SaldoInicialItem> saldosIniciales;
    private List<FlujoCajaReporteRequest.IngresoItem> ingresos;

    public Long getIdReporte() { return idReporte; }
    public void setIdReporte(Long idReporte) { this.idReporte = idReporte; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }
    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }
    public LocalDate getFechaSaldoInicial() { return fechaSaldoInicial; }
    public void setFechaSaldoInicial(LocalDate fechaSaldoInicial) { this.fechaSaldoInicial = fechaSaldoInicial; }
    public List<FlujoCajaReporteRequest.SaldoInicialItem> getSaldosIniciales() { return saldosIniciales; }
    public void setSaldosIniciales(List<FlujoCajaReporteRequest.SaldoInicialItem> saldosIniciales) { this.saldosIniciales = saldosIniciales; }
    public List<FlujoCajaReporteRequest.IngresoItem> getIngresos() { return ingresos; }
    public void setIngresos(List<FlujoCajaReporteRequest.IngresoItem> ingresos) { this.ingresos = ingresos; }
}
