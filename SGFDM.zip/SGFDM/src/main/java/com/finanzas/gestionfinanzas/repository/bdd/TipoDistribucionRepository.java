package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.TipoDistribucion;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TipoDistribucionRepository extends JpaRepository<TipoDistribucion, Long> {
    List<TipoDistribucion> findAllByOrderByNombreTipoDistribucionAsc();

    List<TipoDistribucion> findByEstadoOrderByNombreTipoDistribucionAsc(String estado);

    @Query("SELECT t FROM TipoDistribucion t " +
            "WHERE (:nombre IS NULL OR UPPER(t.nombreTipoDistribucion) LIKE UPPER(CONCAT('%', :nombre, '%'))) " +
            "AND (:estado IS NULL OR t.estado = :estado) " +
            "ORDER BY t.nombreTipoDistribucion")
    Page<TipoDistribucion> buscar(@Param("nombre") String nombre, @Param("estado") String estado, Pageable pageable);
}
