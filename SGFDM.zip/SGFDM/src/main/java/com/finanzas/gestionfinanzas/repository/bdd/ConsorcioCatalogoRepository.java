package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.ConsorcioCatalogo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ConsorcioCatalogoRepository extends JpaRepository<ConsorcioCatalogo, Long> {
    List<ConsorcioCatalogo> findByEstadoOrderByNombreConsorcio(String estado);

    @Query("SELECT c FROM ConsorcioCatalogo c " +
            "WHERE (:nombre IS NULL OR UPPER(c.nombreConsorcio) LIKE UPPER(CONCAT('%', :nombre, '%'))) " +
            "AND (:estado IS NULL OR c.estado = :estado) " +
            "ORDER BY c.nombreConsorcio")
    Page<ConsorcioCatalogo> buscar(@Param("nombre") String nombre, @Param("estado") String estado, Pageable pageable);
}
