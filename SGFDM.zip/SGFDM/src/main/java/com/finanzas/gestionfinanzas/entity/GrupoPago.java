package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// Catálogo local (copia fija, ver reset_bd.sql) de FND_LOOKUP_VALUES_VL con
// LOOKUP_TYPE='PAY GROUP' y ENABLED_FLAG='Y' del ERP. Arma el combo "Gerencia"
// del buscador de facturas pagables sin depender del ERP en vivo ni de la copia
// local volátil FC_EGR_CXP_PAGABLE (ver
// FlujoCajaReporteController.obtenerGerenciasDisponibles).
@Entity
@Table(name = "FC_EGR_GRUPO_PAGO")
public class GrupoPago {

    @Id
    @Column(name = "CODIGO_FC_EGR_GRUPO_PAGO")
    private String codigoGrupoPago;

    @Column(name = "DESCRIPCION")
    private String descripcion;

    public String getCodigoGrupoPago() { return codigoGrupoPago; }
    public void setCodigoGrupoPago(String codigoGrupoPago) { this.codigoGrupoPago = codigoGrupoPago; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
