package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaReportePdf;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface FlujoCajaReportePdfRepository extends JpaRepository<FlujoCajaReportePdf, Long> {
    Optional<FlujoCajaReportePdf> findByReporte_IdReporte(Long idReporte);

    // No trae el BLOB: sirve para saber si mostrar el link de descarga en un
    // listado sin cargar el contenido de todos los PDFs de la página.
    boolean existsByReporte_IdReporte(Long idReporte);
}
