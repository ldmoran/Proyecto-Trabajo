package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.ProvisionArea;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProvisionAreaRepository extends JpaRepository<ProvisionArea, Long> {

    List<ProvisionArea> findByEstadoOrderByNombreArea(String estado);
}
