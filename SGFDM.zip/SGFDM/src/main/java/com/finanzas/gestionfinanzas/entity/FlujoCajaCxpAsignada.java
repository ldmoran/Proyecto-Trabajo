package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

// Registro PERMANENTE (append-only, nunca se borra ni se reescribe) de qué
// factura de Cuentas por Pagar (EBS) quedó comprometida por qué reporte de
// Flujo de Caja — se graba recién cuando el reporte queda Autorizado (ver
// FlujoCajaReporteService.marcarAutorizado), nunca antes: mientras el reporte
// sigue en borrador, se puede seguir jugando con el monto de Ingresos sin que
// eso reserve nada. Sin esto, la semana siguiente volvería a ofrecer las
// mismas facturas como "pagables", porque la vista de EBS no tiene forma de
// saber que SGFDM ya las dio por comprometidas (no se le puede escribir).
// UQ en INVOICE_ID: ninguna factura puede quedar comprometida por dos
// reportes a la vez.
@Entity
@Table(name = "FC_EGR_CXP_ASIGNADA")
public class FlujoCajaCxpAsignada {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CXP_ASIGNADA")
    private Long idCxpAsignada;

    @Column(name = "ID_REPORTE")
    private Long idReporte;

    @Column(name = "ORDEN")
    private Long orden;

    @Column(name = "FUENTE")
    private String fuente;

    @Column(name = "PRIORIZADO")
    private String priorizado;

    @Column(name = "INVOICE_ID")
    private Long invoiceId;

    @Column(name = "PROVEEDOR")
    private String proveedor;

    @Column(name = "TIPO_DOCUMENTO")
    private String tipoDocumento;

    @Column(name = "DOCUMENTO")
    private String documento;

    @Column(name = "FECHA_DOCUMENTO")
    private LocalDate fechaDocumento;

    @Column(name = "TERMINO_PAGO")
    private String terminoPago;

    @Column(name = "FC_EGR_GRUPO_PAGO")
    private String grupoPago;

    @Column(name = "CATEGORIA")
    private String categoria;

    @Column(name = "METODO_PAGO")
    private String metodoPago;

    @Column(name = "FECHA_VENCIMIENTO")
    private LocalDate fechaVencimiento;

    @Column(name = "IMPORTE_A_PAGAR")
    private BigDecimal importeAPagar;

    @Column(name = "DESCRIPCION")
    private String descripcion;

    @Column(name = "FECHA_ASIGNACION")
    private LocalDateTime fechaAsignacion;

    public Long getIdCxpAsignada() { return idCxpAsignada; }
    public void setIdCxpAsignada(Long idCxpAsignada) { this.idCxpAsignada = idCxpAsignada; }

    public Long getIdReporte() { return idReporte; }
    public void setIdReporte(Long idReporte) { this.idReporte = idReporte; }

    public Long getOrden() { return orden; }
    public void setOrden(Long orden) { this.orden = orden; }

    public String getFuente() { return fuente; }
    public void setFuente(String fuente) { this.fuente = fuente; }

    public String getPriorizado() { return priorizado; }
    public void setPriorizado(String priorizado) { this.priorizado = priorizado; }

    public Long getInvoiceId() { return invoiceId; }
    public void setInvoiceId(Long invoiceId) { this.invoiceId = invoiceId; }

    public String getProveedor() { return proveedor; }
    public void setProveedor(String proveedor) { this.proveedor = proveedor; }

    public String getTipoDocumento() { return tipoDocumento; }
    public void setTipoDocumento(String tipoDocumento) { this.tipoDocumento = tipoDocumento; }

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public LocalDate getFechaDocumento() { return fechaDocumento; }
    public void setFechaDocumento(LocalDate fechaDocumento) { this.fechaDocumento = fechaDocumento; }

    public String getTerminoPago() { return terminoPago; }
    public void setTerminoPago(String terminoPago) { this.terminoPago = terminoPago; }

    public String getGrupoPago() { return grupoPago; }
    public void setGrupoPago(String grupoPago) { this.grupoPago = grupoPago; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }

    public LocalDate getFechaVencimiento() { return fechaVencimiento; }
    public void setFechaVencimiento(LocalDate fechaVencimiento) { this.fechaVencimiento = fechaVencimiento; }

    public BigDecimal getImporteAPagar() { return importeAPagar; }
    public void setImporteAPagar(BigDecimal importeAPagar) { this.importeAPagar = importeAPagar; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public LocalDateTime getFechaAsignacion() { return fechaAsignacion; }
    public void setFechaAsignacion(LocalDateTime fechaAsignacion) { this.fechaAsignacion = fechaAsignacion; }
}
