package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

// "Foto" local de las facturas de Cuentas por Pagar del ERP (vista
// APPS.XXOCS_AP_CXP_CONS_V) que alcanzan a pagarse con los Ingresos totales del
// momento. Se reescribe entera cada vez que se pide "Actualizar" en la pantalla
// de Flujo de Caja (ver FlujoCajaCxpPagableService) — no es histórico, es una
// copia de trabajo para no tener que pegarle a la base externa cada vez que
// alguien pagina o busca.
@Entity
@Table(name = "FC_EGR_CXP_PAGABLE")
public class EgresoCxpPagable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CXP_PAGABLE")
    private Long idCxpPagable;

    @Column(name = "ORDEN")
    private Long orden;

    // "EBS_PEC" / "EBS_PAM" (u otro): distingue si la factura va a "GERENCIAS
    // PETROECUADOR" (PEC) o "EXPLORACIÓN Y PRODUCCIÓN" (PAM) en la sección 3)
    // Priorizado (ver FlujoCajaCxpPagableService.resumenPorCategoria).
    @Column(name = "FUENTE")
    private String fuente;

    // "SI"/"NO": distingue la sección 3) Priorizado (Fondos Disponibles = SI) de la
    // 4) Montos Priorizados Pendientes de Ejecutar (NO). Ver
    // FlujoCajaCxpPagableService.resumenPorFuente.
    @Column(name = "PRIORIZADO")
    private String priorizado;

    @Column(name = "INVOICE_ID")
    private Long invoiceId;

    @Column(name = "PROVEEDOR")
    private String proveedor;

    @Column(name = "TIPO_DOCUMENTO")
    private String tipoDocumento;

    @Column(name = "DOCUMENTO")
    private String documento;

    @Column(name = "FECHA_DOCUMENTO")
    private LocalDate fechaDocumento;

    @Column(name = "TERMINO_PAGO")
    private String terminoPago;

    @Column(name = "FC_EGR_GRUPO_PAGO")
    private String grupoPago;

    @Column(name = "CATEGORIA")
    private String categoria;

    @Column(name = "METODO_PAGO")
    private String metodoPago;

    @Column(name = "FECHA_VENCIMIENTO")
    private LocalDate fechaVencimiento;

    @Column(name = "IMPORTE_A_PAGAR")
    private BigDecimal importeAPagar;

    @Column(name = "DESCRIPCION")
    private String descripcion;

    @Column(name = "FECHA_CARGA")
    private LocalDateTime fechaCarga;

    public Long getIdCxpPagable() { return idCxpPagable; }
    public void setIdCxpPagable(Long idCxpPagable) { this.idCxpPagable = idCxpPagable; }

    public Long getOrden() { return orden; }
    public void setOrden(Long orden) { this.orden = orden; }

    public String getFuente() { return fuente; }
    public void setFuente(String fuente) { this.fuente = fuente; }

    public String getPriorizado() { return priorizado; }
    public void setPriorizado(String priorizado) { this.priorizado = priorizado; }

    public Long getInvoiceId() { return invoiceId; }
    public void setInvoiceId(Long invoiceId) { this.invoiceId = invoiceId; }

    public String getProveedor() { return proveedor; }
    public void setProveedor(String proveedor) { this.proveedor = proveedor; }

    public String getTipoDocumento() { return tipoDocumento; }
    public void setTipoDocumento(String tipoDocumento) { this.tipoDocumento = tipoDocumento; }

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public LocalDate getFechaDocumento() { return fechaDocumento; }
    public void setFechaDocumento(LocalDate fechaDocumento) { this.fechaDocumento = fechaDocumento; }

    public String getTerminoPago() { return terminoPago; }
    public void setTerminoPago(String terminoPago) { this.terminoPago = terminoPago; }

    public String getGrupoPago() { return grupoPago; }
    public void setGrupoPago(String grupoPago) { this.grupoPago = grupoPago; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }

    public LocalDate getFechaVencimiento() { return fechaVencimiento; }
    public void setFechaVencimiento(LocalDate fechaVencimiento) { this.fechaVencimiento = fechaVencimiento; }

    public BigDecimal getImporteAPagar() { return importeAPagar; }
    public void setImporteAPagar(BigDecimal importeAPagar) { this.importeAPagar = importeAPagar; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public LocalDateTime getFechaCarga() { return fechaCarga; }
    public void setFechaCarga(LocalDateTime fechaCarga) { this.fechaCarga = fechaCarga; }
}
