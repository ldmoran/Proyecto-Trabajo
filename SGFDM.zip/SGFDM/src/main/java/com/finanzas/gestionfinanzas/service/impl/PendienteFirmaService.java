package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.PendienteFirmaDTO;
import com.finanzas.gestionfinanzas.entity.FlujoCajaResponsable;
import com.finanzas.gestionfinanzas.entity.Usuario;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaReporteRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaResponsableRepository;
import com.finanzas.gestionfinanzas.repository.bdd.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

// Reportes de Flujo de Caja que están esperando la firma de un usuario en
// particular (Aprobar o Autorizar), según lo que tenga marcado en
// FC_RESPONSABLE (ver Mantenimiento > Responsables Flujo de Caja).
// Usado tanto por la tarjeta "Pendientes de tu firma" del Dashboard como por
// la campanita de notificaciones del header (ver NotificacionController).
@Service
public class PendienteFirmaService {

    private final UsuarioRepository usuarioRepository;
    private final FlujoCajaResponsableRepository flujoCajaResponsableRepository;
    private final FlujoCajaReporteRepository flujoCajaReporteRepository;

    public PendienteFirmaService(UsuarioRepository usuarioRepository,
                                  FlujoCajaResponsableRepository flujoCajaResponsableRepository,
                                  FlujoCajaReporteRepository flujoCajaReporteRepository) {
        this.usuarioRepository = usuarioRepository;
        this.flujoCajaResponsableRepository = flujoCajaResponsableRepository;
        this.flujoCajaReporteRepository = flujoCajaReporteRepository;
    }

    // Si el usuario no está marcado como Aprobador ni Autorizador, devuelve
    // lista vacía (no es un error: la mayoría de la gente no va a estar marcada).
    public List<PendienteFirmaDTO> obtenerPendientes(String usuarioLogin) {
        Optional<Usuario> usuario = usuarioRepository.findByUsuario(usuarioLogin);
        if (!usuario.isPresent()) {
            return Collections.emptyList();
        }

        Optional<FlujoCajaResponsable> responsable = flujoCajaResponsableRepository.findByUsuario_IdUsuario(usuario.get().getIdUsuario());
        if (!responsable.isPresent()) {
            return Collections.emptyList();
        }

        List<PendienteFirmaDTO> pendientes = new ArrayList<>();

        if (responsable.get().isAprobador()) {
            flujoCajaReporteRepository.findByElaboradoPorIsNotNullAndAprobadoPorIsNullOrderByFechaInicio()
                    .forEach(r -> pendientes.add(new PendienteFirmaDTO(r.getFechaInicio(), r.getFechaFin(), "Aprobar")));
        }
        if (responsable.get().isAutorizador()) {
            flujoCajaReporteRepository.findByAprobadoPorIsNotNullAndAutorizadoPorIsNullOrderByFechaInicio()
                    .forEach(r -> pendientes.add(new PendienteFirmaDTO(r.getFechaInicio(), r.getFechaFin(), "Autorizar")));
        }

        return pendientes;
    }
}
