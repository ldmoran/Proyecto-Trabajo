package com.finanzas.gestionfinanzas.dto;

import java.time.LocalDateTime;

// Datos de un archivo SIN el contenido (BLOB), para listarlos sin cargar cada
// PDF completo en memoria; el contenido solo se lee al descargar uno puntual.
public class ArchivoResumenDTO {

    private final Long idArchivo;
    private final Long idFactura;
    private final Long idTipoArchivo;
    private final String nombreTipoArchivo;
    private final String nombreArchivo;
    private final String extension;
    private final LocalDateTime fechaCreacion;

    public ArchivoResumenDTO(Long idArchivo, Long idFactura, Long idTipoArchivo, String nombreTipoArchivo,
                             String nombreArchivo, String extension, LocalDateTime fechaCreacion) {
        this.idArchivo = idArchivo;
        this.idFactura = idFactura;
        this.idTipoArchivo = idTipoArchivo;
        this.nombreTipoArchivo = nombreTipoArchivo;
        this.nombreArchivo = nombreArchivo;
        this.extension = extension;
        this.fechaCreacion = fechaCreacion;
    }

    public Long getIdArchivo() {
        return idArchivo;
    }

    public Long getIdFactura() {
        return idFactura;
    }

    public Long getIdTipoArchivo() {
        return idTipoArchivo;
    }

    public String getNombreTipoArchivo() {
        return nombreTipoArchivo;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public String getExtension() {
        return extension;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }
}
