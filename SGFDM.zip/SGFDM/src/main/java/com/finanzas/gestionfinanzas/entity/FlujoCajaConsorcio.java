package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "FC_EGR_CONSORCIO")
public class FlujoCajaConsorcio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CONSORCIO_REPORTE")
    private Long idConsorcioReporte;

    @ManyToOne
    @JoinColumn(name = "ID_REPORTE")
    private FlujoCajaReporte reporte;

    @Column(name = "NOMBRE_CONSORCIO")
    private String nombreConsorcio;

    @Lob
    @Column(name = "DESCRIPCION")
    private String descripcion;

    @Column(name = "SALDO_ESTIMADO")
    private BigDecimal saldoEstimado;

    @Column(name = "FECHA_ESTIMADO")
    private LocalDate fechaEstimado;

    // Snapshot de texto (una línea por factura de Cuentas por Pagar que vence
    // esa semana, ver ConsorcioCxpService), armado en el navegador al momento
    // de Guardar -- no se vuelve a calcular después, así el PDF firmado y el
    // Excel no cambian si la factura se paga o desaparece de la vista del ERP.
    @Lob
    @Column(name = "DETALLE_FACTURAS")
    private String detalleFacturas;

    @Column(name = "TOTAL_FACTURAS")
    private BigDecimal totalFacturas;

    // Manual, solo aplica al consorcio Shushufindi -- queda null en Shaya.
    @Column(name = "FONDEO_BCE")
    private BigDecimal fondeoBce;

    @Column(name = "FECHA_SALDO_FINAL")
    private LocalDate fechaSaldoFinal;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdConsorcioReporte() { return idConsorcioReporte; }
    public void setIdConsorcioReporte(Long idConsorcioReporte) { this.idConsorcioReporte = idConsorcioReporte; }

    public FlujoCajaReporte getReporte() { return reporte; }
    public void setReporte(FlujoCajaReporte reporte) { this.reporte = reporte; }

    public String getNombreConsorcio() { return nombreConsorcio; }
    public void setNombreConsorcio(String nombreConsorcio) { this.nombreConsorcio = nombreConsorcio; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getSaldoEstimado() { return saldoEstimado; }
    public void setSaldoEstimado(BigDecimal saldoEstimado) { this.saldoEstimado = saldoEstimado; }

    public LocalDate getFechaEstimado() { return fechaEstimado; }
    public void setFechaEstimado(LocalDate fechaEstimado) { this.fechaEstimado = fechaEstimado; }

    public String getDetalleFacturas() { return detalleFacturas; }
    public void setDetalleFacturas(String detalleFacturas) { this.detalleFacturas = detalleFacturas; }

    public BigDecimal getTotalFacturas() { return totalFacturas; }
    public void setTotalFacturas(BigDecimal totalFacturas) { this.totalFacturas = totalFacturas; }

    public BigDecimal getFondeoBce() { return fondeoBce; }
    public void setFondeoBce(BigDecimal fondeoBce) { this.fondeoBce = fondeoBce; }

    public LocalDate getFechaSaldoFinal() { return fechaSaldoFinal; }
    public void setFechaSaldoFinal(LocalDate fechaSaldoFinal) { this.fechaSaldoFinal = fechaSaldoFinal; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}