package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.ProvisionRegistro;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ProvisionRegistroRepository extends JpaRepository<ProvisionRegistro, Long> {

    // Todos los NUEVO todavía ABIERTOS (pendientes de cerrar con un
    // Pendiente/Mixto), del más reciente al más antiguo — para mostrarlos en
    // el panel "Provisión Pendiente" y que el usuario elija de una lista en
    // vez de ir a ciegas por la cascada Gerencia->Área->Zona->Concepto (ver
    // ProvisionesController.verProvisiones).
    List<ProvisionRegistro> findByTipoAndEstadoOrderByFechaCreacionDesc(String tipo, String estado);

    // El NUEVO más reciente y todavía abierto de un concepto. Un Pendiente
    // (antes "Anterior") NO lo cierra — deja seguir descontando del mismo
    // Nuevo semana tras semana; solo un MIXTO lo cierra de verdad (ver
    // ProvisionRegistroService.crearAnteriorOMixto), porque ahí sí toca
    // registrar un Nuevo fresco para el siguiente ciclo.
    Optional<ProvisionRegistro> findFirstByConcepto_IdConceptoAndTipoAndEstadoOrderByFechaCreacionDesc(
            Long idConcepto, String tipo, String estado);

    // La ronda (Pendiente/Mixto) más reciente que ya descontó de este mismo
    // Nuevo de origen: sirve para encadenar el "valor a cubrir" de la
    // siguiente ronda (su Valor Pendiente en vez del Valor Nuevo original).
    Optional<ProvisionRegistro> findFirstByRegistroOrigen_IdRegistroOrderByFechaCreacionDesc(Long idRegistroOrigen);

    // Todo lo ya guardado (Nuevo/Pendiente/Mixto) para la semana de un reporte
    // de Flujo de Caja — relación real por ID_REPORTE (ver ProvisionRegistro.reporte),
    // para que la pantalla de Provisiones muestre lo que ya se registró ahí al
    // volver a elegir ese mismo período, en vez de mostrar el formulario vacío
    // como si nunca se hubiera guardado nada (ver
    // ProvisionesController.obtenerHistorialPeriodo / FlujoCajaReporteService.recalcularTotales).
    List<ProvisionRegistro> findByReporte_IdReporteOrderByFechaCreacionDesc(Long idReporte);

    // Pantalla "Consultar Provisiones": busca por año/mes del período de
    // inicio del registro. Cualquiera de los 2 puede venir vacío.
    // Un NUEVO que ya tiene al menos una ronda Pendiente/Mixto encadenada no
    // se lista aparte (puede haber varias rondas seguidas sobre el mismo
    // Nuevo): cada ronda ya muestra su Valor Nuevo de origen (ver
    // ProvisionesController), así que repetir el Nuevo sería la misma
    // información en varias filas.
    @Query(value = "SELECT * FROM PROVISION_REGISTRO r WHERE " +
            "(:anio IS NULL OR EXTRACT(YEAR FROM r.FECHA_INICIO_PERIODO) = :anio) AND " +
            "(:mes IS NULL OR EXTRACT(MONTH FROM r.FECHA_INICIO_PERIODO) = :mes) AND " +
            "NOT (r.TIPO = 'NUEVO' AND EXISTS (SELECT 1 FROM PROVISION_REGISTRO h WHERE h.ID_REGISTRO_ORIGEN = r.ID_REGISTRO)) " +
            // ID_LOTE antes de FECHA_CREACION: así las filas de un mismo lote
            // (varios conceptos guardados juntos) quedan siempre contiguas,
            // sin depender de que sus timestamps hayan quedado idénticos.
            "ORDER BY r.FECHA_INICIO_PERIODO DESC, r.ID_LOTE DESC NULLS LAST, r.FECHA_CREACION DESC",
            countQuery = "SELECT COUNT(*) FROM PROVISION_REGISTRO r WHERE " +
            "(:anio IS NULL OR EXTRACT(YEAR FROM r.FECHA_INICIO_PERIODO) = :anio) AND " +
            "(:mes IS NULL OR EXTRACT(MONTH FROM r.FECHA_INICIO_PERIODO) = :mes) AND " +
            "NOT (r.TIPO = 'NUEVO' AND EXISTS (SELECT 1 FROM PROVISION_REGISTRO h WHERE h.ID_REGISTRO_ORIGEN = r.ID_REGISTRO))",
            nativeQuery = true)
    Page<ProvisionRegistro> buscar(@Param("anio") Integer anio, @Param("mes") Integer mes, Pageable pageable);
}
