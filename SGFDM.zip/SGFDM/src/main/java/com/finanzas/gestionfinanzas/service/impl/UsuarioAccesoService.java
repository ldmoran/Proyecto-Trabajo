package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.entity.Usuario;
import com.finanzas.gestionfinanzas.repository.bdd.UsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

// Guarda la ficha de quien entra al sistema (nombre, cédula, correo) y cuándo lo
// hizo. Los datos vienen del servicio de seguridad institucional en el momento de
// autenticarse; esta es la única oportunidad de tenerlos, porque después no hay
// forma de preguntarle al servicio por un usuario suelto.
@Service
public class UsuarioAccesoService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioAccesoService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @Transactional("secondTransactionManager")
    public void registrarAcceso(AuthResponseDTO datos) {
        if (datos == null || datos.getUsuario() == null) {
            return;
        }

        LocalDateTime ahora = LocalDateTime.now();
        Usuario usuario = usuarioRepository.findByUsuario(datos.getUsuario()).orElse(null);

        if (usuario == null) {
            usuario = new Usuario();
            usuario.setUsuario(datos.getUsuario());
            usuario.setFechaPrimerAcceso(ahora);
            usuario.setTotalAccesos(0);
        }

        // La ficha se refresca en cada acceso: si en el sistema de seguridad le
        // cambiaron el correo o el nombre, aquí queda el dato vigente.
        usuario.setNombreCompleto(nombreCompleto(datos));
        usuario.setCedula(datos.getCedula());
        usuario.setEmail(datos.getEmail());
        usuario.setIdExterno(datos.getId());
        usuario.setFechaUltimoAcceso(ahora);
        usuario.setTotalAccesos(usuario.getTotalAccesos() == null ? 1 : usuario.getTotalAccesos() + 1);

        usuarioRepository.save(usuario);
    }

    // El nombre completo llega en el bloque de LDAP; si no viniera, se usa el
    // nombre que devuelve el propio servicio de seguridad.
    private String nombreCompleto(AuthResponseDTO datos) {
        if (datos.getUsuarioLdap() != null && datos.getUsuarioLdap().getNombreCompleto() != null) {
            return datos.getUsuarioLdap().getNombreCompleto();
        }
        return datos.getNombre();
    }
}
