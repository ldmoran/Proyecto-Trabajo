package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.Auditoria;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditoriaRepository extends JpaRepository<Auditoria, Long> {

    @Query("SELECT a FROM Auditoria a WHERE " +
            "(:nombreTabla IS NULL OR a.nombreTabla = :nombreTabla) " +
            "AND (:accion IS NULL OR a.accion = :accion) " +
            "AND (:usuarioAccion IS NULL OR UPPER(a.usuarioAccion) LIKE UPPER(CONCAT('%', :usuarioAccion, '%'))) " +
            "ORDER BY a.fechaAccion DESC")
    Page<Auditoria> buscar(@Param("nombreTabla") String nombreTabla,
                           @Param("accion") String accion,
                           @Param("usuarioAccion") String usuarioAccion,
                           Pageable pageable);

    @Query("SELECT DISTINCT a.nombreTabla FROM Auditoria a ORDER BY a.nombreTabla")
    List<String> findDistinctNombreTabla();
}
