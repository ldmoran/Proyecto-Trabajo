package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

// Quién es Aprobador y quién es Autorizador de los reportes de Flujo de Caja
// (ver FlujoCajaReporteService.marcarAprobado/marcarAutorizado), para saber a
// quién avisarle por correo cuando le toca firmar. Se marca a mano desde
// Mantenimiento > Responsables Flujo de Caja porque el servicio de seguridad
// institucional todavía no tiene perfiles para esta cadena de firmas — cuando
// los defina, esta tabla se reemplaza por esa fuente sin tocar el resto.
@Entity
@Table(name = "FC_RESPONSABLE")
public class FlujoCajaResponsable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_RESPONSABLE")
    private Long idResponsable;

    @OneToOne
    @JoinColumn(name = "ID_USUARIO")
    private Usuario usuario;

    @Column(name = "ES_ELABORADOR")
    private String esElaborador;

    @Column(name = "ES_APROBADOR")
    private String esAprobador;

    @Column(name = "ES_AUTORIZADOR")
    private String esAutorizador;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdResponsable() { return idResponsable; }
    public void setIdResponsable(Long idResponsable) { this.idResponsable = idResponsable; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public String getEsElaborador() { return esElaborador; }
    public void setEsElaborador(String esElaborador) { this.esElaborador = esElaborador; }

    public String getEsAprobador() { return esAprobador; }
    public void setEsAprobador(String esAprobador) { this.esAprobador = esAprobador; }

    public String getEsAutorizador() { return esAutorizador; }
    public void setEsAutorizador(String esAutorizador) { this.esAutorizador = esAutorizador; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public boolean isElaborador() { return "S".equals(esElaborador); }
    public boolean isAprobador() { return "S".equals(esAprobador); }
    public boolean isAutorizador() { return "S".equals(esAutorizador); }
}
