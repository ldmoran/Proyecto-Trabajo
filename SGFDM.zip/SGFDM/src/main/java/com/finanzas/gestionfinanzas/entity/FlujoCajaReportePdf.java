package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

// PDF acumulado del reporte semanal (1 por reporte). Empieza como el PDF sin
// firmar apenas alguien marca "Elaborado", y de ahí en adelante cada firma
// (Aprobado, Autorizado) se agrega de forma incremental sobre el mismo archivo,
// sin invalidar las firmas anteriores — por eso es un solo registro que se
// sobrescribe, no uno por firma (el detalle de quién firmó cada etapa vive en
// FC_FIRMA).
@Entity
@Table(name = "FC_REPORTE_PDF")
public class FlujoCajaReportePdf {

    @Id
    @Column(name = "ID_REPORTE")
    private Long idReporte;

    @OneToOne
    @MapsId
    @JoinColumn(name = "ID_REPORTE")
    private FlujoCajaReporte reporte;

    @Lob
    @Column(name = "CONTENIDO")
    private byte[] contenido;

    @Column(name = "FECHA_ACTUALIZACION")
    private LocalDateTime fechaActualizacion;

    public Long getIdReporte() {
        return idReporte;
    }

    public void setIdReporte(Long idReporte) {
        this.idReporte = idReporte;
    }

    public FlujoCajaReporte getReporte() {
        return reporte;
    }

    public void setReporte(FlujoCajaReporte reporte) {
        this.reporte = reporte;
    }

    public byte[] getContenido() {
        return contenido;
    }

    public void setContenido(byte[] contenido) {
        this.contenido = contenido;
    }

    public LocalDateTime getFechaActualizacion() {
        return fechaActualizacion;
    }

    public void setFechaActualizacion(LocalDateTime fechaActualizacion) {
        this.fechaActualizacion = fechaActualizacion;
    }
}
