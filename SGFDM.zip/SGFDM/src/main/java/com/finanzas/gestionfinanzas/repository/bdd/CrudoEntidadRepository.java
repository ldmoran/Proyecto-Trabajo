package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.CrudoEntidad;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CrudoEntidadRepository extends JpaRepository<CrudoEntidad, Long> {
    List<CrudoEntidad> findAllByOrderByNombreGrupoAsc();

    List<CrudoEntidad> findByEstadoOrderByNombreGrupoAsc(String estado);

    List<CrudoEntidad> findByEstadoOrderByIdGrupoAsc(String estado);

    @Query("SELECT ce FROM CrudoEntidad ce " +
            "WHERE (:nombre IS NULL OR UPPER(ce.nombreGrupo) LIKE UPPER(CONCAT('%', :nombre, '%'))) " +
            "AND (:estado IS NULL OR ce.estado = :estado) " +
            "ORDER BY ce.nombreGrupo")
    Page<CrudoEntidad> buscar(@Param("nombre") String nombre, @Param("estado") String estado, Pageable pageable);
}
