package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaConsorcio;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FlujoCajaConsorcioRepository extends JpaRepository<FlujoCajaConsorcio, Long> {
    List<FlujoCajaConsorcio> findByReporte_IdReporte(Long idReporte);
}