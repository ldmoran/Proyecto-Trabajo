package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

// Los triggers de auditoría/historial en Oracle (ver reset_bd.sql) leen el usuario real
// desde SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER'), porque la app se conecta con un único
// usuario técnico de base de datos (compartido por todos) y ese contexto es la única forma
// de que el trigger sepa qué persona hizo el cambio. Este servicio deja ese identificador
// en la sesión de Oracle justo antes de guardar/eliminar, usando el usuario autenticado.
// Debe llamarse dentro de la MISMA transacción que el guardado/eliminación (mismo método
// @Transactional("secondTransactionManager")), para que ambas operaciones compartan la
// misma conexión física y el trigger vea el identificador recién puesto.
@Service
public class AuditoriaSessionService {

    @PersistenceContext(unitName = "second")
    private EntityManager entityManager;

    public void activarUsuarioActual() {
        String usuario = SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : "APP";

        entityManager.createNativeQuery("BEGIN DBMS_SESSION.SET_IDENTIFIER(:usuario); END;")
                .setParameter("usuario", usuario)
                .executeUpdate();
    }

    // Fila de auditoría CON COMENTARIO DE NEGOCIO (ej. "Aprobó la factura Nº 123"),
    // además de la que ya inserta sola el trigger genérico de Oracle para ese mismo
    // cambio (ver reset_bd.sql) — esta no la reemplaza, la complementa: el trigger
    // deja el rastro a nivel de fila (qué tabla, qué acción SQL), y esta deja el
    // rastro a nivel de negocio (qué significó ese cambio), que solo el código Java
    // sabe explicar. accion sigue restringida a INSERT/UPDATE/DELETE (mismo CHECK
    // que ya tiene la tabla) para no reinventar esa columna, aunque el matiz real va
    // en descripcion. Debe llamarse dentro de la MISMA transacción que el guardado
    // real (mismo motivo que activarUsuarioActual).
    public void registrarComentario(String nombreTabla, Long idRegistro, String accion, String descripcion) {
        String usuario = SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : "APP";

        entityManager.createNativeQuery(
                "INSERT INTO AUDITORIA (NOMBRE_TABLA, ID_REGISTRO, ACCION, USUARIO_ACCION, DESCRIPCION) " +
                        "VALUES (:nombreTabla, :idRegistro, :accion, :usuario, :descripcion)")
                .setParameter("nombreTabla", nombreTabla)
                .setParameter("idRegistro", idRegistro)
                .setParameter("accion", accion)
                .setParameter("usuario", usuario)
                .setParameter("descripcion", descripcion)
                .executeUpdate();
    }
}
