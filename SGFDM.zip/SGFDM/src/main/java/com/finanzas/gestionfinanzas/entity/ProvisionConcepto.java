package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

// Cada concepto de provisión (ej. Servicios Básicos) pertenece a UNA área; la
// gerencia sale sola a partir de esa área, no se elige aparte (ver
// ProvisionesController, que arma gerencia/área automáticamente al elegir el
// concepto en la pantalla). ZONA es un dato más del concepto, no un nivel
// jerárquico: la misma Área+Concepto puede repetirse en varias zonas (ej.
// Refinación tiene "Servicios Básicos" en ZCN, ZNO y ZSO como 3 conceptos).
@Entity
@Table(name = "PROVISION_CONCEPTO")
public class ProvisionConcepto {

    public static final String ZONA_ZCN = "ZCN";
    public static final String ZONA_ZNO = "ZNO";
    public static final String ZONA_ZSO = "ZSO";
    public static final String ZONA_ZSU = "ZSU";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_CONCEPTO")
    private Long idConcepto;

    @ManyToOne
    @JoinColumn(name = "ID_AREA")
    private ProvisionArea area;

    @Column(name = "ZONA")
    private String zona;

    @Column(name = "NOMBRE_CONCEPTO")
    private String nombreConcepto;

    @Column(name = "ESTADO")
    private String estado;

    public Long getIdConcepto() { return idConcepto; }
    public void setIdConcepto(Long idConcepto) { this.idConcepto = idConcepto; }

    public ProvisionArea getArea() { return area; }
    public void setArea(ProvisionArea area) { this.area = area; }

    public String getZona() { return zona; }
    public void setZona(String zona) { this.zona = zona; }

    public String getNombreConcepto() { return nombreConcepto; }
    public void setNombreConcepto(String nombreConcepto) { this.nombreConcepto = nombreConcepto; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
