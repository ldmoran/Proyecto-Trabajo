package com.finanzas.gestionfinanzas.auth.security;


import com.finanzas.gestionfinanzas.auth.dto.response.AplicacionDTO;
import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.auth.dto.response.MenuDTO;
import com.finanzas.gestionfinanzas.auth.enums.AppEnum;
import com.finanzas.gestionfinanzas.auth.service1.AuthService;
import com.finanzas.gestionfinanzas.entity.Usuario;
import com.finanzas.gestionfinanzas.repository.bdd.UsuarioRepository;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

    private final AuthService authService;
    private final UsuarioRepository usuarioRepository;

    // =========================================================================
    // TEMPORAL — servicio externo de seguridad (eppec-seguridad-ws) caído.
    // En true: NO se llama al servicio real, se arma un usuario local con TODOS
    // los roles (cualquier usuario/clave que se escriba en /login sirve, la
    // clave ni se revisa). En false: vuelve a autenticar contra el servicio
    // real de siempre, sin tocar nada más de este archivo.
    // Para restaurar: poner esto en false (o borrar el bloque de abajo) apenas
    // el servicio externo vuelva a responder.
    // =========================================================================
    private static final boolean BYPASS_AUTENTICACION_EXTERNA = false;

    public CustomAuthenticationProvider(AuthService authService, UsuarioRepository usuarioRepository) {
        this.authService = authService;
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        if (BYPASS_AUTENTICACION_EXTERNA) {
            String usuarioBypass = authentication.getName();
            AuthResponseDTO userBypass = new AuthResponseDTO();
            userBypass.setId("0");
            userBypass.setUsuario(usuarioBypass);
            userBypass.setNombre(usuarioBypass);

            // Como no hay servicio externo al que preguntarle, se recupera nombre/
            // cédula/correo de la última vez que esta persona entró de verdad (ya
            // quedaron guardados en USUARIOS por UsuarioAccesoService). Si es la
            // primera vez que este usuario entra, no hay nada que recuperar y se
            // queda con el nombre = usuario, como antes.
            Usuario usuarioConocido = usuarioRepository.findByUsuario(usuarioBypass).orElse(null);
            if (usuarioConocido != null) {
                if (usuarioConocido.getNombreCompleto() != null) {
                    userBypass.setNombre(usuarioConocido.getNombreCompleto());
                }
                userBypass.setCedula(usuarioConocido.getCedula());
                userBypass.setEmail(usuarioConocido.getEmail());
            }

            List<SimpleGrantedAuthority> authoritiesBypass = new ArrayList<>();
            for (String rol : new String[]{"REGING", "FLUCAJ", "REPROV", "APRFUJ", "ADMFUN"}) {
                authoritiesBypass.add(new SimpleGrantedAuthority("ROLE_" + rol));
            }
            authoritiesBypass.add(new SimpleGrantedAuthority("ROLE_USER"));

            return new UsernamePasswordAuthenticationToken(userBypass, null, authoritiesBypass);
        }

        String username = authentication.getName();
        String password = authentication.getCredentials().toString();

        AuthResponseDTO user;
        try {
            user = authService.authenticate(username, password);

            Optional<AplicacionDTO> aplicacion = user.getListaAplicacion().stream().filter(e -> AppEnum.GFING.name().equals(e.getCodigo())).findFirst();

            if (!aplicacion.isPresent()) throw new BadCredentialsException("No tiene permisos para ingresar a este sistema");

            List<MenuDTO> permisos = authService.obtenerPerfilesUsuario(user.getId(), aplicacion.get().getId(), user.getToken());

            List<SimpleGrantedAuthority> authorities = new ArrayList<>();

            if (permisos != null && !permisos.isEmpty()) {
                authorities.addAll(permisos.stream()
                        .map(e -> new SimpleGrantedAuthority("ROLE_" + e.getNombre()))
                        .collect(Collectors.toList()));
            }

            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));

            return new UsernamePasswordAuthenticationToken(user, null, authorities);

        } catch (BadCredentialsException e) {
            throw e;
        }
        catch (Exception e) {
            throw new AuthenticationServiceException(
                    "Error autenticando contra servicio externo",
                    e
            );
        }
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
