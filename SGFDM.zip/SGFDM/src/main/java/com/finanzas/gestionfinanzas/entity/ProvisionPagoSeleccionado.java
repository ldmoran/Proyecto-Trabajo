package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

// Qué pagos de la vista APPS.XXOCS_AP_CXP_PAGOS_PROV_V del ERP se eligieron
// para un registro ANTERIOR/MIXTO. Esa vista es de solo lectura y externa
// (otro Oracle distinto al nuestro), así que no se puede dejar una FK hacia
// ella: se copian los datos tal cual venían al momento de elegirlos, mismo
// criterio que COSTOS_FACTURA con DETALLE_DISTRIBUCION.
@Entity
@Table(name = "PROVISION_PAGO_SELECCIONADO")
public class ProvisionPagoSeleccionado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_SELECCION")
    private Long idSeleccion;

    @ManyToOne
    @JoinColumn(name = "ID_REGISTRO")
    private ProvisionRegistro registro;

    @Column(name = "RUC")
    private String ruc;

    @Column(name = "DOCUMENTO")
    private String documento;

    @Column(name = "VENDOR_NAME")
    private String vendorName;

    @Column(name = "DESCRIPCION")
    private String descripcion;

    @Column(name = "MONTO_PAGADO")
    private BigDecimal montoPagado;

    @Column(name = "FECHA_PAGO")
    private LocalDate fechaPago;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdSeleccion() { return idSeleccion; }
    public void setIdSeleccion(Long idSeleccion) { this.idSeleccion = idSeleccion; }

    public ProvisionRegistro getRegistro() { return registro; }
    public void setRegistro(ProvisionRegistro registro) { this.registro = registro; }

    public String getRuc() { return ruc; }
    public void setRuc(String ruc) { this.ruc = ruc; }

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public String getVendorName() { return vendorName; }
    public void setVendorName(String vendorName) { this.vendorName = vendorName; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getMontoPagado() { return montoPagado; }
    public void setMontoPagado(BigDecimal montoPagado) { this.montoPagado = montoPagado; }

    public LocalDate getFechaPago() { return fechaPago; }
    public void setFechaPago(LocalDate fechaPago) { this.fechaPago = fechaPago; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}
