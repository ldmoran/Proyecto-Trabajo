package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.dto.PendienteFirmaDTO;
import com.finanzas.gestionfinanzas.service.impl.PendienteFirmaService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

// Alimenta la campanita de notificaciones del header (ver fragments/header.html),
// que la consulta por AJAX en cada pantalla — el header se repite en toda la app,
// así que esto tiene que vivir aparte de cualquier controller de pantalla puntual.
@RestController
public class NotificacionController {

    private final PendienteFirmaService pendienteFirmaService;

    public NotificacionController(PendienteFirmaService pendienteFirmaService) {
        this.pendienteFirmaService = pendienteFirmaService;
    }

    @GetMapping("/notificaciones/pendientes-firma")
    public List<PendienteFirmaDTO> pendientesFirma(@AuthenticationPrincipal AuthResponseDTO user) {
        return pendienteFirmaService.obtenerPendientes(user.getUsuario());
    }
}
