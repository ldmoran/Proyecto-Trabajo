package com.finanzas.gestionfinanzas.dto;

import java.util.List;

// Cuerpo JSON de POST /provisiones/anterior-lote (ver ProvisionesController):
// varios Conceptos de Provisión, cada uno con sus propios pagos elegidos,
// guardados juntos en un mismo lote de "Pendiente".
public class ProvisionAnteriorLoteRequest {

    private String fechaInicioPeriodo;
    private String fechaFinPeriodo;
    private List<ConceptoConPagosRequest> conceptos;

    public String getFechaInicioPeriodo() { return fechaInicioPeriodo; }
    public void setFechaInicioPeriodo(String fechaInicioPeriodo) { this.fechaInicioPeriodo = fechaInicioPeriodo; }

    public String getFechaFinPeriodo() { return fechaFinPeriodo; }
    public void setFechaFinPeriodo(String fechaFinPeriodo) { this.fechaFinPeriodo = fechaFinPeriodo; }

    public List<ConceptoConPagosRequest> getConceptos() { return conceptos; }
    public void setConceptos(List<ConceptoConPagosRequest> conceptos) { this.conceptos = conceptos; }
}
