package com.finanzas.gestionfinanzas.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

// Una fila de "facturas que se pueden pagar" para el anexo del PDF (ver
// FlujoCajaFirmaService/FlujoCajaCxpPagableService.calcularCubiertasCompleto) —
// mismo contenido que la tabla en pantalla de "Egresos — Cuentas por Pagar".
public class FacturaPagableDTO {

    private final Long orden;
    private final String proveedor;
    private final String documento;
    private final LocalDate fechaDocumento;
    private final LocalDate fechaVencimiento;
    private final BigDecimal importeAPagar;

    public FacturaPagableDTO(Long orden, String proveedor, String documento, LocalDate fechaDocumento,
                              LocalDate fechaVencimiento, BigDecimal importeAPagar) {
        this.orden = orden;
        this.proveedor = proveedor;
        this.documento = documento;
        this.fechaDocumento = fechaDocumento;
        this.fechaVencimiento = fechaVencimiento;
        this.importeAPagar = importeAPagar;
    }

    public Long getOrden() {
        return orden;
    }

    public String getProveedor() {
        return proveedor;
    }

    public String getDocumento() {
        return documento;
    }

    public LocalDate getFechaDocumento() {
        return fechaDocumento;
    }

    public LocalDate getFechaVencimiento() {
        return fechaVencimiento;
    }

    public BigDecimal getImporteAPagar() {
        return importeAPagar;
    }
}
