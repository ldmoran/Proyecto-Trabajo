package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

// Tabla del ERP (esquema XX_PAM, misma instancia Oracle que APPS — datasource
// "primary"), YA EN PRODUCCIÓN y ajena a este sistema: un batch externo la lee
// para armar la orden de pago de las facturas "PAM". Solo se usa para
// INSERT (ver PamAsignaFacturaTmpRepository.insertar) — nunca se lee ni se
// borra desde acá.
@Entity
@Table(name = "PAM_ASIGNA_FACTURAS_TMP", schema = "XX_PAM")
public class PamAsignaFacturaTmp {

    @Id
    @Column(name = "INVOICE_ID")
    private Long invoiceId;

    @Column(name = "COMENTARIO")
    private String comentario;

    @Column(name = "LOAD_DATE")
    private LocalDateTime loadDate;

    @Column(name = "CODIGO_FC")
    private String codigoFc;

    public Long getInvoiceId() { return invoiceId; }
    public void setInvoiceId(Long invoiceId) { this.invoiceId = invoiceId; }
    public String getComentario() { return comentario; }
    public void setComentario(String comentario) { this.comentario = comentario; }
    public LocalDateTime getLoadDate() { return loadDate; }
    public void setLoadDate(LocalDateTime loadDate) { this.loadDate = loadDate; }
    public String getCodigoFc() { return codigoFc; }
    public void setCodigoFc(String codigoFc) { this.codigoFc = codigoFc; }
}
