package com.finanzas.gestionfinanzas.auth.enums;

// Menús que el servicio de seguridad devuelve para GFINGRESO (aplicación 565).
// El nombre debe coincidir letra por letra con el que llega en listaMenu: el rol
// de Spring Security se arma como "ROLE_" + nombre (ver CustomAuthenticationProvider).
//
// Se validan los MENÚS y no los perfiles porque el servicio devuelve los menús
// que el usuario tiene asignados; el perfil es solo la forma en que se agrupan
// allá. Si mañana cambia ese reparto la aplicación no se entera ni hay que
// tocar nada, siempre que los nombres de acá abajo sigan siendo los mismos.
//
// Reemplaza al esquema anterior (FACTURA/REPORTERIA/AUDITORIA/MANTENIMIENTO,
// donde MANTENIMIENTO y AUDITORIA veían todo sin distinción). Este es más fino:
// cada uno da acceso a una combinación puntual de pantallas (ver SecurityConfig
// y fragments/menu.html para el detalle de qué pantalla usa cuál).
public enum MenuEnum {
    REGING,   // Facturas, Flujo de Ingresos, Reportes
    FLUCAJ,   // Provisiones, Consulta Provisiones, Flujo de Egresos, Flujo de Caja, Consulta Flujo de Caja, Reportes
    REPROV,   // Consulta Provisiones
    APRFUJ,   // Flujo de Caja, Consulta Flujo de Caja, Reportes, Auditoría
    ADMFUN    // Consulta Flujo de Caja, Reportes, Auditoría, Mantenimiento
}
