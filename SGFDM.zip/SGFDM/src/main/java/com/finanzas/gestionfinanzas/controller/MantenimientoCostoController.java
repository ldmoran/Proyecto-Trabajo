package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.dto.ComprobanteGlobalDTO;
import com.finanzas.gestionfinanzas.entity.Costos;
import com.finanzas.gestionfinanzas.entity.TipoCosto;
import com.finanzas.gestionfinanzas.repository.bdd.ArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CostoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoCostoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoEntidadRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CrudoRepository;
import com.finanzas.gestionfinanzas.service.impl.ArchivoService;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/mantenimiento/costos")
public class MantenimientoCostoController {

    private final CostoRepository costoRepository;
    private final TipoCostoRepository tipoCostoRepository;
    private final CrudoRepository crudoRepository;
    private final CrudoEntidadRepository crudoEntidadRepository;
    private final AuditoriaSessionService auditoriaSessionService;
    private final ArchivoService archivoService;
    private final ArchivoRepository archivoRepository;
    private final TipoArchivoRepository tipoArchivoRepository;

    public MantenimientoCostoController(CostoRepository costoRepository,
                                        TipoCostoRepository tipoCostoRepository,
                                        CrudoRepository crudoRepository,
                                        CrudoEntidadRepository crudoEntidadRepository,
                                        AuditoriaSessionService auditoriaSessionService,
                                        ArchivoService archivoService,
                                        ArchivoRepository archivoRepository,
                                        TipoArchivoRepository tipoArchivoRepository) {
        this.costoRepository = costoRepository;
        this.tipoCostoRepository = tipoCostoRepository;
        this.crudoRepository = crudoRepository;
        this.crudoEntidadRepository = crudoEntidadRepository;
        this.auditoriaSessionService = auditoriaSessionService;
        this.archivoService = archivoService;
        this.archivoRepository = archivoRepository;
        this.tipoArchivoRepository = tipoArchivoRepository;
    }

    @GetMapping
    @Transactional("secondTransactionManager")
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) Long idCrudo,
                         @RequestParam(required = false) Long idGrupo,
                         @RequestParam(required = false) Long idTipoCosto,
                         @RequestParam(required = false) String estado,
                         HttpServletRequest request, Model model) {
        auditoriaSessionService.activarUsuarioActual();

        List<TipoCosto> tiposCosto = tipoCostoRepository.findAllConCrudo();
        asegurarCostosParaTiposCosto(tiposCosto);

        Page<Costos> costosPage = costoRepository.buscar(idCrudo, idGrupo, idTipoCosto, normalizar(estado), PageRequest.of(page, 10));

        boolean hayCostosInactivos = costoRepository.findAll().stream()
                .anyMatch(c -> "INACTIVO".equalsIgnoreCase(c.getEstado()));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("costosPage", costosPage);
        model.addAttribute("tiposCosto", tiposCosto);
        model.addAttribute("crudos", crudoRepository.findByEstadoOrderByNombreCrudoAsc("A"));
        model.addAttribute("entidades", crudoEntidadRepository.findByEstadoOrderByIdGrupoAsc("A"));
        model.addAttribute("idCrudo", idCrudo);
        model.addAttribute("idGrupo", idGrupo);
        model.addAttribute("idTipoCosto", idTipoCosto);
        model.addAttribute("estado", estado);
        model.addAttribute("hayCostosInactivos", hayCostosInactivos);
        model.addAttribute("comprobantesCostos", buscarComprobantesCostos());
        return "mantenimiento/costos";
    }

    private List<ComprobanteGlobalDTO> buscarComprobantesCostos() {
        return tipoArchivoRepository.findByNombreTipoArchivo("Comprobante de Costos")
                .map(t -> archivoRepository.findResumenGlobalByTipoArchivo(t.getIdTipoArchivo(), PageRequest.of(0, 5)))
                .orElse(Collections.emptyList());
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    private void asegurarCostosParaTiposCosto(List<TipoCosto> tiposCosto) {
        Set<Long> idsConCosto = costoRepository.findAll().stream()
                .map(costo -> costo.getTipoCosto().getIdTipoCosto())
                .collect(Collectors.toSet());

        String usuarioActual = obtenerUsuarioActual();

        for (TipoCosto tipoCosto : tiposCosto) {
            if (!idsConCosto.contains(tipoCosto.getIdTipoCosto())) {
                Costos costo = new Costos();
                costo.setTipoCosto(tipoCosto);
                costo.setEstado("ACTIVO");
                costo.setIdUsuarioCreacion(usuarioActual);
                costoRepository.save(costo);
            }
        }
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idCosto,
                          @RequestParam Long idTipoCosto,
                          @RequestParam(required = false) Double valor,
                          @RequestParam(required = false) String fechaInicio,
                          @RequestParam(required = false) String fechaFin,
                          RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        TipoCosto tipoCosto = tipoCostoRepository.findById(idTipoCosto)
                .orElseThrow(() -> new RuntimeException("Tipo de costo no encontrado"));

        Costos costo = (idCosto != null)
                ? costoRepository.findById(idCosto).orElseThrow(() -> new RuntimeException("Costo no encontrado"))
                : new Costos();

        boolean esNuevo = costo.getIdCosto() == null;

        costo.setTipoCosto(tipoCosto);
        costo.setValor(valor);
        // Toda creación/edición de un costo queda INACTIVO hasta que se suba el
        // Comprobante de Costos (ver /mantenimiento/costos/subir-comprobante), que
        // reactiva TODOS los costos pendientes de una sola vez.
        costo.setEstado("INACTIVO");
        costo.setFechaInicio(fechaInicio);
        costo.setFechaFin(fechaFin);

        if (esNuevo) {
            costo.setIdUsuarioCreacion(obtenerUsuarioActual());
            costo.setFechaCreacion(LocalDateTime.now());
        }

        costoRepository.save(costo);
        auditoriaSessionService.registrarComentario("COSTOS", costo.getIdCosto(),
                esNuevo ? "INSERT" : "UPDATE",
                (esNuevo ? "Creó" : "Editó") + " el costo de " + tipoCosto.getNombreCosto() + " con valor " + valor + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        redirectAttributes.addFlashAttribute("pendienteComprobante", true);
        return "redirect:/mantenimiento/costos";
    }

    @PostMapping("/subir-comprobante")
    @Transactional("secondTransactionManager")
    public String subirComprobante(@RequestParam("archivo") MultipartFile archivo,
                                   RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        try {
            archivoService.subirComprobanteCostos(archivo);
            redirectAttributes.addFlashAttribute("comprobanteSubido", true);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error",
                    e.getMessage() != null ? e.getMessage() : "No se pudo subir el comprobante");
        }

        return "redirect:/mantenimiento/costos";
    }

    @PostMapping("/eliminar/{idCosto}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idCosto, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        String nombreEliminado = costoRepository.findById(idCosto)
                .map(c -> c.getTipoCosto() != null ? c.getTipoCosto().getNombreCosto() : "(desconocido)")
                .orElse("(desconocido)");
        try {
            costoRepository.deleteById(idCosto);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados");
            return "redirect:/mantenimiento/costos";
        }
        auditoriaSessionService.registrarComentario("COSTOS", idCosto, "DELETE",
                "Eliminó el costo de " + nombreEliminado + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/costos";
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }
}
