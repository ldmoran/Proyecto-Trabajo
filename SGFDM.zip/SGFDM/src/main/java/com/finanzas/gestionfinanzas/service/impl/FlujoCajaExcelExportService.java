package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.FlujoCajaConsorcio;
import com.finanzas.gestionfinanzas.entity.FlujoCajaIngreso;
import com.finanzas.gestionfinanzas.entity.FlujoCajaPriorizado;
import com.finanzas.gestionfinanzas.entity.FlujoCajaReporte;
import com.finanzas.gestionfinanzas.entity.FlujoCajaSaldoInicial;
import com.finanzas.gestionfinanzas.entity.FlujoCajaTransferencia;
import com.finanzas.gestionfinanzas.utils.FlujoCajaFechaUtils;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

// Genera el .xlsx del Flujo de Caja Semanal ya guardado, con el mismo look &
// feel que ControlIngresoExcelService (mismos colores/estilos) para que todos
// los Excel que descarga el sistema se vean consistentes entre sí. No incluye
// "Egresos — Cuentas por Pagar" (esa sección es en vivo contra el ERP, no se
// guarda con el reporte — ver EgresoCxpService).
@Service
public class FlujoCajaExcelExportService {

    private static final byte[] AZUL_OSCURO = {0, 47, 82};
    private static final byte[] AZUL_MEDIO = {0, 115, (byte) 171};
    private static final byte[] GRIS_FILA = {(byte) 244, (byte) 247, (byte) 249};
    private static final byte[] GRIS_BORDE = {(byte) 208, (byte) 216, (byte) 222};

    private static final int ULTIMA_COLUMNA = 2;
    private static final int ANCHO_MINIMO = 12 * 256;
    private static final int ANCHO_MAXIMO = 45 * 256;
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public void escribir(FlujoCajaReporte reporte,
                          List<FlujoCajaSaldoInicial> saldosIniciales,
                          List<FlujoCajaIngreso> ingresos,
                          List<FlujoCajaPriorizado> priorizados,
                          List<FlujoCajaTransferencia> transferencias,
                          List<FlujoCajaConsorcio> consorcios,
                          OutputStream salida) throws IOException {
        try (XSSFWorkbook libro = new XSSFWorkbook()) {
            XSSFSheet hoja = libro.createSheet("Flujo de Caja Semanal");

            XSSFCellStyle estiloTitulo = crearEstiloTitulo(libro);
            XSSFCellStyle estiloSubtitulo = crearEstiloSubtitulo(libro);
            XSSFCellStyle estiloSeccion = crearEstiloCabecera(libro, AZUL_OSCURO);
            XSSFCellStyle estiloCabecera = crearEstiloCabecera(libro, AZUL_MEDIO);
            XSSFCellStyle[] estiloTexto = {crearEstiloDatos(libro, null, false), crearEstiloDatos(libro, null, true)};
            XSSFCellStyle[] estiloNumero = {crearEstiloDatos(libro, "#,##0.00", false), crearEstiloDatos(libro, "#,##0.00", true)};
            XSSFCellStyle estiloTextoTotal = crearEstiloTotal(libro, null);
            XSSFCellStyle estiloNumeroTotal = crearEstiloTotal(libro, "#,##0.00");

            int f = 0;

            f = escribirTitulo(hoja, f, "FLUJO DE CAJA SEMANAL", estiloTitulo);
            f = escribirTitulo(hoja, f, descripcionPeriodo(reporte), estiloSubtitulo);
            f = escribirTitulo(hoja, f, "(CIFRAS EN USD)", estiloSubtitulo);
            f++; // fila en blanco

            // ---- 1) Saldo Inicial de Caja ----
            f = escribirSeccion(hoja, f, "1) SALDO INICIAL DE CAJA", estiloSeccion);
            f = escribirCabeceraDosColumnas(hoja, f, "Cuenta", "Número", "Valor (USD)", estiloCabecera);
            BigDecimal totalSaldoInicial = BigDecimal.ZERO;
            int z = 0;
            for (FlujoCajaSaldoInicial s : saldosIniciales) {
                Row fila = hoja.createRow(f++);
                String nombre = s.getCuentaBancaria() != null ? s.getCuentaBancaria().getNombreCuenta() : "-";
                String numero = s.getCuentaBancaria() != null ? s.getCuentaBancaria().getNumeroCuenta() : "-";
                escribir(fila, 0, nombre, estiloTexto[z]);
                escribir(fila, 1, numero, estiloTexto[z]);
                escribir(fila, 2, valorODouble(s.getValor()), estiloNumero[z]);
                totalSaldoInicial = totalSaldoInicial.add(s.getValor() != null ? s.getValor() : BigDecimal.ZERO);
                z = 1 - z;
            }
            f = escribirTotal(hoja, f, "TOTAL SALDO INICIAL", totalSaldoInicial, estiloTextoTotal, estiloNumeroTotal);
            f++; // fila en blanco

            // ---- 2) Ingresos por Recibir ----
            f = escribirSeccion(hoja, f, "2) INGRESOS POR RECIBIR", estiloSeccion);
            f = escribirCabeceraDosColumnas(hoja, f, "Concepto", "Tipo", "Valor (USD)", estiloCabecera);
            BigDecimal totalIngresos = BigDecimal.ZERO;
            z = 0;
            for (FlujoCajaIngreso i : ingresos) {
                Row fila = hoja.createRow(f++);
                String nombre = i.getConcepto() != null ? i.getConcepto().getNombreConcepto() : "-";
                String tipo = "AUTOMATICO".equals(i.getTipoCaptura()) ? "Automático" : "Manual";
                escribir(fila, 0, nombre, estiloTexto[z]);
                escribir(fila, 1, tipo, estiloTexto[z]);
                escribir(fila, 2, valorODouble(i.getValor()), estiloNumero[z]);
                totalIngresos = totalIngresos.add(i.getValor() != null ? i.getValor() : BigDecimal.ZERO);
                z = 1 - z;
            }
            f = escribirTotal(hoja, f, "TOTAL INGRESOS", totalIngresos, estiloTextoTotal, estiloNumeroTotal);
            f++; // fila en blanco

            f = escribirTotal(hoja, f, "TOTAL INGRESOS (1+2)", totalSaldoInicial.add(totalIngresos), estiloTextoTotal, estiloNumeroTotal);
            f++;

            // ---- 3) Priorizado (Fondos Disponibles) ----
            f = escribirSeccion(hoja, f, "3) PRIORIZADO (FONDOS DISPONIBLES)", estiloSeccion);
            BigDecimal[] resultado3 = new BigDecimal[1];
            f = escribirSeccionPriorizado(hoja, f, priorizados, "PRIORIZADO_ACTUAL", estiloCabecera, estiloTexto, estiloNumero, estiloTextoTotal, estiloNumeroTotal, "SUBTOTAL 3)", resultado3);
            f++; // fila en blanco

            // ---- 4) Montos Priorizados Pendientes de Ejecutar (Semana Actual) ----
            f = escribirSeccion(hoja, f, "4) MONTOS PRIORIZADOS PENDIENTES DE EJECUTAR (SEMANA ACTUAL)", estiloSeccion);
            BigDecimal[] resultado4 = new BigDecimal[1];
            f = escribirSeccionPriorizado(hoja, f, priorizados, "PENDIENTE_SEMANA_ACTUAL", estiloCabecera, estiloTexto, estiloNumero, estiloTextoTotal, estiloNumeroTotal, "SUBTOTAL 4)", resultado4);
            f++; // fila en blanco

            // ---- 6) 7) 8) Transferencias de Fondos ----
            // Cada sección ahora puede tener VARIAS filas (un concepto de
            // FC_EGR_CONCEPTO_TRANSF por fila, ver reset_bd.sql) en vez de un
            // solo valor con descripción libre — se listan todas las que
            // correspondan a cada tipo, con un guion si no hay ninguna.
            f = escribirSeccion(hoja, f, "6) 7) 8) TRANSFERENCIAS DE FONDOS", estiloSeccion);
            f = escribirCabeceraDosColumnas(hoja, f, "Concepto", "Descripción", "Valor (USD)", estiloCabecera);
            BigDecimal totalSri = BigDecimal.ZERO;
            BigDecimal totalTransferencias = BigDecimal.ZERO;
            z = 0;
            for (String[] tipoYEtiqueta : new String[][]{
                    {"SRI", "Transferencia de Fondos SRI"},
                    {"SHAYA_BOC2", "Transferencia de Fondos Shaya BOC2"},
                    {"HEDGE", "Transferencia Operaciones Hedge"}}) {
                boolean huboFila = false;
                for (FlujoCajaTransferencia t : transferencias) {
                    if (!tipoYEtiqueta[0].equals(t.getTipo())) {
                        continue;
                    }
                    huboFila = true;
                    BigDecimal valor = t.getValor() != null ? t.getValor() : BigDecimal.ZERO;
                    Row fila = hoja.createRow(f++);
                    escribir(fila, 0, tipoYEtiqueta[1], estiloTexto[z]);
                    escribir(fila, 1, textoODash(t.getDescripcion()), estiloTexto[z]);
                    escribir(fila, 2, valor.doubleValue(), estiloNumero[z]);
                    totalTransferencias = totalTransferencias.add(valor);
                    if ("SRI".equals(tipoYEtiqueta[0])) {
                        totalSri = totalSri.add(valor);
                    }
                    z = 1 - z;
                }
                if (!huboFila) {
                    Row fila = hoja.createRow(f++);
                    escribir(fila, 0, tipoYEtiqueta[1], estiloTexto[z]);
                    escribir(fila, 1, "-", estiloTexto[z]);
                    escribir(fila, 2, 0.0, estiloNumero[z]);
                    z = 1 - z;
                }
            }
            f = escribirTotal(hoja, f, "SUBTOTAL 6) 7) 8)", totalTransferencias, estiloTextoTotal, estiloNumeroTotal);
            f++; // fila en blanco

            // Egresos = 3+4+SRI. Shaya BOC2 y Hedge quedan fuera del total, igual
            // que en flujo-caja-egresos.html — son informativos. La sección 5
            // (Montos Priorizados Semanas Anteriores) se eliminó, ya no se usa.
            BigDecimal totalEgresos = resultado3[0].add(resultado4[0]).add(totalSri);
            f = escribirTotal(hoja, f, "TOTAL EGRESOS (3+4+SRI)", totalEgresos, estiloTextoTotal, estiloNumeroTotal);
            f++;
            f = escribirTotal(hoja, f, "SALDO FINAL ESTIMADO", totalSaldoInicial.add(totalIngresos).subtract(totalEgresos), estiloTextoTotal, estiloNumeroTotal);
            f++;

            // ---- Consorcios (si hay): un bloque de 2 columnas (Descripción | Valor)
            // por consorcio -- saldo inicial manual + snapshot de facturas guardado
            // al momento de Guardar (DETALLE_FACTURAS, una línea "descripción\tvalor"
            // por factura, ver flujo-caja-egresos.html) + total + Fondeo BCE (si
            // aplica, solo Shushufindi) + saldo final calculado. ----
            if (!consorcios.isEmpty()) {
                f = escribirSeccion(hoja, f, "INFORMACIÓN CONSORCIOS", estiloSeccion);
                for (FlujoCajaConsorcio c : consorcios) {
                    f = escribirSeccion(hoja, f, textoODash(c.getNombreConsorcio()), estiloCabecera);

                    String fechaInicial = c.getFechaEstimado() != null ? c.getFechaEstimado().format(FORMATO_FECHA) : "-";
                    String descripcionInicial = "Saldo estimado al " + fechaInicial
                            + (c.getDescripcion() != null && !c.getDescripcion().trim().isEmpty() ? ", " + c.getDescripcion() : "");
                    f = escribirTotal(hoja, f, descripcionInicial, valorOZero(c.getSaldoEstimado()), estiloTexto[0], estiloNumero[0]);

                    String detalle = c.getDetalleFacturas();
                    if (detalle == null || detalle.trim().isEmpty()) {
                        f = escribirTotal(hoja, f, "Sin facturas pendientes esta semana.", BigDecimal.ZERO, estiloTexto[0], estiloNumero[0]);
                    } else {
                        z = 0;
                        for (String linea : detalle.split("\n")) {
                            if (linea.trim().isEmpty()) {
                                continue;
                            }
                            String[] partes = linea.split("\t", 2);
                            BigDecimal valorFactura = partes.length > 1 ? new BigDecimal(partes[1]) : BigDecimal.ZERO;
                            f = escribirTotal(hoja, f, partes[0], valorFactura, estiloTexto[z], estiloNumero[z]);
                            z = 1 - z;
                        }
                    }

                    BigDecimal totalFacturas = valorOZero(c.getTotalFacturas());
                    f = escribirTotal(hoja, f, "Total cuenta por pagar " + textoODash(c.getNombreConsorcio()), totalFacturas, estiloTextoTotal, estiloNumeroTotal);

                    if (c.getFondeoBce() != null) {
                        f = escribirTotal(hoja, f, "Fondeo en proceso débito BCE", c.getFondeoBce(), estiloTexto[0], estiloNumero[0]);
                    }

                    BigDecimal saldoFinal = valorOZero(c.getSaldoEstimado()).subtract(totalFacturas).add(valorOZero(c.getFondeoBce()));
                    String fechaFinal = c.getFechaSaldoFinal() != null ? c.getFechaSaldoFinal().format(FORMATO_FECHA) : "-";
                    f = escribirTotal(hoja, f, "Saldo estimado al " + fechaFinal, saldoFinal, estiloTextoTotal, estiloNumeroTotal);
                    f++;
                }
            }

            // ---- Responsables ----
            f = escribirSeccion(hoja, f, "RESPONSABLES", estiloSeccion);
            f = escribirFirma(hoja, f, "Elaborado por", reporte.getElaboradoPor(), estiloTexto[0]);
            f = escribirFirma(hoja, f, "Aprobado por", reporte.getAprobadoPor(), estiloTexto[0]);
            f = escribirFirma(hoja, f, "Autorizado por", reporte.getAutorizadoPor(), estiloTexto[0]);

            ajustarAnchos(hoja);
            libro.write(salida);
        }
    }

    private int escribirTitulo(XSSFSheet hoja, int f, String texto, XSSFCellStyle estilo) {
        Row fila = hoja.createRow(f);
        fila.setHeightInPoints(20);
        escribir(fila, 0, texto, estilo);
        for (int i = 1; i <= ULTIMA_COLUMNA; i++) {
            escribir(fila, i, "", estilo);
        }
        hoja.addMergedRegion(new CellRangeAddress(f, f, 0, ULTIMA_COLUMNA));
        return f + 1;
    }

    private int escribirSeccion(XSSFSheet hoja, int f, String texto, XSSFCellStyle estilo) {
        Row fila = hoja.createRow(f);
        fila.setHeightInPoints(20);
        escribir(fila, 0, texto, estilo);
        for (int i = 1; i <= ULTIMA_COLUMNA; i++) {
            escribir(fila, i, "", estilo);
        }
        hoja.addMergedRegion(new CellRangeAddress(f, f, 0, ULTIMA_COLUMNA));
        return f + 1;
    }

    private int escribirCabeceraDosColumnas(XSSFSheet hoja, int f, String col1, String col2, String col3, XSSFCellStyle estilo) {
        Row fila = hoja.createRow(f);
        escribir(fila, 0, col1, estilo);
        escribir(fila, 1, col2, estilo);
        escribir(fila, 2, col3, estilo);
        return f + 1;
    }

    // Filas de una de las 3 secciones de Priorizado (una por categoría de egreso),
    // más su subtotal — mismo cálculo que las 3 tablas "Priorizado"/"Pendientes" de
    // flujo-caja-semanal.html. subtotalSalida[0] devuelve el subtotal para que el
    // caller lo use en el total general de Egresos (Java no permite retornar dos
    // valores).
    private int escribirSeccionPriorizado(XSSFSheet hoja, int f, List<FlujoCajaPriorizado> priorizados, String seccion,
                                           XSSFCellStyle estiloCabecera, XSSFCellStyle[] estiloTexto, XSSFCellStyle[] estiloNumero,
                                           XSSFCellStyle estiloTextoTotal, XSSFCellStyle estiloNumeroTotal,
                                           String etiquetaSubtotal, BigDecimal[] subtotalSalida) {
        f = escribirCabeceraDosColumnas(hoja, f, "Categoría", "Valor (USD)", "Nro. Procesos", estiloCabecera);
        BigDecimal subtotal = BigDecimal.ZERO;
        int z = 0;
        for (FlujoCajaPriorizado p : priorizados) {
            if (!seccion.equals(p.getSeccion())) {
                continue;
            }
            Row fila = hoja.createRow(f++);
            String categoria = p.getCategoriaEgreso() != null ? p.getCategoriaEgreso().getNombreCategoria() : "-";
            escribir(fila, 0, categoria, estiloTexto[z]);
            escribir(fila, 1, valorODouble(p.getValor()), estiloNumero[z]);
            escribir(fila, 2, p.getNroProcesos() != null ? p.getNroProcesos().doubleValue() : 0.0, estiloNumero[z]);
            subtotal = subtotal.add(p.getValor() != null ? p.getValor() : BigDecimal.ZERO);
            z = 1 - z;
        }
        f = escribirTotal(hoja, f, etiquetaSubtotal, subtotal, estiloTextoTotal, estiloNumeroTotal);
        subtotalSalida[0] = subtotal;
        return f;
    }

    private int escribirTotal(XSSFSheet hoja, int f, String etiqueta, BigDecimal valor, XSSFCellStyle estiloTexto, XSSFCellStyle estiloNumero) {
        Row fila = hoja.createRow(f);
        escribir(fila, 0, etiqueta, estiloTexto);
        escribir(fila, 1, "", estiloTexto);
        escribir(fila, 2, valor.doubleValue(), estiloNumero);
        hoja.addMergedRegion(new CellRangeAddress(f, f, 0, 1));
        return f + 1;
    }

    private int escribirFirma(XSSFSheet hoja, int f, String etiqueta, String nombre, XSSFCellStyle estilo) {
        Row fila = hoja.createRow(f);
        escribir(fila, 0, etiqueta + ":", estilo);
        escribir(fila, 1, textoODash(nombre), estilo);
        escribir(fila, 2, "", estilo);
        return f + 1;
    }

    private double valorODouble(BigDecimal valor) {
        return valor != null ? valor.doubleValue() : 0.0;
    }

    private BigDecimal valorOZero(BigDecimal valor) {
        return valor != null ? valor : BigDecimal.ZERO;
    }

    private String textoODash(String valor) {
        return (valor != null && !valor.trim().isEmpty()) ? valor : "-";
    }

    private String descripcionPeriodo(FlujoCajaReporte reporte) {
        return FlujoCajaFechaUtils.descripcionPeriodo(reporte.getFechaInicio(), reporte.getFechaFin());
    }

    private void ajustarAnchos(XSSFSheet hoja) {
        for (int i = 0; i <= ULTIMA_COLUMNA; i++) {
            hoja.autoSizeColumn(i);
            int ancho = hoja.getColumnWidth(i) + 512;
            hoja.setColumnWidth(i, Math.max(ANCHO_MINIMO, Math.min(ANCHO_MAXIMO, ancho)));
        }
    }

    private void escribir(Row fila, int columna, String texto, XSSFCellStyle estilo) {
        Cell celda = fila.createCell(columna);
        celda.setCellValue(texto);
        celda.setCellStyle(estilo);
    }

    private void escribir(Row fila, int columna, double valor, XSSFCellStyle estilo) {
        Cell celda = fila.createCell(columna);
        celda.setCellValue(valor);
        celda.setCellStyle(estilo);
    }

    private XSSFCellStyle crearEstiloTitulo(XSSFWorkbook libro) {
        XSSFFont fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setFontHeightInPoints((short) 14);
        fuente.setColor(new XSSFColor(AZUL_OSCURO, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        return estilo;
    }

    private XSSFCellStyle crearEstiloSubtitulo(XSSFWorkbook libro) {
        XSSFFont fuente = libro.createFont();
        fuente.setFontHeightInPoints((short) 10);
        fuente.setColor(new XSSFColor(AZUL_MEDIO, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        return estilo;
    }

    private XSSFCellStyle crearEstiloCabecera(XSSFWorkbook libro, byte[] fondo) {
        XSSFFont fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setFontHeightInPoints((short) 10);
        fuente.setColor(new XSSFColor(new byte[]{(byte) 255, (byte) 255, (byte) 255}, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        estilo.setFillForegroundColor(new XSSFColor(fondo, null));
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setAlignment(HorizontalAlignment.CENTER);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        aplicarBordes(estilo);
        return estilo;
    }

    private XSSFCellStyle crearEstiloDatos(XSSFWorkbook libro, String formato, boolean alterna) {
        XSSFCellStyle estilo = libro.createCellStyle();
        if (formato != null) {
            estilo.setDataFormat(libro.createDataFormat().getFormat(formato));
            estilo.setAlignment(HorizontalAlignment.RIGHT);
        }
        if (alterna) {
            estilo.setFillForegroundColor(new XSSFColor(GRIS_FILA, null));
            estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        }
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        aplicarBordes(estilo);
        return estilo;
    }

    private XSSFCellStyle crearEstiloTotal(XSSFWorkbook libro, String formato) {
        XSSFFont fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setColor(new XSSFColor(AZUL_OSCURO, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        estilo.setFillForegroundColor(new XSSFColor(GRIS_FILA, null));
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        if (formato != null) {
            estilo.setDataFormat(libro.createDataFormat().getFormat(formato));
            estilo.setAlignment(HorizontalAlignment.RIGHT);
        }
        aplicarBordes(estilo);
        estilo.setBorderTop(BorderStyle.DOUBLE);
        return estilo;
    }

    private void aplicarBordes(XSSFCellStyle estilo) {
        XSSFColor borde = new XSSFColor(GRIS_BORDE, null);
        estilo.setBorderTop(BorderStyle.THIN);
        estilo.setBorderBottom(BorderStyle.THIN);
        estilo.setBorderLeft(BorderStyle.THIN);
        estilo.setBorderRight(BorderStyle.THIN);
        estilo.setTopBorderColor(borde);
        estilo.setBottomBorderColor(borde);
        estilo.setLeftBorderColor(borde);
        estilo.setRightBorderColor(borde);
    }
}
