package com.finanzas.gestionfinanzas.dto;

import java.math.BigDecimal;

// Un pago elegido de la vista APPS.XXOCS_AP_CXP_PAGOS_PROV_V del ERP, tal
// cual lo mandó el navegador (ver ProvisionesController.crearAnterior/crearMixto).
public class PagoSeleccionadoRequest {

    private String ruc;
    private String documento;
    private String vendorName;
    private String descripcion;
    private BigDecimal monto;
    private String fechaPago;

    public String getRuc() { return ruc; }
    public void setRuc(String ruc) { this.ruc = ruc; }

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public String getVendorName() { return vendorName; }
    public void setVendorName(String vendorName) { this.vendorName = vendorName; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public BigDecimal getMonto() { return monto; }
    public void setMonto(BigDecimal monto) { this.monto = monto; }

    public String getFechaPago() { return fechaPago; }
    public void setFechaPago(String fechaPago) { this.fechaPago = fechaPago; }
}
