package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.TipoArchivo;
import com.finanzas.gestionfinanzas.repository.bdd.ArchivoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoArchivoRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/mantenimiento/tipos-archivo")
public class MantenimientoTipoArchivoController {

    private final TipoArchivoRepository tipoArchivoRepository;
    private final ArchivoRepository archivoRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoTipoArchivoController(TipoArchivoRepository tipoArchivoRepository,
                                              ArchivoRepository archivoRepository,
                                              AuditoriaSessionService auditoriaSessionService) {
        this.tipoArchivoRepository = tipoArchivoRepository;
        this.archivoRepository = archivoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) String nombre,
                         @RequestParam(required = false) String estado,
                         HttpServletRequest request, Model model) {
        Page<TipoArchivo> tiposArchivoPage =
                tipoArchivoRepository.buscar(normalizar(nombre), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("tiposArchivoPage", tiposArchivoPage);
        model.addAttribute("nombre", nombre);
        model.addAttribute("estado", estado);
        return "mantenimiento/tipos-archivo";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idTipoArchivo,
                          @RequestParam String nombreTipoArchivo,
                          @RequestParam String estado,
                          RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        TipoArchivo tipoArchivo = (idTipoArchivo != null)
                ? tipoArchivoRepository.findById(idTipoArchivo).orElseThrow(() -> new RuntimeException("Tipo de archivo no encontrado"))
                : new TipoArchivo();

        boolean esNuevo = tipoArchivo.getIdTipoArchivo() == null;

        tipoArchivo.setNombreTipoArchivo(nombreTipoArchivo.trim());
        tipoArchivo.setEstado(estado);

        if (esNuevo) {
            tipoArchivo.setIdUsuarioCreacion(obtenerUsuarioActual());
            tipoArchivo.setFechaCreacion(LocalDateTime.now());
        }

        tipoArchivoRepository.save(tipoArchivo);
        auditoriaSessionService.registrarComentario("TIPO_ARCHIVO", tipoArchivo.getIdTipoArchivo(),
                esNuevo ? "INSERT" : "UPDATE",
                (esNuevo ? "Creó" : "Editó") + " el tipo de archivo " + tipoArchivo.getNombreTipoArchivo() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/tipos-archivo";
    }

    @PostMapping("/eliminar/{idTipoArchivo}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idTipoArchivo, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        if (archivoRepository.existsByTipoArchivo_IdTipoArchivo(idTipoArchivo)) {
            redirectAttributes.addFlashAttribute("error",
                    "Este tipo de archivo tiene archivos asociados, no se puede eliminar");
            return "redirect:/mantenimiento/tipos-archivo";
        }

        String nombreEliminado = tipoArchivoRepository.findById(idTipoArchivo)
                .map(TipoArchivo::getNombreTipoArchivo).orElse("(desconocido)");
        try {
            tipoArchivoRepository.deleteById(idTipoArchivo);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados");
            return "redirect:/mantenimiento/tipos-archivo";
        }
        auditoriaSessionService.registrarComentario("TIPO_ARCHIVO", idTipoArchivo, "DELETE",
                "Eliminó el tipo de archivo " + nombreEliminado + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/tipos-archivo";
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }
}
