package com.finanzas.gestionfinanzas.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class FlujoCajaReporteRequest {

    private Long idReporte; // null = reporte nuevo
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private LocalDate fechaSaldoInicial;
    private String observacion1;
    private String observacion2;
    private String observacion3;
    private String elaboradoPor;
    private String aprobadoPor;
    private String autorizadoPor;

    private List<SaldoInicialItem> saldosIniciales;
    private List<IngresoItem> ingresos;
    private List<PriorizadoItem> priorizados;
    private List<TransferenciaItem> transferencias;
    private List<ConsorcioItem> consorcios;

    public static class SaldoInicialItem {
        private Long idCuentaBancaria;
        private BigDecimal valor;
        private String tipoCaptura;
        // getters/setters
        public Long getIdCuentaBancaria() { return idCuentaBancaria; }
        public void setIdCuentaBancaria(Long idCuentaBancaria) { this.idCuentaBancaria = idCuentaBancaria; }
        public BigDecimal getValor() { return valor; }
        public void setValor(BigDecimal valor) { this.valor = valor; }
        public String getTipoCaptura() { return tipoCaptura; }
        public void setTipoCaptura(String tipoCaptura) { this.tipoCaptura = tipoCaptura; }
    }

    public static class IngresoItem {
        private Long idConcepto;
        private BigDecimal valor; // ignorado si el concepto es automático, se recalcula en servidor
        private String tipoCaptura;
        public Long getIdConcepto() { return idConcepto; }
        public void setIdConcepto(Long idConcepto) { this.idConcepto = idConcepto; }
        public BigDecimal getValor() { return valor; }
        public void setValor(BigDecimal valor) { this.valor = valor; }
        public String getTipoCaptura() { return tipoCaptura; }
        public void setTipoCaptura(String tipoCaptura) { this.tipoCaptura = tipoCaptura; }
    }

    public static class PriorizadoItem {
        private String seccion; // 'PRIORIZADO_ACTUAL' | 'PENDIENTE_SEMANA_ACTUAL'
        private Long idCategoriaEgreso;
        private BigDecimal valor;
        private Integer nroProcesos;
        public String getSeccion() { return seccion; }
        public void setSeccion(String seccion) { this.seccion = seccion; }
        public Long getIdCategoriaEgreso() { return idCategoriaEgreso; }
        public void setIdCategoriaEgreso(Long idCategoriaEgreso) { this.idCategoriaEgreso = idCategoriaEgreso; }
        public BigDecimal getValor() { return valor; }
        public void setValor(BigDecimal valor) { this.valor = valor; }
        public Integer getNroProcesos() { return nroProcesos; }
        public void setNroProcesos(Integer nroProcesos) { this.nroProcesos = nroProcesos; }
    }

    public static class TransferenciaItem {
        // Concepto elegido del catálogo FC_EGR_CONCEPTO_TRANSF (reemplaza a los
        // viejos campos tipo/descripcion libre — el TIPO ahora sale del
        // concepto, ver FlujoCajaReporteService).
        private Long idConcepto;
        private BigDecimal valor;
        public Long getIdConcepto() { return idConcepto; }
        public void setIdConcepto(Long idConcepto) { this.idConcepto = idConcepto; }
        public BigDecimal getValor() { return valor; }
        public void setValor(BigDecimal valor) { this.valor = valor; }
    }

    public static class ConsorcioItem {
        private String nombreConsorcio;
        private String descripcion;
        private BigDecimal saldoEstimado;
        private LocalDate fechaEstimado;
        // Snapshot armado en el navegador al momento de Guardar (ver
        // flujo-caja-egresos.html) -- no se recalcula en el servidor.
        private String detalleFacturas;
        private BigDecimal totalFacturas;
        private BigDecimal fondeoBce; // solo Shushufindi, null en Shaya
        private LocalDate fechaSaldoFinal;
        public String getNombreConsorcio() { return nombreConsorcio; }
        public void setNombreConsorcio(String nombreConsorcio) { this.nombreConsorcio = nombreConsorcio; }
        public String getDescripcion() { return descripcion; }
        public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
        public BigDecimal getSaldoEstimado() { return saldoEstimado; }
        public void setSaldoEstimado(BigDecimal saldoEstimado) { this.saldoEstimado = saldoEstimado; }
        public LocalDate getFechaEstimado() { return fechaEstimado; }
        public void setFechaEstimado(LocalDate fechaEstimado) { this.fechaEstimado = fechaEstimado; }
        public String getDetalleFacturas() { return detalleFacturas; }
        public void setDetalleFacturas(String detalleFacturas) { this.detalleFacturas = detalleFacturas; }
        public BigDecimal getTotalFacturas() { return totalFacturas; }
        public void setTotalFacturas(BigDecimal totalFacturas) { this.totalFacturas = totalFacturas; }
        public BigDecimal getFondeoBce() { return fondeoBce; }
        public void setFondeoBce(BigDecimal fondeoBce) { this.fondeoBce = fondeoBce; }
        public LocalDate getFechaSaldoFinal() { return fechaSaldoFinal; }
        public void setFechaSaldoFinal(LocalDate fechaSaldoFinal) { this.fechaSaldoFinal = fechaSaldoFinal; }
    }

    // getters/setters de la clase principal
    public Long getIdReporte() { return idReporte; }
    public void setIdReporte(Long idReporte) { this.idReporte = idReporte; }
    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }
    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }
    public LocalDate getFechaSaldoInicial() { return fechaSaldoInicial; }
    public void setFechaSaldoInicial(LocalDate fechaSaldoInicial) { this.fechaSaldoInicial = fechaSaldoInicial; }
    public String getObservacion1() { return observacion1; }
    public void setObservacion1(String observacion1) { this.observacion1 = observacion1; }
    public String getObservacion2() { return observacion2; }
    public void setObservacion2(String observacion2) { this.observacion2 = observacion2; }
    public String getObservacion3() { return observacion3; }
    public void setObservacion3(String observacion3) { this.observacion3 = observacion3; }
    public String getElaboradoPor() { return elaboradoPor; }
    public void setElaboradoPor(String elaboradoPor) { this.elaboradoPor = elaboradoPor; }
    public String getAprobadoPor() { return aprobadoPor; }
    public void setAprobadoPor(String aprobadoPor) { this.aprobadoPor = aprobadoPor; }
    public String getAutorizadoPor() { return autorizadoPor; }
    public void setAutorizadoPor(String autorizadoPor) { this.autorizadoPor = autorizadoPor; }
    public List<SaldoInicialItem> getSaldosIniciales() { return saldosIniciales; }
    public void setSaldosIniciales(List<SaldoInicialItem> saldosIniciales) { this.saldosIniciales = saldosIniciales; }
    public List<IngresoItem> getIngresos() { return ingresos; }
    public void setIngresos(List<IngresoItem> ingresos) { this.ingresos = ingresos; }
    public List<PriorizadoItem> getPriorizados() { return priorizados; }
    public void setPriorizados(List<PriorizadoItem> priorizados) { this.priorizados = priorizados; }
    public List<TransferenciaItem> getTransferencias() { return transferencias; }
    public void setTransferencias(List<TransferenciaItem> transferencias) { this.transferencias = transferencias; }
    public List<ConsorcioItem> getConsorcios() { return consorcios; }
    public void setConsorcios(List<ConsorcioItem> consorcios) { this.consorcios = consorcios; }
}