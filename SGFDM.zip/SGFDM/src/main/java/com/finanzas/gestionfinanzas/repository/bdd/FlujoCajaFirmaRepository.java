package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaFirma;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FlujoCajaFirmaRepository extends JpaRepository<FlujoCajaFirma, Long> {
    List<FlujoCajaFirma> findByReporte_IdReporteOrderByFechaFirmaAsc(Long idReporte);

    // Sirve para saber si ya es seguro (o no) regenerar el PDF base del
    // reporte: si nadie firmó todavía, no hay ninguna firma real que perder
    // al regenerarlo con los datos más recientes (ver FlujoCajaFirmaService).
    boolean existsByReporte_IdReporte(Long idReporte);
}
