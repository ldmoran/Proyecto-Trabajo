package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.Auditoria;
import com.finanzas.gestionfinanzas.repository.bdd.AuditoriaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.UsuarioRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

// Solo lectura: la tabla AUDITORIA la alimentan los triggers de Oracle
// (ver reset_bd.sql), no hay nada que crear/editar/eliminar desde acá.
@Controller
@RequestMapping("/auditoria")
public class AuditoriaController {

    // La tabla AUDITORIA crece para siempre (queda todo el historial en la base,
    // eso no se toca), pero esta pantalla es de consulta rápida de actividad
    // reciente, no un archivo histórico completo — así que a propósito solo
    // muestra los últimos TAMANO_PAGINA * MAX_PAGINAS registros (20 * 5 = 100),
    // sin importar que dentro de un par de años haya millones de filas en la
    // tabla real. Por eso el tope se aplica ACÁ (recortando a los 100 más
    // recientes antes de paginar), no dejando que crezca con auditoriaPage.totalPages.
    private static final int TAMANO_PAGINA = 20;
    private static final int MAX_PAGINAS = 5;

    private final AuditoriaRepository auditoriaRepository;
    private final UsuarioRepository usuarioRepository;

    public AuditoriaController(AuditoriaRepository auditoriaRepository,
                               UsuarioRepository usuarioRepository) {
        this.auditoriaRepository = auditoriaRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                         @RequestParam(required = false) String nombreTabla,
                         @RequestParam(required = false) String accion,
                         @RequestParam(required = false) String usuarioAccion,
                         HttpServletRequest request, Model model) {
        int paginaPedida = Math.max(0, Math.min(page, MAX_PAGINAS - 1));

        List<Auditoria> ultimos100 = auditoriaRepository.buscar(
                normalizar(nombreTabla), normalizar(accion), normalizar(usuarioAccion),
                PageRequest.of(0, TAMANO_PAGINA * MAX_PAGINAS)).getContent();

        int desde = Math.min(paginaPedida * TAMANO_PAGINA, ultimos100.size());
        int hasta = Math.min(desde + TAMANO_PAGINA, ultimos100.size());
        Page<Auditoria> auditoriaPage = new PageImpl<>(
                ultimos100.subList(desde, hasta), PageRequest.of(paginaPedida, TAMANO_PAGINA), ultimos100.size());

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("auditoriaPage", auditoriaPage);
        model.addAttribute("nombresTabla", auditoriaRepository.findDistinctNombreTabla());
        model.addAttribute("nombreTabla", nombreTabla);
        model.addAttribute("accion", accion);
        model.addAttribute("usuarioAccion", usuarioAccion);
        return "auditoria";
    }

    // Ficha de la persona que aparece en una fila de la auditoría. Sale de lo que
    // el sistema guardó la última vez que esa persona inició sesión.
    @GetMapping("/usuario-fragment")
    public String usuarioFragment(@RequestParam String usuario, Model model) {
        model.addAttribute("usuarioConsultado", usuario);
        model.addAttribute("detalleUsuario", usuarioRepository.findByUsuario(usuario).orElse(null));
        return "fragments/usuario-detalle :: usuarioDetalleFragment";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }
}
