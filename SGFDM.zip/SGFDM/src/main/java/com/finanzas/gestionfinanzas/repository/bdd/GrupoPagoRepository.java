package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.GrupoPago;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GrupoPagoRepository extends JpaRepository<GrupoPago, String> {

    List<GrupoPago> findAllByOrderByDescripcionAsc();
}
