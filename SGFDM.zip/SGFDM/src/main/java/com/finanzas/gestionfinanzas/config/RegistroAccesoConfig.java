package com.finanzas.gestionfinanzas.config;

import com.finanzas.gestionfinanzas.auth.dto.response.AuthResponseDTO;
import com.finanzas.gestionfinanzas.service.impl.UsuarioAccesoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// Registra el acceso de cada persona que entra al sistema, UNA sola vez por sesión.
//
// Se hace aquí, en un interceptor aparte, y no dentro del flujo de autenticación,
// para no tocar nada del login: esta clase se limita a mirar quién está autenticado
// en la primera petición de la sesión y a guardar su ficha. Si algo falla al
// guardar, se registra en el log y la persona sigue trabajando con normalidad:
// llevar la bitácora de accesos nunca debe impedir el uso del sistema.
@Configuration
public class RegistroAccesoConfig implements WebMvcConfigurer {

    private static final String MARCA_SESION = "accesoRegistrado";

    private final UsuarioAccesoService usuarioAccesoService;

    public RegistroAccesoConfig(UsuarioAccesoService usuarioAccesoService) {
        this.usuarioAccesoService = usuarioAccesoService;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new RegistroAccesoInterceptor(usuarioAccesoService));
    }

    private static class RegistroAccesoInterceptor implements HandlerInterceptor {

        private static final Logger log = LoggerFactory.getLogger(RegistroAccesoInterceptor.class);

        private final UsuarioAccesoService usuarioAccesoService;

        RegistroAccesoInterceptor(UsuarioAccesoService usuarioAccesoService) {
            this.usuarioAccesoService = usuarioAccesoService;
        }

        @Override
        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
            HttpSession sesion = request.getSession(false);
            if (sesion == null || sesion.getAttribute(MARCA_SESION) != null) {
                return true;
            }

            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth == null || !auth.isAuthenticated() || !(auth.getPrincipal() instanceof AuthResponseDTO)) {
                return true;
            }

            // Se marca antes de guardar: si el guardado falla, no se reintenta en
            // cada petición de la sesión.
            sesion.setAttribute(MARCA_SESION, Boolean.TRUE);

            try {
                usuarioAccesoService.registrarAcceso((AuthResponseDTO) auth.getPrincipal());
            } catch (Exception e) {
                log.warn("No se pudo registrar el acceso del usuario", e);
            }

            return true;
        }
    }
}
