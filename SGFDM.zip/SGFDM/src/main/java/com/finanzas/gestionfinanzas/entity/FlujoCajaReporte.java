package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "FC_REPORTE")
public class FlujoCajaReporte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_REPORTE")
    private Long idReporte;

    @Column(name = "FECHA_INICIO")
    private LocalDate fechaInicio;

    @Column(name = "FECHA_FIN")
    private LocalDate fechaFin;

    @Column(name = "FECHA_SALDO_INICIAL")
    private LocalDate fechaSaldoInicial;

    @Column(name = "SALDO_INICIAL_TOTAL")
    private BigDecimal saldoInicialTotal;

    @Column(name = "INGRESOS_TOTAL")
    private BigDecimal ingresosTotal;

    @Column(name = "EGRESOS_TOTAL")
    private BigDecimal egresosTotal;

    @Column(name = "SALDO_FINAL")
    private BigDecimal saldoFinal;

    @Column(name = "OBSERVACION_1")
    private String observacion1;

    @Column(name = "OBSERVACION_2")
    private String observacion2;

    @Column(name = "OBSERVACION_3")
    private String observacion3;

    @Column(name = "ELABORADO_POR")
    private String elaboradoPor;

    @Column(name = "APROBADO_POR")
    private String aprobadoPor;

    @Column(name = "AUTORIZADO_POR")
    private String autorizadoPor;

    // Paso previo, liviano (sin certificado .p12), antes de las 3 firmas
    // reales de arriba: un solo estado de proceso a nivel de todo el reporte
    // (ver FlujoCajaReporteService.revisarProceso/aprobarProceso). Es
    // independiente de elaboradoPor/aprobadoPor/autorizadoPor (las firmas
    // reales), aunque comparta el nombre "Aprobado" con una de ellas.
    // estadoProceso == "APROBADO" es lo que habilita el bloque de firmas reales.
    @Column(name = "ESTADO_PROCESO")
    private String estadoProceso;

    @Column(name = "PROCESO_REVISADO_POR")
    private String procesoRevisadoPor;

    @Column(name = "PROCESO_FECHA_REVISION")
    private LocalDateTime procesoFechaRevision;

    @Column(name = "PROCESO_APROBADO_POR")
    private String procesoAprobadoPor;

    @Column(name = "PROCESO_FECHA_APROBACION")
    private LocalDateTime procesoFechaAprobacion;

    // 'B' = Borrador, 'A' = Aprobado (mismo patrón que Factura.estado)
    @Column(name = "ESTADO")
    private String estado;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdReporte() { return idReporte; }
    public void setIdReporte(Long idReporte) { this.idReporte = idReporte; }

    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }

    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }

    public LocalDate getFechaSaldoInicial() { return fechaSaldoInicial; }
    public void setFechaSaldoInicial(LocalDate fechaSaldoInicial) { this.fechaSaldoInicial = fechaSaldoInicial; }

    public BigDecimal getSaldoInicialTotal() { return saldoInicialTotal; }
    public void setSaldoInicialTotal(BigDecimal saldoInicialTotal) { this.saldoInicialTotal = saldoInicialTotal; }

    public BigDecimal getIngresosTotal() { return ingresosTotal; }
    public void setIngresosTotal(BigDecimal ingresosTotal) { this.ingresosTotal = ingresosTotal; }

    public BigDecimal getEgresosTotal() { return egresosTotal; }
    public void setEgresosTotal(BigDecimal egresosTotal) { this.egresosTotal = egresosTotal; }

    public BigDecimal getSaldoFinal() { return saldoFinal; }
    public void setSaldoFinal(BigDecimal saldoFinal) { this.saldoFinal = saldoFinal; }

    public String getObservacion1() { return observacion1; }
    public void setObservacion1(String observacion1) { this.observacion1 = observacion1; }

    public String getObservacion2() { return observacion2; }
    public void setObservacion2(String observacion2) { this.observacion2 = observacion2; }

    public String getObservacion3() { return observacion3; }
    public void setObservacion3(String observacion3) { this.observacion3 = observacion3; }

    public String getElaboradoPor() { return elaboradoPor; }
    public void setElaboradoPor(String elaboradoPor) { this.elaboradoPor = elaboradoPor; }

    public String getAprobadoPor() { return aprobadoPor; }
    public void setAprobadoPor(String aprobadoPor) { this.aprobadoPor = aprobadoPor; }

    public String getAutorizadoPor() { return autorizadoPor; }
    public void setAutorizadoPor(String autorizadoPor) { this.autorizadoPor = autorizadoPor; }

    public String getEstadoProceso() { return estadoProceso; }
    public void setEstadoProceso(String estadoProceso) { this.estadoProceso = estadoProceso; }

    public String getProcesoRevisadoPor() { return procesoRevisadoPor; }
    public void setProcesoRevisadoPor(String procesoRevisadoPor) { this.procesoRevisadoPor = procesoRevisadoPor; }

    public LocalDateTime getProcesoFechaRevision() { return procesoFechaRevision; }
    public void setProcesoFechaRevision(LocalDateTime procesoFechaRevision) { this.procesoFechaRevision = procesoFechaRevision; }

    public String getProcesoAprobadoPor() { return procesoAprobadoPor; }
    public void setProcesoAprobadoPor(String procesoAprobadoPor) { this.procesoAprobadoPor = procesoAprobadoPor; }

    public LocalDateTime getProcesoFechaAprobacion() { return procesoFechaAprobacion; }
    public void setProcesoFechaAprobacion(LocalDateTime procesoFechaAprobacion) { this.procesoFechaAprobacion = procesoFechaAprobacion; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}