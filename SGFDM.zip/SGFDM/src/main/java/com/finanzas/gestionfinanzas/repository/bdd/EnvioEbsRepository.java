package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.EnvioEbs;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EnvioEbsRepository extends JpaRepository<EnvioEbs, Long> {

    @Query(value = "SELECT e FROM EnvioEbs e ORDER BY e.idEnvioEbs DESC",
            countQuery = "SELECT COUNT(e) FROM EnvioEbs e")
    Page<EnvioEbs> findAllOrdenado(Pageable pageable);
}
