package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.ConceptoTransferencia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ConceptoTransferenciaRepository extends JpaRepository<ConceptoTransferencia, Long> {

    // Catálogo completo (activos) para armar los 3 selectores de la pantalla
    // Egresos (SRI/SHAYA_BOC2/HEDGE) — se filtra por tipo en el JS, mismo
    // patrón que conceptosManualJson en Ingresos.
    List<ConceptoTransferencia> findByEstadoOrderByNombreConcepto(String estado);

    @Query("SELECT c FROM ConceptoTransferencia c " +
            "WHERE (:nombre IS NULL OR UPPER(c.nombreConcepto) LIKE UPPER(CONCAT('%', :nombre, '%'))) " +
            "AND (:tipo IS NULL OR c.tipo = :tipo) " +
            "AND (:estado IS NULL OR c.estado = :estado) " +
            "ORDER BY c.tipo, c.nombreConcepto")
    Page<ConceptoTransferencia> buscar(@Param("nombre") String nombre, @Param("tipo") String tipo,
                                        @Param("estado") String estado, Pageable pageable);
}
