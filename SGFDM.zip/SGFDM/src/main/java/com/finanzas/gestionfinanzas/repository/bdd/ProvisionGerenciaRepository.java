package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.ProvisionGerencia;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProvisionGerenciaRepository extends JpaRepository<ProvisionGerencia, Long> {

    List<ProvisionGerencia> findByEstadoOrderByNombreGerencia(String estado);
}
