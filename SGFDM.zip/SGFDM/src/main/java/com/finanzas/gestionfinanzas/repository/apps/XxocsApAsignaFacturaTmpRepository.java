package com.finanzas.gestionfinanzas.repository.apps;

import com.finanzas.gestionfinanzas.entity.XxocsApAsignaFacturaTmp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface XxocsApAsignaFacturaTmpRepository extends JpaRepository<XxocsApAsignaFacturaTmp, Long> {

    // INSERT directo (no .save()) — mismo motivo que PamAsignaFacturaTmpRepository.
    @Modifying
    @Query(value = "INSERT INTO APPS.XXOCS_AP_ASIGNA_FACTURAS_TMP (INVOICE_ID, COMENTARIO, LOAD_DATE, CODIGO_FC) " +
            "VALUES (:invoiceId, :comentario, SYSDATE, :codigoFc)", nativeQuery = true)
    void insertar(@Param("invoiceId") Long invoiceId, @Param("comentario") String comentario, @Param("codigoFc") String codigoFc);
}
