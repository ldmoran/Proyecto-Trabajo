package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "FC_EGR_PRIORIZADO")
public class FlujoCajaPriorizado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_PRIORIZADO")
    private Long idPriorizado;

    @ManyToOne
    @JoinColumn(name = "ID_REPORTE")
    private FlujoCajaReporte reporte;

    // 'PRIORIZADO_ACTUAL' | 'PENDIENTE_SEMANA_ACTUAL'
    @Column(name = "SECCION")
    private String seccion;

    @ManyToOne
    @JoinColumn(name = "ID_CATEGORIA_EGRESO")
    private CategoriaEgreso categoriaEgreso;

    @Column(name = "VALOR")
    private BigDecimal valor;

    @Column(name = "NRO_PROCESOS")
    private Integer nroProcesos;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdPriorizado() { return idPriorizado; }
    public void setIdPriorizado(Long idPriorizado) { this.idPriorizado = idPriorizado; }

    public FlujoCajaReporte getReporte() { return reporte; }
    public void setReporte(FlujoCajaReporte reporte) { this.reporte = reporte; }

    public String getSeccion() { return seccion; }
    public void setSeccion(String seccion) { this.seccion = seccion; }

    public CategoriaEgreso getCategoriaEgreso() { return categoriaEgreso; }
    public void setCategoriaEgreso(CategoriaEgreso categoriaEgreso) { this.categoriaEgreso = categoriaEgreso; }

    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }

    public Integer getNroProcesos() { return nroProcesos; }
    public void setNroProcesos(Integer nroProcesos) { this.nroProcesos = nroProcesos; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}