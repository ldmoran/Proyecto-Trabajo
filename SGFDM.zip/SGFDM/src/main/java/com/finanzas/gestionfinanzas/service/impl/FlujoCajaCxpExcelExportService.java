package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.GrupoPago;
import com.finanzas.gestionfinanzas.entity.GrupoPagoGerencia;
import com.finanzas.gestionfinanzas.repository.bdd.GrupoPagoGerenciaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.GrupoPagoRepository;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Excel de las facturas de Cuentas por Pagar cubiertas con los Ingresos de un
// reporte (mismo cálculo que FlujoCajaCxpPagableService.calcularCubiertasParaAutorizar,
// que ya usa marcarAutorizado). Mismo look & feel (colores, bordes) que
// FlujoCajaExcelExportService para que todos los Excel del sistema se vean
// consistentes, pero acá es una sola tabla plana en vez de un reporte por
// secciones — la pantalla solo muestra 6 columnas (paginadas, con buscador),
// pero el Excel lleva TODAS las columnas de la factura, sin paginar ni filtrar.
@Service
public class FlujoCajaCxpExcelExportService {

    // Mismos índices que FlujoCajaCxpPagableService (misma forma de fila).
    private static final int ORDEN = 0, FUENTE = 1, INVOICE_ID = 2, PROVEEDOR = 3, TIPO_DOCUMENTO = 4, DOCUMENTO = 5,
            FECHA_DOCUMENTO = 6, TERMINO_PAGO = 7, GRUPO_PAGO = 8, CATEGORIA = 9, METODO_PAGO = 10,
            FECHA_VENCIMIENTO = 11, IMPORTE_A_PAGAR = 12, DESCRIPCION = 13, PRIORIZADO = 14;

    private static final String[] ENCABEZADOS = {
            "Orden", "Fuente", "Invoice ID", "Proveedor", "Tipo Documento", "Documento",
            "Fecha Documento", "Término de Pago", "Grupo de Pago", "Categoría", "Método de Pago",
            "Fecha Vencimiento", "Importe a Pagar (USD)", "Descripción", "Priorizado", "Gerencia"
    };

    private static final byte[] AZUL_MEDIO = {0, 115, (byte) 171};
    private static final byte[] GRIS_FILA = {(byte) 244, (byte) 247, (byte) 249};
    private static final byte[] GRIS_BORDE = {(byte) 208, (byte) 216, (byte) 222};

    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final GrupoPagoRepository grupoPagoRepository;
    private final GrupoPagoGerenciaRepository grupoPagoGerenciaRepository;

    public FlujoCajaCxpExcelExportService(GrupoPagoRepository grupoPagoRepository,
                                           GrupoPagoGerenciaRepository grupoPagoGerenciaRepository) {
        this.grupoPagoRepository = grupoPagoRepository;
        this.grupoPagoGerenciaRepository = grupoPagoGerenciaRepository;
    }

    public void escribir(List<Object[]> filas, OutputStream salida) throws IOException {
        Map<String, String> gerenciaPorCodigo = new HashMap<>();
        for (GrupoPagoGerencia g : grupoPagoGerenciaRepository.findAll()) {
            gerenciaPorCodigo.put(g.getCodigoGrupoPago(), g.getGerencia());
        }
        Map<String, String> descripcionPorCodigo = new HashMap<>();
        for (GrupoPago g : grupoPagoRepository.findAll()) {
            descripcionPorCodigo.put(g.getCodigoGrupoPago(), g.getDescripcion());
        }

        try (XSSFWorkbook libro = new XSSFWorkbook()) {
            XSSFSheet hoja = libro.createSheet("Cuentas por Pagar");

            XSSFCellStyle estiloCabecera = crearEstiloCabecera(libro);
            XSSFCellStyle[] estiloTexto = {crearEstiloDatos(libro, null, false), crearEstiloDatos(libro, null, true)};
            XSSFCellStyle[] estiloNumero = {crearEstiloDatos(libro, "#,##0.00", false), crearEstiloDatos(libro, "#,##0.00", true)};

            Row cabecera = hoja.createRow(0);
            for (int c = 0; c < ENCABEZADOS.length; c++) {
                escribir(cabecera, c, ENCABEZADOS[c], estiloCabecera);
            }

            int f = 1;
            int z = 0;
            for (Object[] fila : filas) {
                Row row = hoja.createRow(f++);
                XSSFCellStyle texto = estiloTexto[z];
                XSSFCellStyle numero = estiloNumero[z];

                escribir(row, 0, aLong(fila[ORDEN]), numero);
                escribir(row, 1, aTexto(fila[FUENTE]), texto);
                escribir(row, 2, aLong(fila[INVOICE_ID]), numero);
                escribir(row, 3, aTexto(fila[PROVEEDOR]), texto);
                escribir(row, 4, aTexto(fila[TIPO_DOCUMENTO]), texto);
                escribir(row, 5, aTexto(fila[DOCUMENTO]), texto);
                escribir(row, 6, aFechaTexto(fila[FECHA_DOCUMENTO]), texto);
                escribir(row, 7, aTexto(fila[TERMINO_PAGO]), texto);
                String grupoPago = (String) fila[GRUPO_PAGO];
                escribir(row, 8, aTexto(grupoPago), texto);
                escribir(row, 9, aTexto(fila[CATEGORIA]), texto);
                escribir(row, 10, aTexto(fila[METODO_PAGO]), texto);
                escribir(row, 11, aFechaTexto(fila[FECHA_VENCIMIENTO]), texto);
                escribir(row, 12, aDouble(fila[IMPORTE_A_PAGAR]), numero);
                escribir(row, 13, aTexto(fila[DESCRIPCION]), texto);
                escribir(row, 14, aTexto(fila[PRIORIZADO]), texto);
                escribir(row, 15, gerenciaDe(grupoPago, gerenciaPorCodigo, descripcionPorCodigo), texto);

                z = 1 - z;
            }

            for (int c = 0; c < ENCABEZADOS.length; c++) {
                hoja.autoSizeColumn(c);
                hoja.setColumnWidth(c, Math.min(hoja.getColumnWidth(c) + 512, 40 * 256));
            }

            libro.write(salida);
        }
    }

    // Si el código tiene una etiqueta "agrupada" (ej. los "BCE *" -> "GERENCIA DE
    // EXPLORACIÓN Y PRODUCCIÓN") se usa esa; si no, la descripción normal del
    // catálogo GRUPO_PAGO; si tampoco existe ahí, el código crudo tal cual.
    private String gerenciaDe(String codigoGrupoPago, Map<String, String> gerenciaPorCodigo, Map<String, String> descripcionPorCodigo) {
        if (codigoGrupoPago == null) {
            return "-";
        }
        if (gerenciaPorCodigo.containsKey(codigoGrupoPago)) {
            return gerenciaPorCodigo.get(codigoGrupoPago);
        }
        return descripcionPorCodigo.getOrDefault(codigoGrupoPago, codigoGrupoPago);
    }

    private String aTexto(Object valor) {
        return valor != null ? valor.toString() : "-";
    }

    private String aFechaTexto(Object valor) {
        if (valor == null) {
            return "-";
        }
        try {
            return FORMATO_FECHA.format(LocalDate.parse(valor.toString()));
        } catch (Exception e) {
            return valor.toString();
        }
    }

    private double aLong(Object valor) {
        return valor == null ? 0 : ((Number) valor).longValue();
    }

    private double aDouble(Object valor) {
        if (valor == null) {
            return 0.0;
        }
        return valor instanceof BigDecimal ? ((BigDecimal) valor).doubleValue() : Double.parseDouble(valor.toString());
    }

    private void escribir(Row fila, int columna, String texto, XSSFCellStyle estilo) {
        Cell celda = fila.createCell(columna);
        celda.setCellValue(texto);
        celda.setCellStyle(estilo);
    }

    private void escribir(Row fila, int columna, double valor, XSSFCellStyle estilo) {
        Cell celda = fila.createCell(columna);
        celda.setCellValue(valor);
        celda.setCellStyle(estilo);
    }

    private XSSFCellStyle crearEstiloCabecera(XSSFWorkbook libro) {
        XSSFFont fuente = libro.createFont();
        fuente.setBold(true);
        fuente.setFontHeightInPoints((short) 10);
        fuente.setColor(new XSSFColor(new byte[]{(byte) 255, (byte) 255, (byte) 255}, null));

        XSSFCellStyle estilo = libro.createCellStyle();
        estilo.setFont(fuente);
        estilo.setFillForegroundColor(new XSSFColor(AZUL_MEDIO, null));
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setAlignment(HorizontalAlignment.CENTER);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        aplicarBordes(estilo);
        return estilo;
    }

    private XSSFCellStyle crearEstiloDatos(XSSFWorkbook libro, String formato, boolean alterna) {
        XSSFCellStyle estilo = libro.createCellStyle();
        if (formato != null) {
            estilo.setDataFormat(libro.createDataFormat().getFormat(formato));
            estilo.setAlignment(HorizontalAlignment.RIGHT);
        }
        if (alterna) {
            estilo.setFillForegroundColor(new XSSFColor(GRIS_FILA, null));
            estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        }
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        aplicarBordes(estilo);
        return estilo;
    }

    private void aplicarBordes(XSSFCellStyle estilo) {
        XSSFColor borde = new XSSFColor(GRIS_BORDE, null);
        estilo.setBorderTop(org.apache.poi.ss.usermodel.BorderStyle.THIN);
        estilo.setBorderBottom(org.apache.poi.ss.usermodel.BorderStyle.THIN);
        estilo.setBorderLeft(org.apache.poi.ss.usermodel.BorderStyle.THIN);
        estilo.setBorderRight(org.apache.poi.ss.usermodel.BorderStyle.THIN);
        estilo.setTopBorderColor(borde);
        estilo.setBottomBorderColor(borde);
        estilo.setLeftBorderColor(borde);
        estilo.setRightBorderColor(borde);
    }
}
