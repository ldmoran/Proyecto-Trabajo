package com.finanzas.gestionfinanzas.service;

import com.finanzas.gestionfinanzas.entity.Factura;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface FacturaService {
    Page<Factura> listarFacturas(Pageable pageable);
	List<Factura> buscarTodasPorRangoEmbarque(String ruc,
            String numFactura,
            String fecEmbarqueInicio,
            String fecEmbarqueFin,
            String fecDeposito,
            String fecFactura);

	List<Factura> buscarTodasPorRangoDeposito(String ruc,
            String numFactura,
            String fecDepositoInicio,
            String fecDepositoFin,
            String fecFactura);

	List<Factura> buscarPorNumFacturaORuc(String ruc, String numFactura);

}
