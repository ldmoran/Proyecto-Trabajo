package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.FlujoCajaEgresosRequest;
import com.finanzas.gestionfinanzas.dto.FlujoCajaIngresosRequest;
import com.finanzas.gestionfinanzas.dto.FlujoCajaReporteRequest;
import com.finanzas.gestionfinanzas.entity.*;
import com.finanzas.gestionfinanzas.repository.bdd.*;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FlujoCajaReporteService {

    private final FlujoCajaReporteRepository reporteRepository;
    private final FlujoCajaSaldoInicialRepository saldoInicialRepository;
    private final FlujoCajaIngresoRepository ingresoRepository;
    private final FlujoCajaPriorizadoRepository priorizadoRepository;
    private final FlujoCajaTransferenciaRepository transferenciaRepository;
    private final ConceptoTransferenciaRepository conceptoTransferenciaRepository;
    private final FlujoCajaConsorcioRepository consorcioRepository;
    private final ConceptoIngresoRepository conceptoIngresoRepository;
    private final CuentaBancariaRepository cuentaBancariaRepository;
    private final CategoriaEgresoRepository categoriaEgresoRepository;
    private final EnvioEbsCuentaRepository envioEbsCuentaRepository;
    private final AuditoriaSessionService auditoriaSessionService;
    private final FlujoCajaFirmaService flujoCajaFirmaService;
    private final FlujoCajaNotificacionService flujoCajaNotificacionService;
    private final FlujoCajaCxpPagableService flujoCajaCxpPagableService;
    private final ProvisionRegistroRepository provisionRegistroRepository;

    public FlujoCajaReporteService(FlujoCajaReporteRepository reporteRepository,
                                    FlujoCajaSaldoInicialRepository saldoInicialRepository,
                                    FlujoCajaIngresoRepository ingresoRepository,
                                    FlujoCajaPriorizadoRepository priorizadoRepository,
                                    FlujoCajaTransferenciaRepository transferenciaRepository,
                                    ConceptoTransferenciaRepository conceptoTransferenciaRepository,
                                    FlujoCajaConsorcioRepository consorcioRepository,
                                    ConceptoIngresoRepository conceptoIngresoRepository,
                                    CuentaBancariaRepository cuentaBancariaRepository,
                                    CategoriaEgresoRepository categoriaEgresoRepository,
                                    EnvioEbsCuentaRepository envioEbsCuentaRepository,
                                    AuditoriaSessionService auditoriaSessionService,
                                    FlujoCajaFirmaService flujoCajaFirmaService,
                                    FlujoCajaNotificacionService flujoCajaNotificacionService,
                                    FlujoCajaCxpPagableService flujoCajaCxpPagableService,
                                    ProvisionRegistroRepository provisionRegistroRepository) {
        this.reporteRepository = reporteRepository;
        this.saldoInicialRepository = saldoInicialRepository;
        this.ingresoRepository = ingresoRepository;
        this.priorizadoRepository = priorizadoRepository;
        this.transferenciaRepository = transferenciaRepository;
        this.conceptoTransferenciaRepository = conceptoTransferenciaRepository;
        this.consorcioRepository = consorcioRepository;
        this.conceptoIngresoRepository = conceptoIngresoRepository;
        this.cuentaBancariaRepository = cuentaBancariaRepository;
        this.categoriaEgresoRepository = categoriaEgresoRepository;
        this.envioEbsCuentaRepository = envioEbsCuentaRepository;
        this.auditoriaSessionService = auditoriaSessionService;
        this.flujoCajaFirmaService = flujoCajaFirmaService;
        this.flujoCajaNotificacionService = flujoCajaNotificacionService;
        this.flujoCajaCxpPagableService = flujoCajaCxpPagableService;
        this.provisionRegistroRepository = provisionRegistroRepository;
    }

    // Guarda cabecera + las 6 secciones de una sola vez. Estrategia:
    // "borrar todo el detalle anterior de este reporte y volver a insertar" —
    // más simple y segura que ir comparando fila por fila cuál cambió.
    @Transactional("secondTransactionManager")
    public FlujoCajaReporte guardarCompleto(FlujoCajaReporteRequest req) {
        auditoriaSessionService.activarUsuarioActual();
        String usuario = obtenerUsuarioActual();

        FlujoCajaReporte reporte = (req.getIdReporte() != null)
                ? reporteRepository.findById(req.getIdReporte()).orElseThrow(() -> new RuntimeException("Reporte no encontrado"))
                : new FlujoCajaReporte();

        verificarDatosNoBloqueados(reporte);

        boolean esNuevo = reporte.getIdReporte() == null;

        // FECHA_INICIO tiene un UNIQUE en la base (una sola semana, un solo
        // reporte): si ya hay otro reporte con esa fecha, se corta acá con un
        // mensaje claro en vez de dejar que reviente con el error crudo de
        // Oracle al guardar.
        final Long idReporteActual = reporte.getIdReporte();
        reporteRepository.findByFechaInicio(req.getFechaInicio())
                .filter(otro -> !otro.getIdReporte().equals(idReporteActual))
                .ifPresent(otro -> {
                    throw new RuntimeException("Ya existe un reporte para la semana que empieza el "
                            + req.getFechaInicio() + ". Abrilo desde Consultar en vez de crear uno nuevo.");
                });

        reporte.setFechaInicio(req.getFechaInicio());
        reporte.setFechaFin(req.getFechaFin());
        reporte.setFechaSaldoInicial(req.getFechaSaldoInicial());
        reporte.setObservacion1(req.getObservacion1());
        reporte.setObservacion2(req.getObservacion2());
        reporte.setObservacion3(req.getObservacion3());
        // Elaborado/Aprobado/Autorizado ya NO se tocan desde Guardar: son firmas que
        // se estampan una por una con marcarElaborado/marcarAprobado/marcarAutorizado.

        if (esNuevo) {
            reporte.setEstado("B"); // Borrador
            reporte.setEstadoProceso("CREADO");
            reporte.setIdUsuarioCreacion(usuario);
            reporte.setFechaCreacion(LocalDateTime.now());
        }

        reporte = reporteRepository.save(reporte);
        Long idReporte = reporte.getIdReporte();

        // ---- Saldo inicial ----
        saldoInicialRepository.deleteAll(saldoInicialRepository.findByReporte_IdReporte(idReporte));
        if (req.getSaldosIniciales() != null) {
            for (FlujoCajaReporteRequest.SaldoInicialItem item : req.getSaldosIniciales()) {
                CuentaBancaria cuenta = cuentaBancariaRepository.findById(item.getIdCuentaBancaria())
                        .orElseThrow(() -> new RuntimeException("Cuenta bancaria no encontrada"));
                FlujoCajaSaldoInicial fila = new FlujoCajaSaldoInicial();
                fila.setReporte(reporte);
                fila.setCuentaBancaria(cuenta);
                fila.setValor(item.getValor());
                fila.setTipoCaptura(item.getTipoCaptura() != null ? item.getTipoCaptura() : "MANUAL");
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                saldoInicialRepository.save(fila);
            }
        }

        // ---- Ingresos (manuales; los automáticos se recalculan aparte) ----
        ingresoRepository.deleteAll(ingresoRepository.findByReporte_IdReporte(idReporte));
        if (req.getIngresos() != null) {
            for (FlujoCajaReporteRequest.IngresoItem item : req.getIngresos()) {
                ConceptoIngreso concepto = conceptoIngresoRepository.findById(item.getIdConcepto())
                        .orElseThrow(() -> new RuntimeException("Concepto de ingreso no encontrado"));
                // Los automáticos no se toman del formulario: se calculan en recalcularIngresosAutomaticos
                if (concepto.isAutomatico()) {
                    continue;
                }
                FlujoCajaIngreso fila = new FlujoCajaIngreso();
                fila.setReporte(reporte);
                fila.setConcepto(concepto);
                fila.setValor(item.getValor());
                fila.setTipoCaptura("MANUAL");
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                ingresoRepository.save(fila);
            }
        }
        recalcularIngresosAutomaticos(reporte);

        // ---- Priorizados (secciones 3, 4, 5) ----
        priorizadoRepository.deleteAll(priorizadoRepository.findByReporte_IdReporte(idReporte));
        if (req.getPriorizados() != null) {
            for (FlujoCajaReporteRequest.PriorizadoItem item : req.getPriorizados()) {
                CategoriaEgreso categoria = categoriaEgresoRepository.findById(item.getIdCategoriaEgreso())
                        .orElseThrow(() -> new RuntimeException("Categoría de egreso no encontrada"));
                FlujoCajaPriorizado fila = new FlujoCajaPriorizado();
                fila.setReporte(reporte);
                fila.setSeccion(item.getSeccion());
                fila.setCategoriaEgreso(categoria);
                fila.setValor(item.getValor());
                fila.setNroProcesos(item.getNroProcesos());
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                priorizadoRepository.save(fila);
            }
        }

        // ---- Transferencias (secciones 6, 7, 8) ----
        transferenciaRepository.deleteAll(transferenciaRepository.findByReporte_IdReporte(idReporte));
        if (req.getTransferencias() != null) {
            for (FlujoCajaReporteRequest.TransferenciaItem item : req.getTransferencias()) {
                ConceptoTransferencia concepto = conceptoTransferenciaRepository.findById(item.getIdConcepto())
                        .orElseThrow(() -> new RuntimeException("Concepto de transferencia no encontrado"));
                FlujoCajaTransferencia fila = new FlujoCajaTransferencia();
                fila.setReporte(reporte);
                fila.setConcepto(concepto);
                fila.setValor(item.getValor());
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                transferenciaRepository.save(fila);
            }
        }

        // ---- Consorcios ----
        consorcioRepository.deleteAll(consorcioRepository.findByReporte_IdReporte(idReporte));
        if (req.getConsorcios() != null) {
            for (FlujoCajaReporteRequest.ConsorcioItem item : req.getConsorcios()) {
                FlujoCajaConsorcio fila = new FlujoCajaConsorcio();
                fila.setReporte(reporte);
                fila.setNombreConsorcio(item.getNombreConsorcio());
                fila.setDescripcion(item.getDescripcion());
                fila.setSaldoEstimado(item.getSaldoEstimado());
                fila.setFechaEstimado(item.getFechaEstimado());
                fila.setDetalleFacturas(item.getDetalleFacturas());
                fila.setTotalFacturas(item.getTotalFacturas());
                fila.setFondeoBce(item.getFondeoBce());
                fila.setFechaSaldoFinal(item.getFechaSaldoFinal());
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                consorcioRepository.save(fila);
            }
        }

        recalcularTotales(reporte);

        auditoriaSessionService.registrarComentario("FC_REPORTE", reporte.getIdReporte(),
                esNuevo ? "INSERT" : "UPDATE",
                "Guardó el reporte de Flujo de Caja de la semana del " + reporte.getFechaInicio()
                        + " al " + reporte.getFechaFin());

        return reporte;
    }

    // Guarda SOLO Saldo Inicial + Ingresos (pantalla "Flujo de Caja > Ingresos").
    // Mismo patrón "borrar todo el detalle anterior + volver a insertar" que
    // guardarCompleto, pero acotado a esas 2 secciones — NO toca Priorizados,
    // Transferencias ni Consorcios (esos son de guardarEgresos). Es la pantalla
    // que CREA el reporte si todavía no existe para esa semana.
    @Transactional("secondTransactionManager")
    public FlujoCajaReporte guardarIngresos(FlujoCajaIngresosRequest req) {
        auditoriaSessionService.activarUsuarioActual();
        String usuario = obtenerUsuarioActual();

        FlujoCajaReporte reporte = (req.getIdReporte() != null)
                ? reporteRepository.findById(req.getIdReporte()).orElseThrow(() -> new RuntimeException("Reporte no encontrado"))
                : new FlujoCajaReporte();

        verificarDatosNoBloqueados(reporte);

        boolean esNuevo = reporte.getIdReporte() == null;

        final Long idReporteActual = reporte.getIdReporte();
        reporteRepository.findByFechaInicio(req.getFechaInicio())
                .filter(otro -> !otro.getIdReporte().equals(idReporteActual))
                .ifPresent(otro -> {
                    throw new RuntimeException("Ya existe un reporte para la semana que empieza el "
                            + req.getFechaInicio() + ". Abrilo desde Consultar en vez de crear uno nuevo.");
                });

        reporte.setFechaInicio(req.getFechaInicio());
        reporte.setFechaFin(req.getFechaFin());
        reporte.setFechaSaldoInicial(req.getFechaSaldoInicial());

        if (esNuevo) {
            reporte.setEstado("B"); // Borrador
            reporte.setEstadoProceso("CREADO");
            reporte.setIdUsuarioCreacion(usuario);
            reporte.setFechaCreacion(LocalDateTime.now());
        }

        reporte = reporteRepository.save(reporte);
        Long idReporte = reporte.getIdReporte();

        saldoInicialRepository.deleteAll(saldoInicialRepository.findByReporte_IdReporte(idReporte));
        if (req.getSaldosIniciales() != null) {
            for (FlujoCajaReporteRequest.SaldoInicialItem item : req.getSaldosIniciales()) {
                CuentaBancaria cuenta = cuentaBancariaRepository.findById(item.getIdCuentaBancaria())
                        .orElseThrow(() -> new RuntimeException("Cuenta bancaria no encontrada"));
                FlujoCajaSaldoInicial fila = new FlujoCajaSaldoInicial();
                fila.setReporte(reporte);
                fila.setCuentaBancaria(cuenta);
                fila.setValor(item.getValor());
                fila.setTipoCaptura(item.getTipoCaptura() != null ? item.getTipoCaptura() : "MANUAL");
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                saldoInicialRepository.save(fila);
            }
        }

        ingresoRepository.deleteAll(ingresoRepository.findByReporte_IdReporte(idReporte));
        if (req.getIngresos() != null) {
            for (FlujoCajaReporteRequest.IngresoItem item : req.getIngresos()) {
                ConceptoIngreso concepto = conceptoIngresoRepository.findById(item.getIdConcepto())
                        .orElseThrow(() -> new RuntimeException("Concepto de ingreso no encontrado"));
                if (concepto.isAutomatico()) {
                    continue;
                }
                FlujoCajaIngreso fila = new FlujoCajaIngreso();
                fila.setReporte(reporte);
                fila.setConcepto(concepto);
                fila.setValor(item.getValor());
                fila.setTipoCaptura("MANUAL");
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                ingresoRepository.save(fila);
            }
        }
        recalcularIngresosAutomaticos(reporte);

        recalcularTotales(reporte);

        auditoriaSessionService.registrarComentario("FC_REPORTE", reporte.getIdReporte(),
                esNuevo ? "INSERT" : "UPDATE",
                "Guardó Ingresos del reporte de Flujo de Caja de la semana del " + reporte.getFechaInicio()
                        + " al " + reporte.getFechaFin());

        return reporte;
    }

    // Guarda SOLO Priorizados/Transferencias/Consorcios/Observaciones (pantalla
    // "Flujo de Caja > Egresos"). El reporte YA tiene que existir — lo crea
    // guardarIngresos, no esta pantalla.
    @Transactional("secondTransactionManager")
    public FlujoCajaReporte guardarEgresos(FlujoCajaEgresosRequest req) {
        auditoriaSessionService.activarUsuarioActual();
        String usuario = obtenerUsuarioActual();

        if (req.getIdReporte() == null) {
            throw new RuntimeException("Primero hay que guardar los Ingresos de esta semana.");
        }
        FlujoCajaReporte reporte = reporteRepository.findById(req.getIdReporte())
                .orElseThrow(() -> new RuntimeException("Reporte no encontrado"));

        verificarDatosNoBloqueados(reporte);

        reporte.setObservacion1(req.getObservacion1());
        reporte.setObservacion2(req.getObservacion2());
        reporte.setObservacion3(req.getObservacion3());
        reporte = reporteRepository.save(reporte);
        Long idReporte = reporte.getIdReporte();

        priorizadoRepository.deleteAll(priorizadoRepository.findByReporte_IdReporte(idReporte));
        if (req.getPriorizados() != null) {
            for (FlujoCajaReporteRequest.PriorizadoItem item : req.getPriorizados()) {
                CategoriaEgreso categoria = categoriaEgresoRepository.findById(item.getIdCategoriaEgreso())
                        .orElseThrow(() -> new RuntimeException("Categoría de egreso no encontrada"));
                FlujoCajaPriorizado fila = new FlujoCajaPriorizado();
                fila.setReporte(reporte);
                fila.setSeccion(item.getSeccion());
                fila.setCategoriaEgreso(categoria);
                fila.setValor(item.getValor());
                fila.setNroProcesos(item.getNroProcesos());
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                priorizadoRepository.save(fila);
            }
        }

        transferenciaRepository.deleteAll(transferenciaRepository.findByReporte_IdReporte(idReporte));
        if (req.getTransferencias() != null) {
            for (FlujoCajaReporteRequest.TransferenciaItem item : req.getTransferencias()) {
                ConceptoTransferencia concepto = conceptoTransferenciaRepository.findById(item.getIdConcepto())
                        .orElseThrow(() -> new RuntimeException("Concepto de transferencia no encontrado"));
                FlujoCajaTransferencia fila = new FlujoCajaTransferencia();
                fila.setReporte(reporte);
                fila.setConcepto(concepto);
                fila.setValor(item.getValor());
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                transferenciaRepository.save(fila);
            }
        }

        consorcioRepository.deleteAll(consorcioRepository.findByReporte_IdReporte(idReporte));
        if (req.getConsorcios() != null) {
            for (FlujoCajaReporteRequest.ConsorcioItem item : req.getConsorcios()) {
                FlujoCajaConsorcio fila = new FlujoCajaConsorcio();
                fila.setReporte(reporte);
                fila.setNombreConsorcio(item.getNombreConsorcio());
                fila.setDescripcion(item.getDescripcion());
                fila.setSaldoEstimado(item.getSaldoEstimado());
                fila.setFechaEstimado(item.getFechaEstimado());
                fila.setDetalleFacturas(item.getDetalleFacturas());
                fila.setTotalFacturas(item.getTotalFacturas());
                fila.setFondeoBce(item.getFondeoBce());
                fila.setFechaSaldoFinal(item.getFechaSaldoFinal());
                fila.setIdUsuarioCreacion(usuario);
                fila.setFechaCreacion(LocalDateTime.now());
                consorcioRepository.save(fila);
            }
        }

        recalcularTotales(reporte);

        auditoriaSessionService.registrarComentario("FC_REPORTE", reporte.getIdReporte(), "UPDATE",
                "Guardó Egresos del reporte de Flujo de Caja de la semana del " + reporte.getFechaInicio()
                        + " al " + reporte.getFechaFin());

        return reporte;
    }

    // Recalcula las líneas "Automático": por cada ConceptoIngreso con cuenta
    // asignada, toma lo que salió en el envío a EBS de esa semana.
    @Transactional("secondTransactionManager")
    public void recalcularIngresosAutomaticos(FlujoCajaReporte reporte) {
        List<ConceptoIngreso> conceptosAutomaticos = conceptoIngresoRepository.findByEstadoOrderByNombreConcepto("A")
                .stream()
                .filter(ConceptoIngreso::isAutomatico)
                .collect(Collectors.toList());

        for (ConceptoIngreso concepto : conceptosAutomaticos) {
            BigDecimal valor = calcularValorAutomatico(concepto, reporte.getFechaInicio());

            FlujoCajaIngreso ingreso = ingresoRepository.findByReporte_IdReporte(reporte.getIdReporte())
                    .stream()
                    .filter(i -> i.getConcepto().getIdConcepto().equals(concepto.getIdConcepto()))
                    .findFirst()
                    .orElseGet(FlujoCajaIngreso::new);

            ingreso.setReporte(reporte);
            ingreso.setConcepto(concepto);
            ingreso.setValor(valor);
            ingreso.setTipoCaptura("AUTOMATICO");
            if (ingreso.getIdFlujoIngreso() == null) {
                ingreso.setIdUsuarioCreacion(obtenerUsuarioActual());
                ingreso.setFechaCreacion(LocalDateTime.now());
            }

            ingresoRepository.save(ingreso);
        }
    }

    // Lo que cuenta como "ingreso recuperado" de la semana es lo que efectivamente
    // se mandó a Flujo (pantalla Ingresos > Enviar a Flujo) ATRIBUIDO a esa semana
    // (ENVIO_EBS.FECHA_PERIODO, elegido a mano al enviar — ver EnvioEbsService.
    // guardarEnvio), no todo lo que haya en el rango de fecha de embarque. Suma
    // TODOS los envíos de ese período (puede haber más de uno si se mandó en
    // varias tandas antes de firmar), no solo el más reciente. Si no hubo envío
    // todavía para esa semana, el valor es 0. Público porque el controller la usa
    // también para mostrar el valor en vivo al abrir la pantalla, sin guardar primero.
    public BigDecimal calcularValorAutomatico(ConceptoIngreso concepto, LocalDate fechaInicio) {
        if (concepto.getCuenta() == null) {
            return BigDecimal.ZERO;
        }

        Double suma = envioEbsCuentaRepository.sumarSubtotalPorPeriodoYCuenta(fechaInicio, concepto.getCuenta().getIdCuenta());
        // Dinero: 2 decimales, no el arrastre de coma flotante del SUM.
        return BigDecimal.valueOf(suma != null ? suma : 0.0).setScale(2, RoundingMode.HALF_UP);
    }

    // Suma todo y actualiza SALDO_INICIAL_TOTAL, INGRESOS_TOTAL, EGRESOS_TOTAL,
    // SALDO_FINAL en la cabecera. INGRESOS_TOTAL = 1+2 (Saldo Inicial + Ingresos
    // por Recibir): representa todo el dinero disponible, y es lo que se usa
    // como monto disponible para Cuentas por Pagar (ver
    // FlujoCajaCxpPagableService, llamado desde marcarAutorizado con
    // getIngresosTotal()). EGRESOS_TOTAL = 3+4+5+6, según el rótulo "TOTAL
    // EGRESOS (3+4+5+6)" del Excel — Shaya BOC2 (7) y Hedge (8) quedan fuera del
    // total, son informativos aparte. Como INGRESOS_TOTAL ya incluye el Saldo
    // Inicial, SALDO_FINAL no lo vuelve a sumar (sería contarlo dos veces).
    @Transactional("secondTransactionManager")
    public void recalcularTotales(FlujoCajaReporte reporte) {
        Long idReporte = reporte.getIdReporte();

        BigDecimal saldoInicialTotal = saldoInicialRepository.findByReporte_IdReporte(idReporte).stream()
                .map(FlujoCajaSaldoInicial::getValor)
                .filter(v -> v != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal ingresosSeccion2 = ingresoRepository.findByReporte_IdReporte(idReporte).stream()
                .map(FlujoCajaIngreso::getValor)
                .filter(v -> v != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal ingresosTotal = saldoInicialTotal.add(ingresosSeccion2);

        BigDecimal priorizadosTotal = priorizadoRepository.findByReporte_IdReporte(idReporte).stream()
                .map(FlujoCajaPriorizado::getValor)
                .filter(v -> v != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal sriTotal = transferenciaRepository.findByReporte_IdReporte(idReporte).stream()
                .filter(t -> ConceptoTransferencia.TIPO_SRI.equals(t.getTipo()))
                .map(FlujoCajaTransferencia::getValor)
                .filter(v -> v != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Provisiones de esta semana (ver PROVISION_REGISTRO / ProvisionRegistroService):
        // el egreso real es VALOR_NUEVO — la reserva que se hace ESA semana (ya sea
        // de un lote Nuevo, o de los "nuevos" que trae un Mixto junto con sus
        // cierres). Esa reserva es la que después financia las facturas que se
        // pagan en semanas siguientes (VALOR_FACTURAS de un Pendiente/Mixto
        // posterior) — por eso VALOR_FACTURAS NO se vuelve a sumar acá: ya se
        // contó como egreso cuando se apartó como Nuevo, sumarlo de nuevo al
        // pagarse duplicaría la misma plata. VALOR_FACTURAS/VALOR_PENDIENTE quedan
        // solo informativos en pantalla (a qué facturas se aplicó la reserva).
        // Se busca por ID_REPORTE (relación real, ver ProvisionRegistro.reporte),
        // no por fecha — evita depender de que las fechas coincidan carácter a
        // carácter entre las dos tablas.
        BigDecimal provisionesTotal = provisionRegistroRepository
                .findByReporte_IdReporteOrderByFechaCreacionDesc(idReporte).stream()
                .map(ProvisionRegistro::getValorNuevo)
                .filter(v -> v != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal egresosTotal = priorizadosTotal.add(sriTotal).add(provisionesTotal);

        BigDecimal saldoFinal = ingresosTotal.subtract(egresosTotal);

        reporte.setSaldoInicialTotal(saldoInicialTotal);
        reporte.setIngresosTotal(ingresosTotal);
        reporte.setEgresosTotal(egresosTotal);
        reporte.setSaldoFinal(saldoFinal);

        reporteRepository.save(reporte);
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }

    private void verificarNoAutorizado(FlujoCajaReporte reporte) {
        if ("A".equals(reporte.getEstado())) {
            throw new RuntimeException("Este reporte ya está Autorizado y no se puede modificar.");
        }
    }

    // Igual que verificarNoAutorizado, pero además corta desde que se firmó
    // "Elaborado" (ya hay o va a haber un PDF firmado que no se regenera) O
    // desde que el proceso quedó APROBADO (paso previo liviano, ver
    // revisarProceso/aprobarProceso) — una vez aprobado, los datos no se
    // tocan más, sin importar si el guardado viene de guardarCompleto
    // (pantalla vieja combinada), guardarIngresos o guardarEgresos.
    // Público (no solo de uso interno) para que otros módulos que comparten
    // semana con Flujo de Caja, como Provisiones (ver
    // ProvisionRegistroService), puedan aplicar el mismo candado antes de
    // guardar — sin esto, se podría seguir guardando Provisiones de una
    // semana ya Elaborada/Aprobada/Autorizada aunque Ingresos/Egresos ya no
    // dejen tocar nada.
    public void verificarDatosNoBloqueados(FlujoCajaReporte reporte) {
        verificarNoAutorizado(reporte);
        if (reporte.getElaboradoPor() != null && !reporte.getElaboradoPor().trim().isEmpty()) {
            throw new RuntimeException("Este reporte ya está Elaborado y sus datos no se pueden modificar.");
        }
        if ("APROBADO".equals(reporte.getEstadoProceso())) {
            throw new RuntimeException("Este reporte ya está Aprobado y sus datos no se pueden modificar.");
        }
    }

    // ---- Estado de proceso: paso liviano (sin certificado .p12, solo un
    // clic) que va ANTES de las 3 firmas reales, a nivel de TODO el reporte
    // (no por sección). CREADO -> REVISADO -> APROBADO. Solo cuando queda
    // APROBADO tiene sentido mostrar el bloque de firmas reales
    // (Elaborado/Aprobado/Autorizado) en pantalla. ----

    @Transactional("secondTransactionManager")
    public FlujoCajaReporte revisarProceso(Long idReporte) {
        auditoriaSessionService.activarUsuarioActual();
        FlujoCajaReporte reporte = obtenerReporteOMorir(idReporte);
        verificarNoAutorizado(reporte);
        if (!"CREADO".equals(reporte.getEstadoProceso())) {
            throw new RuntimeException("Este reporte ya fue marcado como Revisado.");
        }
        reporte.setEstadoProceso("REVISADO");
        reporte.setProcesoRevisadoPor(obtenerUsuarioActual());
        reporte.setProcesoFechaRevision(LocalDateTime.now());
        FlujoCajaReporte guardado = reporteRepository.save(reporte);
        flujoCajaNotificacionService.avisarRevision(guardado);
        return guardado;
    }

    @Transactional("secondTransactionManager")
    public FlujoCajaReporte aprobarProceso(Long idReporte) {
        auditoriaSessionService.activarUsuarioActual();
        FlujoCajaReporte reporte = obtenerReporteOMorir(idReporte);
        verificarNoAutorizado(reporte);
        if (!"REVISADO".equals(reporte.getEstadoProceso())) {
            throw new RuntimeException("Primero hay que marcar el reporte como Revisado.");
        }
        reporte.setEstadoProceso("APROBADO");
        reporte.setProcesoAprobadoPor(obtenerUsuarioActual());
        reporte.setProcesoFechaAprobacion(LocalDateTime.now());
        FlujoCajaReporte guardado = reporteRepository.save(reporte);
        // Recién acá (proceso Aprobado) tiene sentido avisarle al Elaborador
        // que puede firmar Elaborado de verdad.
        flujoCajaNotificacionService.avisarElaboradores(guardado);
        return guardado;
    }

    // Las 3 firmas son secuenciales: no se puede Aprobar sin Elaborado, ni
    // Autorizar sin Aprobado. Autorizar es la que finalmente bloquea TODO el
    // reporte (ESTADO pasa a 'A', ver verificarNoAutorizado); Elaborado ya
    // bloquea los DATOS (ver verificarDatosNoBloqueados) porque a partir de esa
    // firma existe un PDF firmado que no se vuelve a regenerar. Aprobado no
    // agrega ningún bloqueo propio. Cada etapa exige firma electrónica real con
    // .p12 (ver FlujoCajaFirmaService): el nombre que queda guardado sale del
    // certificado, no de la sesión.
    @Transactional("secondTransactionManager")
    public FlujoCajaReporte marcarElaborado(Long idReporte, InputStream p12Stream, char[] password, Integer x, Integer y) {
        auditoriaSessionService.activarUsuarioActual();
        FlujoCajaReporte reporte = obtenerReporteOMorir(idReporte);
        verificarNoAutorizado(reporte);
        // Candado real (no solo de UI): la firma real de Elaborado no se puede dar
        // hasta que el proceso esté APROBADO (paso previo liviano, ver
        // aprobarProceso) — aplica sin importar desde qué pantalla se intente
        // (Ver/Firmar, la pantalla combinada vieja, o directo a la API).
        if (!"APROBADO".equals(reporte.getEstadoProceso())) {
            throw new RuntimeException("Primero hay que marcar el reporte como Aprobado antes de firmar Elaborado.");
        }
        if (reporte.getElaboradoPor() != null && !reporte.getElaboradoPor().trim().isEmpty()) {
            throw new RuntimeException("Este reporte ya está marcado como Elaborado.");
        }
        String nombreFirmante = flujoCajaFirmaService.firmarEtapa(reporte, "ELABORADO", p12Stream, password, x, y);
        reporte.setElaboradoPor(nombreFirmante);
        FlujoCajaReporte guardado = reporteRepository.save(reporte);
        flujoCajaNotificacionService.avisarAprobadores(guardado);
        return guardado;
    }

    @Transactional("secondTransactionManager")
    public FlujoCajaReporte marcarAprobado(Long idReporte, InputStream p12Stream, char[] password, Integer x, Integer y) {
        auditoriaSessionService.activarUsuarioActual();
        FlujoCajaReporte reporte = obtenerReporteOMorir(idReporte);
        verificarNoAutorizado(reporte);
        if (reporte.getElaboradoPor() == null || reporte.getElaboradoPor().trim().isEmpty()) {
            throw new RuntimeException("Primero hay que marcar el reporte como Elaborado.");
        }
        if (reporte.getAprobadoPor() != null && !reporte.getAprobadoPor().trim().isEmpty()) {
            throw new RuntimeException("Este reporte ya está Aprobado.");
        }
        String nombreFirmante = flujoCajaFirmaService.firmarEtapa(reporte, "APROBADO", p12Stream, password, x, y);
        reporte.setAprobadoPor(nombreFirmante);
        FlujoCajaReporte guardado = reporteRepository.save(reporte);
        flujoCajaNotificacionService.avisarAutorizadores(guardado);
        return guardado;
    }

    @Transactional("secondTransactionManager")
    public FlujoCajaReporte marcarAutorizado(Long idReporte, InputStream p12Stream, char[] password, Integer x, Integer y) {
        auditoriaSessionService.activarUsuarioActual();
        FlujoCajaReporte reporte = obtenerReporteOMorir(idReporte);
        verificarNoAutorizado(reporte);
        if (reporte.getAprobadoPor() == null || reporte.getAprobadoPor().trim().isEmpty()) {
            throw new RuntimeException("Primero hay que Aprobar el reporte.");
        }
        String nombreFirmante = flujoCajaFirmaService.firmarEtapa(reporte, "AUTORIZADO", p12Stream, password, x, y);

        // Recién acá el reporte tiene las 3 firmas (Elaborado, Aprobado y esta,
        // Autorizado) — antes de guardar nada localmente se calculan las facturas
        // cubiertas definitivas y se mandan al ERP (PAM/PEC, ver
        // FlujoCajaCxpPagableService.enviarAsignacionPam/enviarAsignacionPec). Si
        // cualquiera de las dos falla, se corta acá: ni el reporte queda marcado
        // como Autorizado ni se compromete nada localmente, para poder reintentar
        // sin dejar el reporte a medio autorizar.
        List<Object[]> cubiertas = flujoCajaCxpPagableService.calcularCubiertasParaAutorizar(idReporte, reporte.getIngresosTotal());
        // PAM y PEC van en instancias Oracle distintas — dos llamadas separadas,
        // cada una en su propia transacción (ver FlujoCajaCxpPagableService).
        flujoCajaCxpPagableService.enviarAsignacionPam(cubiertas, reporte.getFechaInicio(), reporte.getFechaFin());
        flujoCajaCxpPagableService.enviarAsignacionPec(cubiertas, reporte.getFechaInicio(), reporte.getFechaFin());

        reporte.setAutorizadoPor(nombreFirmante);
        reporte.setEstado("A");
        FlujoCajaReporte guardado = reporteRepository.save(reporte);

        // Con el reporte ya cerrado del todo, se comprometen para siempre (acá,
        // localmente) las mismas facturas que se acaban de mandar al ERP arriba —
        // para que ninguna semana futura vuelva a ofrecerlas. Va en la misma
        // transacción que el guardado de arriba: si esto falla, Autorizar también
        // se revierte.
        flujoCajaCxpPagableService.confirmarAsignacion(guardado.getIdReporte(), cubiertas);

        return guardado;
    }

    private FlujoCajaReporte obtenerReporteOMorir(Long idReporte) {
        return reporteRepository.findById(idReporte)
                .orElseThrow(() -> new RuntimeException("Reporte no encontrado"));
    }
}