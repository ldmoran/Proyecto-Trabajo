package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.EnvioEbsCuenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface EnvioEbsCuentaRepository extends JpaRepository<EnvioEbsCuenta, Long> {

    @Query("SELECT ec FROM EnvioEbsCuenta ec LEFT JOIN FETCH ec.cuenta WHERE ec.envioEbs.idEnvioEbs = :idEnvioEbs")
    List<EnvioEbsCuenta> findByEnvioEbs_IdEnvioEbs(@Param("idEnvioEbs") Long idEnvioEbs);

    @Query("SELECT COALESCE(SUM(ec.subtotal), 0) FROM EnvioEbsCuenta ec " +
            "WHERE ec.envioEbs.idEnvioEbs = :idEnvioEbs AND ec.cuenta.idCuenta = :idCuenta")
    Double sumarSubtotalPorEnvioYCuenta(@Param("idEnvioEbs") Long idEnvioEbs, @Param("idCuenta") Long idCuenta);

    // Suma TODOS los envíos atribuidos a un período (puede haber más de uno, ver
    // EnvioEbsService.guardarEnvio), no solo el más reciente — usado por
    // FlujoCajaReporteService.calcularValorAutomatico.
    @Query("SELECT COALESCE(SUM(ec.subtotal), 0) FROM EnvioEbsCuenta ec " +
            "WHERE ec.envioEbs.fechaPeriodo = :fechaPeriodo AND ec.cuenta.idCuenta = :idCuenta")
    Double sumarSubtotalPorPeriodoYCuenta(@Param("fechaPeriodo") LocalDate fechaPeriodo, @Param("idCuenta") Long idCuenta);
}
