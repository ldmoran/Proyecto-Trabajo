package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

// Un registro por cada ciclo de Provisiones (concepto + período + tipo
// NUEVO/ANTERIOR/MIXTO). Ver el comentario de la tabla en reset_bd.sql para
// el detalle de qué significa cada TIPO y cómo se calcula VALOR_PENDIENTE.
@Entity
@Table(name = "PROVISION_REGISTRO")
public class ProvisionRegistro {

    public static final String TIPO_NUEVO = "NUEVO";
    public static final String TIPO_ANTERIOR = "ANTERIOR";
    public static final String TIPO_MIXTO = "MIXTO";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_REGISTRO")
    private Long idRegistro;

    @ManyToOne
    @JoinColumn(name = "ID_CONCEPTO")
    private ProvisionConcepto concepto;

    @ManyToOne
    @JoinColumn(name = "ID_LOTE")
    private ProvisionLote lote;

    // Reporte de Flujo de Caja de la semana a la que pertenece este registro —
    // relación real por ID (mismo patrón que FC_EGR_TRANSFERENCIA/FC_EGR_PRIORIZADO/
    // FC_EGR_CONSORCIO), en vez de matchear FECHA_INICIO_PERIODO contra
    // FC_REPORTE.FECHA_INICIO a mano cada vez.
    @ManyToOne
    @JoinColumn(name = "ID_REPORTE")
    private FlujoCajaReporte reporte;

    @Column(name = "FECHA_INICIO_PERIODO")
    private LocalDate fechaInicioPeriodo;

    @Column(name = "FECHA_FIN_PERIODO")
    private LocalDate fechaFinPeriodo;

    @Column(name = "TIPO")
    private String tipo;

    @Column(name = "VALOR_NUEVO")
    private BigDecimal valorNuevo;

    @Column(name = "VALOR_FACTURAS")
    private BigDecimal valorFacturas;

    @Column(name = "VALOR_PENDIENTE")
    private BigDecimal valorPendiente;

    @ManyToOne
    @JoinColumn(name = "ID_REGISTRO_ORIGEN")
    private ProvisionRegistro registroOrigen;

    @Column(name = "ESTADO")
    private String estado;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdRegistro() { return idRegistro; }
    public void setIdRegistro(Long idRegistro) { this.idRegistro = idRegistro; }

    public ProvisionConcepto getConcepto() { return concepto; }
    public void setConcepto(ProvisionConcepto concepto) { this.concepto = concepto; }

    public ProvisionLote getLote() { return lote; }
    public void setLote(ProvisionLote lote) { this.lote = lote; }

    public FlujoCajaReporte getReporte() { return reporte; }
    public void setReporte(FlujoCajaReporte reporte) { this.reporte = reporte; }

    public LocalDate getFechaInicioPeriodo() { return fechaInicioPeriodo; }
    public void setFechaInicioPeriodo(LocalDate fechaInicioPeriodo) { this.fechaInicioPeriodo = fechaInicioPeriodo; }

    public LocalDate getFechaFinPeriodo() { return fechaFinPeriodo; }
    public void setFechaFinPeriodo(LocalDate fechaFinPeriodo) { this.fechaFinPeriodo = fechaFinPeriodo; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public BigDecimal getValorNuevo() { return valorNuevo; }
    public void setValorNuevo(BigDecimal valorNuevo) { this.valorNuevo = valorNuevo; }

    public BigDecimal getValorFacturas() { return valorFacturas; }
    public void setValorFacturas(BigDecimal valorFacturas) { this.valorFacturas = valorFacturas; }

    public BigDecimal getValorPendiente() { return valorPendiente; }
    public void setValorPendiente(BigDecimal valorPendiente) { this.valorPendiente = valorPendiente; }

    public ProvisionRegistro getRegistroOrigen() { return registroOrigen; }
    public void setRegistroOrigen(ProvisionRegistro registroOrigen) { this.registroOrigen = registroOrigen; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getIdUsuarioCreacion() { return idUsuarioCreacion; }
    public void setIdUsuarioCreacion(String idUsuarioCreacion) { this.idUsuarioCreacion = idUsuarioCreacion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}
