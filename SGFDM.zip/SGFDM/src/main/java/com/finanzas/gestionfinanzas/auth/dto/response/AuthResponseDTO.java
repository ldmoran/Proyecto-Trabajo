package com.finanzas.gestionfinanzas.auth.dto.response;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.util.List;
import java.util.Objects;

public class AuthResponseDTO {

    private String id;
    private String usuario;
    private String cedula;
    private String nombre;
    private String email;

    private String token;

    private List<AplicacionDTO> listaAplicacion;

    @JsonAlias({"usuarioLDAP", "usuarioLdap", "usuarioldap"})
    private UsuarioLdapDTO usuarioLdap;
    private RespuestaDTO respuesta;

    public AuthResponseDTO() {
    }

    public AuthResponseDTO(String id, String usuario, String cedula, String nombre, String email,
                           String token, List<AplicacionDTO> listaAplicacion,
                           UsuarioLdapDTO usuarioLdap, RespuestaDTO respuesta) {
        this.id = id;
        this.usuario = usuario;
        this.cedula = cedula;
        this.nombre = nombre;
        this.email = email;
        this.token = token;
        this.listaAplicacion = listaAplicacion;
        this.usuarioLdap = usuarioLdap;
        this.respuesta = respuesta;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public List<AplicacionDTO> getListaAplicacion() {
        return listaAplicacion;
    }

    public void setListaAplicacion(List<AplicacionDTO> listaAplicacion) {
        this.listaAplicacion = listaAplicacion;
    }

    public UsuarioLdapDTO getUsuarioLdap() {
        return usuarioLdap;
    }

    public void setUsuarioLdap(UsuarioLdapDTO usuarioLdap) {
        this.usuarioLdap = usuarioLdap;
    }

    public RespuestaDTO getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(RespuestaDTO respuesta) {
        this.respuesta = respuesta;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        AuthResponseDTO that = (AuthResponseDTO) o;
        return Objects.equals(id, that.id) &&
               Objects.equals(usuario, that.usuario) &&
               Objects.equals(cedula, that.cedula);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, usuario, cedula);
    }
}
