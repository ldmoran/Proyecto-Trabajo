package com.finanzas.gestionfinanzas.auth.security;

import com.finanzas.gestionfinanzas.auth.enums.MenuEnum;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.session.HttpSessionEventPublisher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final CustomAuthenticationProvider authProvider;
  //  private final CustomSuccessHandler customSuccessHandler;
    private final CustomAuthenticationFailureHandler customFailureHandler;

    public SecurityConfig(CustomAuthenticationProvider authProvider,
                          CustomAuthenticationFailureHandler customFailureHandler) {
       this.authProvider = authProvider;
       this.customFailureHandler = customFailureHandler;
    }

                        	  
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
                .authenticationProvider(authProvider)
                .sessionManagement(session -> session
                        .maximumSessions(1)
                        .maxSessionsPreventsLogin(false)
                        .sessionRegistry(sessionRegistry())
                        .expiredUrl("/login?error=true&message=Se detecto un nuevo acceso desde otro dispositivo")
                )
               .authorizeRequests(auth -> auth
                       .antMatchers("/login", "/error", "/css/**", "/images/**", "/js/**", "/webjars/**", "/fonts/**").permitAll()
                        // Cada zona exige el menú (rol) que el servicio de seguridad le haya
                        // asignado al usuario. Un mismo usuario puede traer varios menús a la
                        // vez, por eso son hasAnyRole y no hasRole salvo donde solo uno de los
                        // 5 lo cubre.
                       .antMatchers("/facturas-web", "/facturas-distribuciones", "/facturas/**",
                                    "/guardar-distribuciones", "/detalle-distribucion/**",
                                    "/ingresos", "/ingresos/**",
                                    "/archivos/**").hasRole(MenuEnum.REGING.name())

                       .antMatchers("/flujo-caja/ingresos", "/flujo-caja/ingresos/**").hasRole(MenuEnum.REGING.name())
                       .antMatchers("/flujo-caja/egresos", "/flujo-caja/egresos/**").hasRole(MenuEnum.FLUCAJ.name())
                       .antMatchers("/provisiones/consultar", "/provisiones/consultar/**")
                                .hasAnyRole(MenuEnum.FLUCAJ.name(), MenuEnum.REPROV.name())
                       .antMatchers("/provisiones").hasRole(MenuEnum.FLUCAJ.name())
                       // "/flujo-caja/consultar" y "/flujo-caja/semana/**" se llegan tanto
                       // desde "Flujo de Caja" (FLUCAJ, APRFUJ) como desde "Consultar Flujo
                       // de Caja" (FLUCAJ, APRFUJ, ADMFUN) — se deja la unión de los dos.
                       .antMatchers("/flujo-caja/consultar", "/flujo-caja/consultar/**", "/flujo-caja/semana/**")
                                .hasAnyRole(MenuEnum.FLUCAJ.name(), MenuEnum.APRFUJ.name(), MenuEnum.ADMFUN.name())
                       .antMatchers("/flujo-caja").hasAnyRole(MenuEnum.FLUCAJ.name(), MenuEnum.APRFUJ.name())

                       .antMatchers("/reportes", "/reportes/**",
                                     "/control-ingresos/**", "/envios/**")
                                .hasAnyRole(MenuEnum.REGING.name(), MenuEnum.FLUCAJ.name(), MenuEnum.APRFUJ.name(), MenuEnum.ADMFUN.name())
                        .antMatchers("/auditoria", "/auditoria/**")
                                .hasAnyRole(MenuEnum.APRFUJ.name(), MenuEnum.ADMFUN.name())
                        .antMatchers("/mantenimiento", "/mantenimiento/**").hasRole(MenuEnum.ADMFUN.name())
                       .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .loginProcessingUrl("/login")
                        .defaultSuccessUrl("/dashboard", true) // siempre va al dashboard
                        .failureHandler(customFailureHandler)
                        .permitAll()
                )

                .logout(logout -> logout
                        .logoutSuccessUrl("/login")
                );

        return http.build();
    }

    @Bean
    public SessionRegistry sessionRegistry() {
        return new SessionRegistryImpl();
    }

    @Bean
    public static ServletListenerRegistrationBean<HttpSessionEventPublisher>
    httpSessionEventPublisher() {

        return new ServletListenerRegistrationBean<>(
                new HttpSessionEventPublisher()
        );
    }
}
