package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.FacturaPagableDTO;
import com.finanzas.gestionfinanzas.entity.CategoriaEgreso;
import com.finanzas.gestionfinanzas.entity.FlujoCajaConsorcio;
import com.finanzas.gestionfinanzas.entity.FlujoCajaFirma;
import com.finanzas.gestionfinanzas.entity.FlujoCajaIngreso;
import com.finanzas.gestionfinanzas.entity.FlujoCajaPriorizado;
import com.finanzas.gestionfinanzas.entity.FlujoCajaReporte;
import com.finanzas.gestionfinanzas.entity.FlujoCajaReportePdf;
import com.finanzas.gestionfinanzas.entity.FlujoCajaSaldoInicial;
import com.finanzas.gestionfinanzas.entity.FlujoCajaTransferencia;
import com.finanzas.gestionfinanzas.entity.ProvisionPagoSeleccionado;
import com.finanzas.gestionfinanzas.entity.ProvisionRegistro;
import com.finanzas.gestionfinanzas.integracion.firmapam.IServicePAM;
import com.finanzas.gestionfinanzas.integracion.firmapam.ServicePAM;
import com.finanzas.gestionfinanzas.repository.bdd.CategoriaEgresoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaConsorcioRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaFirmaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaIngresoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaPriorizadoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaReportePdfRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaReporteRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaSaldoInicialRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FlujoCajaTransferenciaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionPagoSeleccionadoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionRegistroRepository;
import com.finanzas.gestionfinanzas.utils.FlujoCajaFechaUtils;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StreamUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.xhtmlrenderer.pdf.ITextRenderer;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Firma electrónica del reporte con certificado .p12, usando el servicio SOAP
// institucional de EP Petroecuador (wsPAM.ServicePAM.svc) en vez de firmar el
// PDF localmente: el .p12 + su contraseña + el PDF actual se mandan al
// servicio, que devuelve el PDF ya firmado (una estampa más sobre lo que ya
// había). Por eso alcanza con llamarlo una vez por cada etapa, pasándole
// siempre el PDF que devolvió la etapa anterior, para ir acumulando firmas.
//
// El .p12 y su contraseña se usan una sola vez, en memoria, para esta firma
// puntual: nunca se guardan en el servidor ni se loguean.
//
@Service
public class FlujoCajaFirmaService {

    // "Perfil" que identifica ante el servicio de firma para qué proceso es
    // (confirmado con el área de firma electrónica: puede ser cualquier
    // nombre, no hace falta registrarlo antes).
    private static final String PERFIL_FIRMA = "flujoCajaSemanal";

    private final FlujoCajaReportePdfRepository pdfRepository;
    private final FlujoCajaFirmaRepository firmaRepository;
    private final FlujoCajaReporteRepository reporteRepository;
    private final FlujoCajaSaldoInicialRepository saldoInicialRepository;
    private final FlujoCajaIngresoRepository ingresoRepository;
    private final FlujoCajaConsorcioRepository consorcioRepository;
    private final FlujoCajaPriorizadoRepository priorizadoRepository;
    private final FlujoCajaTransferenciaRepository transferenciaRepository;
    private final CategoriaEgresoRepository categoriaEgresoRepository;
    private final SpringTemplateEngine templateEngine;
    private final AuditoriaSessionService auditoriaSessionService;
    private final FlujoCajaCxpPagableService flujoCajaCxpPagableService;
    private final ProvisionRegistroRepository provisionRegistroRepository;
    private final ProvisionPagoSeleccionadoRepository provisionPagoSeleccionadoRepository;
    private final String logoBase64;

    public FlujoCajaFirmaService(FlujoCajaReportePdfRepository pdfRepository,
                                  FlujoCajaFirmaRepository firmaRepository,
                                  FlujoCajaReporteRepository reporteRepository,
                                  FlujoCajaSaldoInicialRepository saldoInicialRepository,
                                  FlujoCajaIngresoRepository ingresoRepository,
                                  FlujoCajaConsorcioRepository consorcioRepository,
                                  FlujoCajaPriorizadoRepository priorizadoRepository,
                                  FlujoCajaTransferenciaRepository transferenciaRepository,
                                  CategoriaEgresoRepository categoriaEgresoRepository,
                                  SpringTemplateEngine templateEngine,
                                  AuditoriaSessionService auditoriaSessionService,
                                  FlujoCajaCxpPagableService flujoCajaCxpPagableService,
                                  ProvisionRegistroRepository provisionRegistroRepository,
                                  ProvisionPagoSeleccionadoRepository provisionPagoSeleccionadoRepository) {
        this.pdfRepository = pdfRepository;
        this.firmaRepository = firmaRepository;
        this.reporteRepository = reporteRepository;
        this.saldoInicialRepository = saldoInicialRepository;
        this.ingresoRepository = ingresoRepository;
        this.consorcioRepository = consorcioRepository;
        this.priorizadoRepository = priorizadoRepository;
        this.flujoCajaCxpPagableService = flujoCajaCxpPagableService;
        this.transferenciaRepository = transferenciaRepository;
        this.categoriaEgresoRepository = categoriaEgresoRepository;
        this.templateEngine = templateEngine;
        this.auditoriaSessionService = auditoriaSessionService;
        this.provisionRegistroRepository = provisionRegistroRepository;
        this.provisionPagoSeleccionadoRepository = provisionPagoSeleccionadoRepository;
        this.logoBase64 = cargarLogoBase64();
    }

    // Firma una etapa (ELABORADO/APROBADO/AUTORIZADO) sobre el reporte, generando
    // el PDF base si todavía no existe. xFirma/yFirma son la posición que el
    // usuario eligió haciendo clic sobre el PDF en el navegador (ver
    // pdf-preview en el controller) y son obligatorias. Devuelve el nombre
    // del firmante (sacado del certificado), que es lo que
    // FlujoCajaReporteService guarda en elaboradoPor/aprobadoPor/autorizadoPor.
    @Transactional("secondTransactionManager")
    public String firmarEtapa(FlujoCajaReporte reporte, String etapa, InputStream p12Stream, char[] password,
                               Integer xFirma, Integer yFirma) {
        try {
            if (xFirma == null || yFirma == null) {
                throw new RuntimeException("Hace falta elegir la posición de la firma en el PDF antes de firmar.");
            }

            byte[] certificadoBytes = StreamUtils.copyToByteArray(p12Stream);

            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(new java.io.ByteArrayInputStream(certificadoBytes), password);
            String alias = primerAlias(keyStore);
            if (alias == null) {
                throw new RuntimeException("El archivo .p12 no tiene ningún certificado.");
            }

            X509Certificate certificado = (X509Certificate) keyStore.getCertificate(alias);
            if (certificado == null) {
                throw new RuntimeException("No se pudo leer el certificado del .p12. Revise la contraseña.");
            }
            String nombreFirmante = extraerNombreCN(certificado);

            byte[] pdfBase = obtenerOGenerarPdfBase(reporte.getIdReporte());

            String nombreArchivoFirma = "FlujoCaja_" + reporte.getIdReporte() + "_" + etapa;
            byte[] pdfFirmado = firmarConServicioPAM(certificadoBytes, password, pdfBase, nombreArchivoFirma, xFirma, yFirma);

            guardarPdf(reporte, pdfFirmado);

            FlujoCajaFirma firma = new FlujoCajaFirma();
            firma.setReporte(reporte);
            firma.setEtapa(etapa);
            firma.setNombreFirmante(nombreFirmante);
            firma.setFechaFirma(LocalDateTime.now());
            firma.setIdUsuarioCreacion(obtenerUsuarioActual());
            firmaRepository.save(firma);

            auditoriaSessionService.registrarComentario("FC_FIRMA", firma.getIdFirma(), "INSERT",
                    "Firmó como " + etapa + ": " + nombreFirmante + " (reporte semana del "
                            + reporte.getFechaInicio() + ")");

            return nombreFirmante;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("No se pudo firmar con ese .p12: " + e.getMessage(), e);
        } finally {
            // La contraseña queda en memoria lo mínimo posible.
            java.util.Arrays.fill(password, '\0');
        }
    }

    // Llama al servicio SOAP institucional (wsPAM.ServicePAM.svc /
    // setFirmaUltimaHoja_PDF) para estampar la firma sobre el PDF actual. El
    // cliente (IServicePAM/ServicePAM) se genera en cada build a partir del
    // WSDL (ver pom.xml -> cxf-codegen-plugin), así que la máquina que compila
    // necesita alcanzar http://firmaelectronica.eppetroecuador.ec en ese momento;
    // en runtime, instanciar "new ServicePAM()" también vuelve a pedir el WSDL,
    // así que el servidor donde corra la app necesita esa misma conectividad.
    private byte[] firmarConServicioPAM(byte[] certificadoBytes, char[] password, byte[] documentoActual,
                                         String nombreArchivoFirma, int x, int y) {
        IServicePAM puerto = new ServicePAM().getBasicHttpBindingIServicePAM();
        byte[] pdfFirmado = puerto.setFirmaUltimaHojaPDF(
                PERFIL_FIRMA,
                nombreArchivoFirma,
                new String(password),
                certificadoBytes,
                documentoActual,
                x,
                y);
        if (pdfFirmado == null || pdfFirmado.length == 0) {
            throw new RuntimeException("El servicio de firma no devolvió un PDF firmado. Revise el .p12 y la contraseña.");
        }
        return pdfFirmado;
    }

    public byte[] obtenerPdf(Long idReporte) {
        return pdfRepository.findByReporte_IdReporte(idReporte)
                .map(FlujoCajaReportePdf::getContenido)
                .orElse(null);
    }

    // Devuelve el PDF base del reporte (sin firmar todavía), generándolo y
    // guardándolo la primera vez que se pide. Se usa tanto acá adentro como
    // desde el endpoint de vista previa (pdf-preview), para que el usuario
    // pueda ver el PDF y elegir dónde firmar ANTES de subir su .p12.
    //
    // Recibe el ID (no la entidad) y la busca acá mismo, dentro de esta misma
    // transacción: si el caller la trae de otra transacción ya cerrada (como
    // pasa en el endpoint de vista previa, que solo hace un findById suelto),
    // Hibernate la considera "detached" y el guardarPdf() de abajo revienta
    // con PersistentObjectException al querer cascadearla.
    @Transactional("secondTransactionManager")
    public byte[] obtenerOGenerarPdfBase(Long idReporte) {
        // Mientras nadie haya firmado ninguna etapa todavía, no hay ninguna
        // firma real en el PDF guardado que se pueda perder: se regenera
        // siempre con los datos más recientes del reporte (por si se guardaron
        // cambios — observaciones, montos, etc. — después de la última vez
        // que se vio la vista previa). Apenas existe la primera firma, se deja
        // de regenerar y se reutiliza tal cual lo guardado, para no invalidarla.
        boolean yaFirmoAlgo = firmaRepository.existsByReporte_IdReporte(idReporte);
        if (!yaFirmoAlgo) {
            FlujoCajaReporte reporte = reporteRepository.findById(idReporte)
                    .orElseThrow(() -> new RuntimeException("Reporte no encontrado: " + idReporte));
            byte[] base = generarPdfBase(reporte);
            guardarPdf(reporte, base);
            return base;
        }

        return pdfRepository.findByReporte_IdReporte(idReporte)
                .map(FlujoCajaReportePdf::getContenido)
                .orElseGet(() -> {
                    FlujoCajaReporte reporte = reporteRepository.findById(idReporte)
                            .orElseThrow(() -> new RuntimeException("Reporte no encontrado: " + idReporte));
                    byte[] base = generarPdfBase(reporte);
                    guardarPdf(reporte, base);
                    return base;
                });
    }

    private byte[] generarPdfBase(FlujoCajaReporte reporte) {
        List<FlujoCajaSaldoInicial> saldosIniciales = saldoInicialRepository.findByReporte_IdReporte(reporte.getIdReporte());
        List<FlujoCajaIngreso> ingresos = ingresoRepository.findByReporte_IdReporte(reporte.getIdReporte());
        List<FlujoCajaConsorcio> consorcios = consorcioRepository.findByReporte_IdReporte(reporte.getIdReporte());
        List<CategoriaEgreso> categoriasEgreso = categoriaEgresoRepository.findByEstadoOrderByNombreCategoria("A");

        // Egresos (3, 4, 6/7/8): mismos datos ya guardados con el botón "Guardar"
        // de la pantalla (incluidas 3 y 4, que ahí se calculan solas pero se
        // guardan en la misma tabla genérica — ver FlujoCajaReporteController).
        Map<String, FlujoCajaPriorizado> priorizadoPorClave = new HashMap<>();
        for (FlujoCajaPriorizado p : priorizadoRepository.findByReporte_IdReporte(reporte.getIdReporte())) {
            priorizadoPorClave.put(p.getSeccion() + "_" + p.getCategoriaEgreso().getIdCategoriaEgreso(), p);
        }
        // Cada tipo (SRI/SHAYA_BOC2/HEDGE) puede tener VARIAS filas (un
        // concepto por fila), así que agrupa en vez de quedarse con una sola.
        Map<String, List<FlujoCajaTransferencia>> transferenciaPorTipo = new HashMap<>();
        for (FlujoCajaTransferencia t : transferenciaRepository.findByReporte_IdReporte(reporte.getIdReporte())) {
            transferenciaPorTipo.computeIfAbsent(t.getTipo(), k -> new ArrayList<>()).add(t);
        }

        // Anexo "Facturas que se pueden pagar" (según Saldo Final): se calcula EN VIVO,
        // propio de este reporte (no lee la copia local compartida FC_EGR_CXP_PAGABLE
        // — ver el comentario en FlujoCajaCxpPagableService.calcularCubiertasCompleto).
        // Se mete acá, en el PDF BASE que se genera una sola vez (al firmar Elaborado):
        // a partir de esa firma los datos del reporte quedan bloqueados (ver
        // FlujoCajaReporteService.verificarDatosNoBloqueados), así que esta lista no
        // cambia entre Elaborado y Autorizar — es la misma que confirmarAsignacion
        // termina grabando para siempre al Autorizar. Va en el cuerpo del documento
        // (antes de la página de firmas), nunca después: el servicio de firma estampa
        // siempre en la ÚLTIMA hoja, y esa tiene que seguir siendo la de los recuadros
        // de firma sin importar cuán larga sea esta lista.
        List<FacturaPagableDTO> facturasPagables = flujoCajaCxpPagableService
                .calcularCubiertasCompleto(reporte.getIngresosTotal(), reporte.getIdReporte());

        // Provisiones de esta semana (ver PROVISION_REGISTRO.reporte) — va
        // JUSTO DESPUÉS de "Información Consorcios" y ANTES de "Facturas que
        // se pueden pagar", por pedido del usuario (mismo lugar relativo que
        // ya ocupa en pantalla, ver flujo-caja-semanal.html/flujo-caja-egresos.html).
        // Las facturas pagadas de cada registro (Pendiente/Mixto) se traen
        // aparte y se arma un Map por ID_REGISTRO — Thymeleaf no puede llamar
        // al repositorio directo desde la plantilla.
        List<ProvisionRegistro> provisiones = provisionRegistroRepository
                .findByReporte_IdReporteOrderByFechaCreacionDesc(reporte.getIdReporte());
        Map<Long, List<ProvisionPagoSeleccionado>> pagosPorProvisionRegistro = new HashMap<>();
        for (ProvisionRegistro p : provisiones) {
            pagosPorProvisionRegistro.put(p.getIdRegistro(),
                    provisionPagoSeleccionadoRepository.findByRegistro_IdRegistro(p.getIdRegistro()));
        }

        Context context = new Context();
        context.setVariable("reporte", reporte);
        context.setVariable("saldosIniciales", saldosIniciales);
        context.setVariable("ingresos", ingresos);
        context.setVariable("consorcios", consorcios);
        context.setVariable("categoriasEgreso", categoriasEgreso);
        context.setVariable("priorizadoPorClave", priorizadoPorClave);
        context.setVariable("transferenciaPorTipo", transferenciaPorTipo);
        context.setVariable("provisiones", provisiones);
        context.setVariable("pagosPorProvisionRegistro", pagosPorProvisionRegistro);
        context.setVariable("facturasPagables", facturasPagables);
        context.setVariable("logoBase64", logoBase64);
        context.setVariable("tituloPeriodo", FlujoCajaFechaUtils.descripcionPeriodo(reporte.getFechaInicio(), reporte.getFechaFin()));

        String html = templateEngine.process("pdf/flujo-caja-pdf", context);

        try {
            ByteArrayOutputStream salida = new ByteArrayOutputStream();
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(html);
            renderer.layout();
            renderer.createPDF(salida);
            return salida.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("No se pudo generar el PDF del reporte: " + e.getMessage(), e);
        }
    }

    private void guardarPdf(FlujoCajaReporte reporte, byte[] contenido) {
        FlujoCajaReportePdf pdf = pdfRepository.findByReporte_IdReporte(reporte.getIdReporte())
                .orElseGet(FlujoCajaReportePdf::new);
        pdf.setReporte(reporte);
        pdf.setContenido(contenido);
        pdf.setFechaActualizacion(LocalDateTime.now());
        pdfRepository.save(pdf);
    }

    private String primerAlias(KeyStore keyStore) throws Exception {
        java.util.Enumeration<String> alias = keyStore.aliases();
        return alias.hasMoreElements() ? alias.nextElement() : null;
    }

    // El nombre del titular del certificado (CN) es el que se muestra como
    // firmante; si no se puede parsear, se cae al nombre completo del subject.
    private String extraerNombreCN(X509Certificate certificado) {
        String subjectDN = certificado.getSubjectX500Principal().getName();
        try {
            LdapName ldapName = new LdapName(subjectDN);
            for (Rdn rdn : ldapName.getRdns()) {
                if ("CN".equalsIgnoreCase(rdn.getType())) {
                    return rdn.getValue().toString();
                }
            }
        } catch (InvalidNameException e) {
            // sigue con el fallback de abajo
        }
        return subjectDN;
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }

    private String cargarLogoBase64() {
        try {
            byte[] bytes = StreamUtils.copyToByteArray(new ClassPathResource("static/images/logo.png").getInputStream());
            return Base64.getEncoder().encodeToString(bytes);
        } catch (IOException e) {
            return null;
        }
    }
}
