package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "COSTOS_FACTURA")
public class CostoFactura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_COSTO_FACTURA")
    private Long idCostoFactura;

    @ManyToOne
    @JoinColumn(name = "ID_FACTURA")
    private FacturasBDD factura;

    @ManyToOne
    @JoinColumn(name = "ID_DETALLE")
    private DetalleDistribucion detalleDistribucion;

    @ManyToOne
    @JoinColumn(name = "ID_TIPO_COSTO")
    private TipoCosto tipoCosto;

    @Column(name = "VOLUMEN")
    private Double volumen;

    @Column(name = "VALOR_UNITARIO")
    private Double valorUnitario;

    @Column(name = "TOTAL")
    private Double total;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdCostoFactura() {
        return idCostoFactura;
    }

    public void setIdCostoFactura(Long idCostoFactura) {
        this.idCostoFactura = idCostoFactura;
    }

    public FacturasBDD getFactura() {
        return factura;
    }

    public void setFactura(FacturasBDD factura) {
        this.factura = factura;
    }

    public DetalleDistribucion getDetalleDistribucion() {
        return detalleDistribucion;
    }

    public void setDetalleDistribucion(DetalleDistribucion detalleDistribucion) {
        this.detalleDistribucion = detalleDistribucion;
    }

    public TipoCosto getTipoCosto() {
        return tipoCosto;
    }

    public void setTipoCosto(TipoCosto tipoCosto) {
        this.tipoCosto = tipoCosto;
    }

    public Double getVolumen() {
        return volumen;
    }

    public void setVolumen(Double volumen) {
        this.volumen = volumen;
    }

    public Double getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(Double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public String getIdUsuarioCreacion() {
        return idUsuarioCreacion;
    }

    public void setIdUsuarioCreacion(String idUsuarioCreacion) {
        this.idUsuarioCreacion = idUsuarioCreacion;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
