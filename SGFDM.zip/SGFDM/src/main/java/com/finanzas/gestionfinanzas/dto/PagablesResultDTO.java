package com.finanzas.gestionfinanzas.dto;

import org.springframework.data.domain.Page;

import com.finanzas.gestionfinanzas.entity.EgresoCxpPagable;

import java.math.BigDecimal;

// Respuesta del buscador de facturas pagables: la página pedida más el total de
// IMPORTE_A_PAGAR de TODAS las facturas que matchean el filtro actual (no solo
// las de la página visible). Ver FlujoCajaReporteController.buscarPagablesCxp.
public class PagablesResultDTO {

    private final Page<EgresoCxpPagable> pagina;
    private final BigDecimal totalFiltrado;

    public PagablesResultDTO(Page<EgresoCxpPagable> pagina, BigDecimal totalFiltrado) {
        this.pagina = pagina;
        this.totalFiltrado = totalFiltrado;
    }

    public Page<EgresoCxpPagable> getPagina() {
        return pagina;
    }

    public BigDecimal getTotalFiltrado() {
        return totalFiltrado;
    }
}
