package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.CategoriaEgreso;
import com.finanzas.gestionfinanzas.entity.ConceptoTransferencia;
import com.finanzas.gestionfinanzas.entity.ConsorcioCatalogo;
import com.finanzas.gestionfinanzas.repository.bdd.CategoriaEgresoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ConceptoTransferenciaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ConsorcioCatalogoRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/mantenimiento/categorias-egreso")
public class MantenimientoCategoriaEgresoController {

    private final CategoriaEgresoRepository categoriaEgresoRepository;
    private final ConceptoTransferenciaRepository conceptoTransferenciaRepository;
    private final ConsorcioCatalogoRepository consorcioCatalogoRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoCategoriaEgresoController(CategoriaEgresoRepository categoriaEgresoRepository,
                                                    ConceptoTransferenciaRepository conceptoTransferenciaRepository,
                                                    ConsorcioCatalogoRepository consorcioCatalogoRepository,
                                                    AuditoriaSessionService auditoriaSessionService) {
        this.categoriaEgresoRepository = categoriaEgresoRepository;
        this.conceptoTransferenciaRepository = conceptoTransferenciaRepository;
        this.consorcioCatalogoRepository = consorcioCatalogoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                          @RequestParam(required = false) String nombre,
                          @RequestParam(required = false) String estado,
                          @RequestParam(defaultValue = "0") int ctPage,
                          @RequestParam(required = false) String ctNombre,
                          @RequestParam(required = false) String ctTipo,
                          @RequestParam(required = false) String ctEstado,
                          @RequestParam(defaultValue = "0") int ccPage,
                          @RequestParam(required = false) String ccNombre,
                          @RequestParam(required = false) String ccEstado,
                          HttpServletRequest request, Model model) {
        Page<CategoriaEgreso> categoriasEgresoPage =
                categoriaEgresoRepository.buscar(normalizar(nombre), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("categoriasEgresoPage", categoriasEgresoPage);
        model.addAttribute("nombre", nombre);
        model.addAttribute("estado", estado);

        // Conceptos de Transferencia (secciones 6/7/8 de Egresos): se agregan
        // acá mismo, en vez de un ítem de menú nuevo aparte, para no
        // multiplicar submenús por un catálogo tan chico.
        Page<ConceptoTransferencia> conceptosTransferenciaPage = conceptoTransferenciaRepository.buscar(
                normalizar(ctNombre), normalizar(ctTipo), normalizar(ctEstado), PageRequest.of(ctPage, 10));
        model.addAttribute("conceptosTransferenciaPage", conceptosTransferenciaPage);
        model.addAttribute("ctNombre", ctNombre);
        model.addAttribute("ctTipo", ctTipo);
        model.addAttribute("ctEstado", ctEstado);

        // Consorcios ("Información Consorcios" de Egresos): mismo patrón,
        // catálogo chico embebido acá en vez de un ítem de menú aparte.
        Page<ConsorcioCatalogo> consorciosCatalogoPage = consorcioCatalogoRepository.buscar(
                normalizar(ccNombre), normalizar(ccEstado), PageRequest.of(ccPage, 10));
        model.addAttribute("consorciosCatalogoPage", consorciosCatalogoPage);
        model.addAttribute("ccNombre", ccNombre);
        model.addAttribute("ccEstado", ccEstado);

        return "mantenimiento/categorias-egreso";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idCategoriaEgreso,
                           @RequestParam String nombreCategoria,
                           @RequestParam String estado,
                           RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        CategoriaEgreso categoriaEgreso = (idCategoriaEgreso != null)
                ? categoriaEgresoRepository.findById(idCategoriaEgreso).orElseThrow(() -> new RuntimeException("Categoría de egreso no encontrada"))
                : new CategoriaEgreso();

        boolean esNueva = categoriaEgreso.getIdCategoriaEgreso() == null;

        categoriaEgreso.setNombreCategoria(nombreCategoria.trim());
        categoriaEgreso.setEstado(estado);

        if (esNueva) {
            categoriaEgreso.setIdUsuarioCreacion(obtenerUsuarioActual());
            categoriaEgreso.setFechaCreacion(LocalDateTime.now());
        }

        categoriaEgresoRepository.save(categoriaEgreso);
        auditoriaSessionService.registrarComentario("CATEGORIA_EGRESO", categoriaEgreso.getIdCategoriaEgreso(),
                esNueva ? "INSERT" : "UPDATE",
                (esNueva ? "Creó" : "Editó") + " la categoría de egreso " + categoriaEgreso.getNombreCategoria() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/categorias-egreso";
    }

    @PostMapping("/eliminar/{idCategoriaEgreso}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idCategoriaEgreso, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        String nombreEliminada = categoriaEgresoRepository.findById(idCategoriaEgreso)
                .map(CategoriaEgreso::getNombreCategoria).orElse("(desconocida)");
        try {
            categoriaEgresoRepository.deleteById(idCategoriaEgreso);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados en algún reporte de Flujo de Caja");
            return "redirect:/mantenimiento/categorias-egreso";
        }
        auditoriaSessionService.registrarComentario("CATEGORIA_EGRESO", idCategoriaEgreso, "DELETE",
                "Eliminó la categoría de egreso " + nombreEliminada + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/categorias-egreso";
    }

    @PostMapping("/conceptos-transferencia/guardar")
    @Transactional("secondTransactionManager")
    public String guardarConceptoTransferencia(@RequestParam(required = false) Long idConcepto,
                                                 @RequestParam String tipo,
                                                 @RequestParam String nombreConcepto,
                                                 @RequestParam String estado,
                                                 RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        ConceptoTransferencia concepto = (idConcepto != null)
                ? conceptoTransferenciaRepository.findById(idConcepto).orElseThrow(() -> new RuntimeException("Concepto de transferencia no encontrado"))
                : new ConceptoTransferencia();

        boolean esNuevo = concepto.getIdConcepto() == null;

        concepto.setTipo(tipo);
        concepto.setNombreConcepto(nombreConcepto.trim());
        concepto.setEstado(estado);

        if (esNuevo) {
            concepto.setIdUsuarioCreacion(obtenerUsuarioActual());
            concepto.setFechaCreacion(LocalDateTime.now());
        }

        conceptoTransferenciaRepository.save(concepto);
        auditoriaSessionService.registrarComentario("CONCEPTO_TRANSFERENCIA", concepto.getIdConcepto(),
                esNuevo ? "INSERT" : "UPDATE",
                (esNuevo ? "Creó" : "Editó") + " el concepto de transferencia " + concepto.getNombreConcepto() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/categorias-egreso";
    }

    @PostMapping("/conceptos-transferencia/eliminar/{idConcepto}")
    @Transactional("secondTransactionManager")
    public String eliminarConceptoTransferencia(@PathVariable Long idConcepto, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        String nombreEliminado = conceptoTransferenciaRepository.findById(idConcepto)
                .map(ConceptoTransferencia::getNombreConcepto).orElse("(desconocido)");
        try {
            conceptoTransferenciaRepository.deleteById(idConcepto);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados en algún reporte de Flujo de Caja");
            return "redirect:/mantenimiento/categorias-egreso";
        }
        auditoriaSessionService.registrarComentario("CONCEPTO_TRANSFERENCIA", idConcepto, "DELETE",
                "Eliminó el concepto de transferencia " + nombreEliminado + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/categorias-egreso";
    }

    @PostMapping("/consorcios/guardar")
    @Transactional("secondTransactionManager")
    public String guardarConsorcioCatalogo(@RequestParam(required = false) Long idConsorcio,
                                            @RequestParam String nombreConsorcio,
                                            @RequestParam String estado,
                                            RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        ConsorcioCatalogo consorcio = (idConsorcio != null)
                ? consorcioCatalogoRepository.findById(idConsorcio).orElseThrow(() -> new RuntimeException("Consorcio no encontrado"))
                : new ConsorcioCatalogo();

        boolean esNuevo = consorcio.getIdConsorcio() == null;

        consorcio.setNombreConsorcio(nombreConsorcio.trim());
        consorcio.setEstado(estado);

        if (esNuevo) {
            consorcio.setIdUsuarioCreacion(obtenerUsuarioActual());
            consorcio.setFechaCreacion(LocalDateTime.now());
        }

        consorcioCatalogoRepository.save(consorcio);
        auditoriaSessionService.registrarComentario("CONSORCIO_CATALOGO", consorcio.getIdConsorcio(),
                esNuevo ? "INSERT" : "UPDATE",
                (esNuevo ? "Creó" : "Editó") + " el consorcio " + consorcio.getNombreConsorcio() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/categorias-egreso";
    }

    @PostMapping("/consorcios/eliminar/{idConsorcio}")
    @Transactional("secondTransactionManager")
    public String eliminarConsorcioCatalogo(@PathVariable Long idConsorcio, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        String nombreEliminado = consorcioCatalogoRepository.findById(idConsorcio)
                .map(ConsorcioCatalogo::getNombreConsorcio).orElse("(desconocido)");
        try {
            consorcioCatalogoRepository.deleteById(idConsorcio);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar este consorcio");
            return "redirect:/mantenimiento/categorias-egreso";
        }
        auditoriaSessionService.registrarComentario("CONSORCIO_CATALOGO", idConsorcio, "DELETE",
                "Eliminó el consorcio " + nombreEliminado + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/categorias-egreso";
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }
}