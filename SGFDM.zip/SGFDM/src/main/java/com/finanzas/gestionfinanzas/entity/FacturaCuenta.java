package com.finanzas.gestionfinanzas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "FACTURA_CUENTA")
public class FacturaCuenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_FACTURA_CUENTA")
    private Long idFacturaCuenta;

    @ManyToOne
    @JoinColumn(name = "ID_FACTURA")
    private FacturasBDD factura;

    @ManyToOne
    @JoinColumn(name = "ID_CUENTA")
    private Cuenta cuenta;

    @Column(name = "SUBTOTAL")
    private Double subtotal;

    @Column(name = "ID_USUARIO_CREACION")
    private String idUsuarioCreacion;

    @Column(name = "FECHA_CREACION")
    private LocalDateTime fechaCreacion;

    public Long getIdFacturaCuenta() {
        return idFacturaCuenta;
    }

    public void setIdFacturaCuenta(Long idFacturaCuenta) {
        this.idFacturaCuenta = idFacturaCuenta;
    }

    public FacturasBDD getFactura() {
        return factura;
    }

    public void setFactura(FacturasBDD factura) {
        this.factura = factura;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(Double subtotal) {
        this.subtotal = subtotal;
    }

    public String getIdUsuarioCreacion() {
        return idUsuarioCreacion;
    }

    public void setIdUsuarioCreacion(String idUsuarioCreacion) {
        this.idUsuarioCreacion = idUsuarioCreacion;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
