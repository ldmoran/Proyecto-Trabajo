package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaPriorizado;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FlujoCajaPriorizadoRepository extends JpaRepository<FlujoCajaPriorizado, Long> {
    List<FlujoCajaPriorizado> findByReporte_IdReporte(Long idReporte);
    List<FlujoCajaPriorizado> findByReporte_IdReporteAndSeccion(Long idReporte, String seccion);
}