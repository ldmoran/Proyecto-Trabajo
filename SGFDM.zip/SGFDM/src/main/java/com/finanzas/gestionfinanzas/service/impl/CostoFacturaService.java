package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.entity.CostoFactura;
import com.finanzas.gestionfinanzas.entity.Cuenta;
import com.finanzas.gestionfinanzas.entity.DetalleDistribucion;
import com.finanzas.gestionfinanzas.entity.FacturaCuenta;
import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import com.finanzas.gestionfinanzas.entity.Ingreso;
import com.finanzas.gestionfinanzas.repository.bdd.CostoFacturaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CostoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.DetalleDistribucionRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturaCuentaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;
import com.finanzas.gestionfinanzas.repository.bdd.IngresoRepository;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CostoFacturaService {

    private final DetalleDistribucionRepository detalleDistribucionRepository;
    private final IngresoRepository ingresoRepository;
    private final CostoRepository costoRepository;
    private final CostoFacturaRepository costoFacturaRepository;
    private final FacturasBDDRepository facturasBDDRepository;
    private final FacturaCuentaRepository facturaCuentaRepository;
    private final DistribucionService distribucionService;
    private final AuditoriaSessionService auditoriaSessionService;
    private final EstadoFacturaErpService estadoFacturaErpService;

    public CostoFacturaService(DetalleDistribucionRepository detalleDistribucionRepository,
                               IngresoRepository ingresoRepository,
                               CostoRepository costoRepository,
                               CostoFacturaRepository costoFacturaRepository,
                               FacturasBDDRepository facturasBDDRepository,
                               FacturaCuentaRepository facturaCuentaRepository,
                               DistribucionService distribucionService,
                               AuditoriaSessionService auditoriaSessionService,
                               EstadoFacturaErpService estadoFacturaErpService) {
        this.detalleDistribucionRepository = detalleDistribucionRepository;
        this.ingresoRepository = ingresoRepository;
        this.costoRepository = costoRepository;
        this.costoFacturaRepository = costoFacturaRepository;
        this.facturasBDDRepository = facturasBDDRepository;
        this.facturaCuentaRepository = facturaCuentaRepository;
        this.distribucionService = distribucionService;
        this.auditoriaSessionService = auditoriaSessionService;
        this.estadoFacturaErpService = estadoFacturaErpService;
    }

    @Transactional("secondTransactionManager")
    public int guardarCostosFactura(Long idFactura) {
        auditoriaSessionService.activarUsuarioActual();

        FacturasBDD factura = facturasBDDRepository.findById(idFactura)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada"));

        List<DetalleDistribucion> detalles = detalleDistribucionRepository.findConDetalleByFactura(idFactura);

        validarSumaVolumenIgualCantidad(factura, detalles);

        costoFacturaRepository.deleteByFactura_IdFactura(idFactura);
        facturaCuentaRepository.deleteByFactura_IdFactura(idFactura);

        if (detalles.isEmpty()) {
            return 0;
        }

        List<Long> idsDetalle = detalles.stream()
                .map(DetalleDistribucion::getIdDetalle)
                .collect(Collectors.toList());

        List<Ingreso> ingresos = ingresoRepository.findByDetalleDistribucion_IdDetalleIn(idsDetalle);

        List<Long> idsTipoCosto = ingresos.stream()
                .filter(i -> i.getTipoCosto() != null)
                .map(i -> i.getTipoCosto().getIdTipoCosto())
                .distinct()
                .collect(Collectors.toList());

        // Solo se usan costos ACTIVOS: uno que quedó INACTIVO (por edición/creación
        // pendiente de comprobante, ver ArchivoService.subirComprobanteCostos) no debe
        // usarse para calcular montos todavía.
        Map<Long, Double> valorPorTipoCosto = costoRepository.findByTipoCosto_IdTipoCostoInAndEstado(idsTipoCosto, "ACTIVO").stream()
                .collect(Collectors.toMap(
                        c -> c.getTipoCosto().getIdTipoCosto(),
                        c -> c.getValor() != null ? c.getValor() : 0.0,
                        (a, b) -> a));

        Map<Long, DetalleDistribucion> detallesPorId = detalles.stream()
                .collect(Collectors.toMap(DetalleDistribucion::getIdDetalle, d -> d, (a, b) -> a));

        String usuarioActual = SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;

        Map<Long, Cuenta> cuentasPorId = new LinkedHashMap<>();
        Map<Long, Double> subtotalPorCuenta = new LinkedHashMap<>();

        int guardados = 0;
        for (Ingreso ingreso : ingresos) {
            if (ingreso.getDetalleDistribucion() == null || ingreso.getTipoCosto() == null) {
                continue;
            }

            DetalleDistribucion detalle = detallesPorId.get(ingreso.getDetalleDistribucion().getIdDetalle());
            double volumen = detalle != null && detalle.getVolumen() != null ? detalle.getVolumen() : 0.0;

            double valorUnitario;
            double total;
            if (ingreso.getTotalManual() != null) {
                // MEM/Ministerio: no se conoce el costo unitario, el usuario tecleó el
                // total. Se guarda tal cual y el unitario se deduce (total / volumen)
                // solo para que el respaldo quede completo y comparable.
                total = ingreso.getTotalManual();
                valorUnitario = volumen != 0 ? total / volumen : 0.0;
            } else {
                valorUnitario = valorPorTipoCosto.getOrDefault(ingreso.getTipoCosto().getIdTipoCosto(), 0.0);
                total = valorUnitario * volumen;
            }

            CostoFactura costoFactura = new CostoFactura();
            costoFactura.setFactura(factura);
            costoFactura.setDetalleDistribucion(detalle);
            costoFactura.setTipoCosto(ingreso.getTipoCosto());
            costoFactura.setVolumen(volumen);
            costoFactura.setValorUnitario(valorUnitario);
            costoFactura.setTotal(total);
            costoFactura.setIdUsuarioCreacion(usuarioActual);
            costoFactura.setFechaCreacion(LocalDateTime.now());

            costoFacturaRepository.save(costoFactura);
            guardados++;

            Cuenta cuenta = ingreso.getTipoCosto().getCuenta();
            Long idCuenta = cuenta != null ? cuenta.getIdCuenta() : -1L;
            cuentasPorId.putIfAbsent(idCuenta, cuenta);
            subtotalPorCuenta.merge(idCuenta, total, Double::sum);
        }

        // Respaldo del total recolectado por cuenta contable, ya congelado en este
        // momento (independiente de si el VALOR de COSTOS cambia después).
        for (Map.Entry<Long, Double> entry : subtotalPorCuenta.entrySet()) {
            FacturaCuenta facturaCuenta = new FacturaCuenta();
            facturaCuenta.setFactura(factura);
            facturaCuenta.setCuenta(cuentasPorId.get(entry.getKey()));
            facturaCuenta.setSubtotal(entry.getValue());
            facturaCuenta.setIdUsuarioCreacion(usuarioActual);
            facturaCuenta.setFechaCreacion(LocalDateTime.now());
            facturaCuentaRepository.save(facturaCuenta);
        }

        factura.setEstado("A");
        factura.setSecuencia(1); // ronda cerrada: ya Aprobada, nunca más se toca
        factura.setFechaModificacion(LocalDateTime.now());
        facturasBDDRepository.save(factura);

        auditoriaSessionService.registrarComentario("FACTURAS", factura.getIdFactura(), "UPDATE",
                "Aprobó la factura Nº " + factura.getNumFactura());

        estadoFacturaErpService.sincronizar(factura);

        // Si esta ronda quedó Parcial (le faltó volumen por distribuir), se crea
        // de una vez la fila de la siguiente ronda con ese saldo pendiente, para
        // que quede lista sin que el usuario tenga que hacer nada más aparte.
        if ("P".equals(factura.getEstadoParcial())) {
            distribucionService.crearNuevaRonda(factura.getIdFactura());
        }

        return guardados;
    }

    // Marca o desmarca una factura ya Aprobada como "no enviar a EBS" porque llegó
    // a destiempo. No toca su cálculo (COSTOS_FACTURA/FACTURA_CUENTA siguen igual,
    // así que sigue viéndose normal en reportes); solo la saca de las candidatas a
    // seleccionarse en un envío a EBS (ver EnvioEbsService.guardarEnvio, que además
    // valida esto de nuevo por si se fuerza la llamada saltándose la pantalla).
    @Transactional("secondTransactionManager")
    public void marcarExclusionEbs(Long idFactura, boolean excluida, String motivo) {
        auditoriaSessionService.activarUsuarioActual();

        FacturasBDD factura = facturasBDDRepository.findById(idFactura)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada"));

        factura.setExcluidaEbs(excluida ? "S" : "N");
        factura.setMotivoExclusionEbs(excluida ? motivo : null);
        factura.setIdUsuarioExclusion(excluida && SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario() : null);
        factura.setFechaExclusion(excluida ? LocalDateTime.now() : null);

        facturasBDDRepository.save(factura);
        auditoriaSessionService.registrarComentario("FACTURAS", factura.getIdFactura(), "UPDATE",
                excluida
                        ? "Excluyó la factura Nº " + factura.getNumFactura() + " del envío a EBS: " + motivo
                        : "Volvió a incluir la factura Nº " + factura.getNumFactura() + " en el envío a EBS.");
    }

    // No se puede aprobar una factura mientras la suma de los volúmenes de sus
    // distribuciones no sea EXACTAMENTE igual a su VOLUMEN_TOTAL (a diferencia de
    // agregar/editar una distribución individual, donde sí se permite quedar por
    // debajo mientras se sigue distribuyendo). EXCEPCIÓN: si la factura está en
    // modo parcial (ESTADO_PARCIAL != null), esa exigencia no aplica — ya se validó
    // al guardar que no supera su VOLUMEN_TOTAL, y aprobar con menos es justamente
    // el punto de una ronda parcial.
    private void validarSumaVolumenIgualCantidad(FacturasBDD factura, List<DetalleDistribucion> detalles) {
        if (factura.getEstadoParcial() != null) {
            return;
        }

        Double volumenObjetivo = factura.getVolumenTotal() != null
                ? factura.getVolumenTotal()
                : (factura.getCantidad() != null ? factura.getCantidad().doubleValue() : null);
        if (volumenObjetivo == null) {
            return;
        }

        double sumaVolumen = detalles.stream()
                .mapToDouble(d -> d.getVolumen() != null ? d.getVolumen() : 0.0)
                .sum();

        if (Math.abs(sumaVolumen - volumenObjetivo) > 0.01) {
            throw new RuntimeException(String.format(
                    "No se puede aprobar: la suma de volúmenes (%.2f) debe ser igual a la cantidad de la factura (%.2f)",
                    sumaVolumen, volumenObjetivo));
        }
    }
}
