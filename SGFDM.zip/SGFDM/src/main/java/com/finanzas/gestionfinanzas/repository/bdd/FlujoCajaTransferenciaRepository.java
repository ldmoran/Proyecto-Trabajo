package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.FlujoCajaTransferencia;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FlujoCajaTransferenciaRepository extends JpaRepository<FlujoCajaTransferencia, Long> {
    List<FlujoCajaTransferencia> findByReporte_IdReporte(Long idReporte);
}