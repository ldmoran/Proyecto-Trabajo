package com.finanzas.gestionfinanzas.service.impl;

import com.finanzas.gestionfinanzas.dto.NuevaDistribucionDTO;
import com.finanzas.gestionfinanzas.entity.DetalleDistribucion;
import com.finanzas.gestionfinanzas.entity.DistribucionHija;
import com.finanzas.gestionfinanzas.entity.FacturasBDD;
import com.finanzas.gestionfinanzas.entity.Ingreso;
import com.finanzas.gestionfinanzas.entity.TipoCosto;
import com.finanzas.gestionfinanzas.repository.bdd.DetalleDistribucionRepository;
import com.finanzas.gestionfinanzas.repository.bdd.DistribucionHijaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.FacturasBDDRepository;
import com.finanzas.gestionfinanzas.repository.bdd.IngresoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.TipoCostoRepository;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class DistribucionService {

    private final DistribucionHijaRepository hijaRepo;
    private final DetalleDistribucionRepository detalleRepo;
    private final IngresoRepository ingresoRepo;
    private final TipoCostoRepository tipoCostoRepository;
    private final FacturasBDDRepository facturasRepo;
    private final AuditoriaSessionService auditoriaSessionService;
    private final EstadoFacturaErpService estadoFacturaErpService;

    public DistribucionService(DistribucionHijaRepository hijaRepo,
                               DetalleDistribucionRepository detalleRepo,
                               IngresoRepository ingresoRepo,
                               TipoCostoRepository tipoCostoRepository,
                               FacturasBDDRepository facturasRepo,
                               AuditoriaSessionService auditoriaSessionService,
                               EstadoFacturaErpService estadoFacturaErpService) {
        this.hijaRepo = hijaRepo;
        this.detalleRepo = detalleRepo;
        this.ingresoRepo = ingresoRepo;
        this.tipoCostoRepository = tipoCostoRepository;
        this.facturasRepo = facturasRepo;
        this.auditoriaSessionService = auditoriaSessionService;
        this.estadoFacturaErpService = estadoFacturaErpService;
    }

    // Guarda TODO el lote de distribuciones que el usuario armó en el modal de una sola
    // vez, de forma atómica: si alguna es inválida (duplicada, o la suma de sus volúmenes
    // más lo que ya existía en la factura supera su VOLUMEN_TOTAL), no se guarda NINGUNA
    // del lote. Antes se guardaba una por una y podía quedar una guardada y otra no aunque
    // juntas superaran la cantidad, lo cual no debía pasar.
    //
    // marcarParcial: si el usuario tildó "Marcar como parcial", no exige que la suma cuadre
    // EXACTO con VOLUMEN_TOTAL (solo que no lo supere); una vez usado, la factura queda en
    // modo parcial de forma permanente para esa fila (ESTADO_PARCIAL != null), aunque en un
    // guardado posterior no se vuelva a tildar el check.
    @Transactional("secondTransactionManager")
    public void guardarLoteDetalleDistribucion(Long idFactura, List<NuevaDistribucionDTO> nuevasDistribuciones, boolean marcarParcial) {
        if (nuevasDistribuciones == null || nuevasDistribuciones.isEmpty()) {
            return;
        }

        auditoriaSessionService.activarUsuarioActual();

        FacturasBDD factura = facturasRepo.findById(idFactura)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada"));

        if ("A".equalsIgnoreCase(factura.getEstado())) {
            throw new RuntimeException("La factura ya está Aprobada: no se pueden agregar más distribuciones");
        }

        Set<Long> idsHijaEnLote = new HashSet<>();
        for (NuevaDistribucionDTO nueva : nuevasDistribuciones) {
            if (!idsHijaEnLote.add(nueva.getIdHija())) {
                throw new RuntimeException("No se puede agregar la misma distribución dos veces en el mismo guardado");
            }
            if (detalleRepo.existsByFactura_IdFacturaAndDistribucionHija_IdDeta(idFactura, nueva.getIdHija())) {
                throw new RuntimeException("Esta distribución ya fue agregada a la factura: edita su volumen en vez de agregarla de nuevo");
            }
        }

        boolean usaParcial = marcarParcial || factura.getEstadoParcial() != null;
        Double volumenObjetivo = factura.getVolumenTotal() != null
                ? factura.getVolumenTotal()
                : (factura.getCantidad() != null ? factura.getCantidad().doubleValue() : null);

        double total = 0;
        if (volumenObjetivo != null) {
            double sumaExistente = detalleRepo.sumVolumenByFactura(idFactura);
            double sumaNueva = nuevasDistribuciones.stream()
                    .mapToDouble(n -> n.getVolumen() != null ? n.getVolumen() : 0.0)
                    .sum();
            total = sumaExistente + sumaNueva;

            if (usaParcial) {
                // Modo parcial: puede quedar por debajo (se completa en otra ronda), pero
                // nunca por encima del volumen que le corresponde a ESTA ronda.
                if (total - volumenObjetivo > 0.01) {
                    throw new RuntimeException(String.format(
                            "La suma de los volúmenes (%.2f) supera el volumen total de esta ronda (%.2f): no se guardó ninguna distribución de este envío",
                            total, volumenObjetivo));
                }
            } else if (Math.abs(total - volumenObjetivo) > 0.01) {
                throw new RuntimeException(String.format(
                        "La suma de los volúmenes (%.2f) debe quedar exactamente igual a la cantidad de la factura (%.2f): no se guardó ninguna distribución de este envío",
                        total, volumenObjetivo));
            }
        }

        String usuarioActual = SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;

        for (NuevaDistribucionDTO nueva : nuevasDistribuciones) {
            DistribucionHija hija = hijaRepo.findByIdConCostosDefault(nueva.getIdHija())
                    .orElseThrow(() -> new RuntimeException("Distribución hija no encontrada"));

            if (hija.getDistribucionPadre() == null || hija.getDistribucionPadre().getCrudo() == null) {
                throw new RuntimeException("La distribución no tiene un crudo asociado");
            }

            DetalleDistribucion detalle = new DetalleDistribucion();
            detalle.setFactura(factura);
            detalle.setDistribucionHija(hija);
            detalle.setVolumen(nueva.getVolumen());
            detalle.setIdUsuarioCreacion(usuarioActual);
            detalle.setFechaCreacion(LocalDateTime.now());
            detalleRepo.save(detalle);

            boolean usaCostosPorDefecto = hija.getTiposCostoDefault() != null && !hija.getTiposCostoDefault().isEmpty();
            Map<Long, Double> totalesManuales = nueva.getTotalesManualPorTipoCosto();

            List<TipoCosto> tiposCosto = usaCostosPorDefecto
                    ? hija.getTiposCostoDefault()
                    : resolverCostosManuales(totalesManuales);

            for (TipoCosto tipoCosto : tiposCosto) {
                Ingreso ingreso = new Ingreso();
                ingreso.setDetalleDistribucion(detalle);
                ingreso.setTipoCosto(tipoCosto);
                // En los costos elegidos a mano (MEM/Ministerio) el usuario teclea el
                // total porque no se conoce el costo unitario; en los de por defecto
                // queda null y el total se calcula con el valor del catálogo.
                if (!usaCostosPorDefecto && totalesManuales != null) {
                    ingreso.setTotalManual(totalesManuales.get(tipoCosto.getIdTipoCosto()));
                }
                ingreso.setIdUsuarioCreacion(usuarioActual);
                ingreso.setFechaCreacion(LocalDateTime.now());

                ingresoRepo.save(ingreso);
            }
        }

        if (volumenObjetivo != null) {
            factura.setVolumenDistribuido(total);
            double faltante = volumenObjetivo - total;
            factura.setVolumenFaltante(faltante);
            if (usaParcial) {
                factura.setEstadoParcial(Math.abs(faltante) < 0.01 ? "C" : "P");
            }
        }
        // Aunque no haya volumen de referencia, la factura se acaba de trabajar y
        // debe subir al tope del listado.
        factura.setFechaModificacion(LocalDateTime.now());
        facturasRepo.save(factura);

        auditoriaSessionService.registrarComentario("FACTURAS", factura.getIdFactura(), "UPDATE",
                "Agregó " + nuevasDistribuciones.size() + " distribución(es) a la factura Nº " + factura.getNumFactura() + ".");

        estadoFacturaErpService.sincronizar(factura);
    }

    // Clona los datos descriptivos de una factura ya Aprobada que quedó con saldo
    // pendiente (ESTADO_PARCIAL = 'P') en una fila NUEVA, para seguir distribuyendo
    // lo que falta: el VOLUMEN_TOTAL de esta nueva ronda es el VOLUMEN_FALTANTE de
    // la anterior. La CANTIDAD original nunca cambia (viene del ERP).
    @Transactional("secondTransactionManager")
    public FacturasBDD crearNuevaRonda(Long idFacturaAnterior) {
        auditoriaSessionService.activarUsuarioActual();
        FacturasBDD anterior = facturasRepo.findById(idFacturaAnterior)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada"));

        if (!"A".equalsIgnoreCase(anterior.getEstado())) {
            throw new RuntimeException("La factura debe estar Aprobada para poder distribuir su saldo pendiente");
        }
        if (!"P".equals(anterior.getEstadoParcial())) {
            throw new RuntimeException("Esta factura no tiene saldo pendiente por distribuir");
        }
        // Nunca debe haber 2 rondas activas (sin aprobar) a la vez para la misma
        // factura del ERP: si ya existe una fila con SECUENCIA = 0 para este
        // CUSTOMER_TRX_ID, no se crea otra (evita duplicar la ronda por un doble
        // clic o una llamada repetida).
        if (anterior.getCustomerTrxId() != null
                && facturasRepo.existsByCustomerTrxIdAndSecuencia(anterior.getCustomerTrxId(), 0)) {
            throw new RuntimeException("Ya existe una ronda pendiente sin aprobar para esta factura");
        }

        FacturasBDD nueva = new FacturasBDD();
        nueva.setCustomerTrxId(anterior.getCustomerTrxId());
        nueva.setNumFactura(anterior.getNumFactura());
        nueva.setFecEmbarque(anterior.getFecEmbarque());
        nueva.setFecDeposito(anterior.getFecDeposito());
        nueva.setRuc(anterior.getRuc());
        nueva.setCompania(anterior.getCompania());
        nueva.setContrato(anterior.getContrato());
        nueva.setBuque(anterior.getBuque());
        nueva.setCantidad(anterior.getCantidad());
        nueva.setPrecio(anterior.getPrecio());
        nueva.setSubtotal(anterior.getSubtotal());
        nueva.setDescripcion(anterior.getDescripcion());
        nueva.setFecFactura(anterior.getFecFactura());
        nueva.setIdDistribucion(0L);
        nueva.setEstado("R");
        nueva.setVolumenTotal(anterior.getVolumenFaltante());
        nueva.setVolumenDistribuido(0.0);
        nueva.setVolumenFaltante(anterior.getVolumenFaltante());
        nueva.setSecuencia(0); // ronda activa/pendiente, aún no Aprobada
        // Arranca en Parcial (le falta TODO su volumen por distribuir); así, al
        // completarla, guardarLoteDetalleDistribucion la pasa a Completado ('C')
        // aunque en ese guardado puntual no se vuelva a tildar "marcar parcial".
        nueva.setEstadoParcial("P");
        nueva.setFechaModificacion(LocalDateTime.now());

        FacturasBDD guardada = facturasRepo.save(nueva);
        auditoriaSessionService.registrarComentario("FACTURAS", guardada.getIdFactura(), "INSERT",
                "Creó una nueva ronda para distribuir el saldo pendiente (" + guardada.getVolumenTotal()
                        + ") de la factura Nº " + anterior.getNumFactura() + ".");
        // La factura del ERP sigue con saldo pendiente: se le informa "Parcial",
        // pisando el estado que se le acababa de poner al aprobar la ronda anterior.
        estadoFacturaErpService.sincronizar(guardada);
        return guardada;
    }

    private List<TipoCosto> resolverCostosManuales(Map<Long, Double> totalesManualPorTipoCosto) {
        // Hay campos donde solo se registra el nombre y el volumen, sin costo alguno
        // (PARDALISERVICES, los IGAPO, y los MEM cuyos valores llegan por oficio del
        // Ministerio a fin de mes). Guardar sin costos es válido: queda el detalle
        // con su volumen y sin filas en INGRESOS.
        if (totalesManualPorTipoCosto == null || totalesManualPorTipoCosto.isEmpty()) {
            return Collections.emptyList();
        }

        for (Map.Entry<Long, Double> entry : totalesManualPorTipoCosto.entrySet()) {
            if (entry.getValue() == null) {
                throw new RuntimeException("Debe indicarse el total de cada costo seleccionado manualmente");
            }
        }

        return tipoCostoRepository.findAllById(totalesManualPorTipoCosto.keySet());
    }

    @Transactional("secondTransactionManager")
    public void editarVolumen(Long idDetalle, Double volumen) {
        auditoriaSessionService.activarUsuarioActual();
        DetalleDistribucion detalle = detalleRepo.findById(idDetalle)
                .orElseThrow(() -> new RuntimeException("Distribución no encontrada"));

        validarNoAprobada(detalle);
        validarVolumenNoExcedeCantidad(detalle.getFactura(), detalle.getFactura().getIdFactura(), volumen, detalle.getVolumen());

        detalle.setVolumen(volumen);
        detalleRepo.save(detalle);
        auditoriaSessionService.registrarComentario("DETALLE_DISTRIBUCION", idDetalle, "UPDATE",
                "Editó el volumen de una distribución de la factura Nº "
                        + (detalle.getFactura() != null ? detalle.getFactura().getNumFactura() : "?") + " a " + volumen + ".");

        actualizarVolumenesFactura(detalle.getFactura());
    }

    // La suma de los volúmenes de todas las distribuciones de una factura no puede
    // superar su VOLUMEN_TOTAL (toda la CANTIDAD en la primera ronda, o el saldo
    // pendiente de la ronda anterior si es una continuación). Puede quedar por
    // debajo mientras se sigue distribuyendo, pero nunca por encima.
    private void validarVolumenNoExcedeCantidad(FacturasBDD factura, Long idFactura, Double volumenNuevo, Double volumenAnteriorAReemplazar) {
        if (factura == null) {
            return;
        }

        Double volumenObjetivo = factura.getVolumenTotal() != null
                ? factura.getVolumenTotal()
                : (factura.getCantidad() != null ? factura.getCantidad().doubleValue() : null);
        if (volumenObjetivo == null) {
            return;
        }

        double sumaActual = detalleRepo.sumVolumenByFactura(idFactura);
        double sumaSinReemplazado = sumaActual - (volumenAnteriorAReemplazar != null ? volumenAnteriorAReemplazar : 0.0);
        double nuevaSuma = sumaSinReemplazado + (volumenNuevo != null ? volumenNuevo : 0.0);

        if (nuevaSuma - volumenObjetivo > 0.01) {
            throw new RuntimeException(String.format(
                    "El volumen supera el volumen total de esta factura: ya se han distribuido %.2f y el total es %.2f",
                    sumaSinReemplazado, volumenObjetivo));
        }
    }

    @Transactional("secondTransactionManager")
    public void eliminarDetalle(Long idDetalle) {
        auditoriaSessionService.activarUsuarioActual();
        DetalleDistribucion detalle = detalleRepo.findById(idDetalle)
                .orElseThrow(() -> new RuntimeException("Distribución no encontrada"));

        validarNoAprobada(detalle);

        FacturasBDD factura = detalle.getFactura();
        ingresoRepo.deleteByDetalleDistribucion_IdDetalle(idDetalle);
        detalleRepo.delete(detalle);
        auditoriaSessionService.registrarComentario("DETALLE_DISTRIBUCION", idDetalle, "DELETE",
                "Eliminó una distribución de la factura Nº " + (factura != null ? factura.getNumFactura() : "?") + ".");

        actualizarVolumenesFactura(factura);
    }

    private void validarNoAprobada(DetalleDistribucion detalle) {
        FacturasBDD factura = detalle.getFactura();
        if (factura != null && "A".equalsIgnoreCase(factura.getEstado())) {
            throw new RuntimeException("La factura ya está Aprobada: no se pueden modificar sus distribuciones");
        }
    }

    // Recalcula VOLUMEN_DISTRIBUIDO/VOLUMEN_FALTANTE tras editar o eliminar una
    // distribución individual (fuera del guardado en lote). Si la factura ya está
    // en modo parcial (ESTADO_PARCIAL != null), también reevalúa si quedó Completa.
    private void actualizarVolumenesFactura(FacturasBDD factura) {
        if (factura == null) {
            return;
        }

        Double volumenObjetivo = factura.getVolumenTotal() != null
                ? factura.getVolumenTotal()
                : (factura.getCantidad() != null ? factura.getCantidad().doubleValue() : null);
        if (volumenObjetivo == null) {
            return;
        }

        double sumaActual = detalleRepo.sumVolumenByFactura(factura.getIdFactura());
        double faltante = volumenObjetivo - sumaActual;

        factura.setVolumenDistribuido(sumaActual);
        factura.setVolumenFaltante(faltante);
        if (factura.getEstadoParcial() != null) {
            factura.setEstadoParcial(Math.abs(faltante) < 0.01 ? "C" : "P");
        }
        factura.setFechaModificacion(LocalDateTime.now());
        facturasRepo.save(factura);

        estadoFacturaErpService.sincronizar(factura);
    }

}
