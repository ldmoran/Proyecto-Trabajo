package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.ProvisionArea;
import com.finanzas.gestionfinanzas.entity.ProvisionConcepto;
import com.finanzas.gestionfinanzas.entity.ProvisionGerencia;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionAreaRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionConceptoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.ProvisionGerenciaRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Mantenimiento de la jerarquía Gerencia -> Área -> Concepto de Provisión
// (ver reset_bd.sql y ProvisionesController). Gerencias y Áreas son
// catálogos chicos (se listan enteras, sin paginar); Conceptos es la tabla
// principal, con búsqueda y paginación, igual que Mantenimiento > Categorías
// de egreso. ZONA es un dato del Concepto (no un catálogo aparte): valores
// fijos ZCN/ZNO/ZSO/ZSU.
@Controller
@RequestMapping("/mantenimiento/conceptos-provision")
public class MantenimientoProvisionController {

    private final ProvisionGerenciaRepository gerenciaRepository;
    private final ProvisionAreaRepository areaRepository;
    private final ProvisionConceptoRepository conceptoRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoProvisionController(ProvisionGerenciaRepository gerenciaRepository,
                                              ProvisionAreaRepository areaRepository,
                                              ProvisionConceptoRepository conceptoRepository,
                                              AuditoriaSessionService auditoriaSessionService) {
        this.gerenciaRepository = gerenciaRepository;
        this.areaRepository = areaRepository;
        this.conceptoRepository = conceptoRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                          @RequestParam(required = false) String nombre,
                          @RequestParam(required = false) String estado,
                          HttpServletRequest request, Model model) {
        List<ProvisionGerencia> gerencias = gerenciaRepository.findAll();
        List<ProvisionArea> areas = areaRepository.findAll();
        Page<ProvisionConcepto> conceptosPage =
                conceptoRepository.buscar(normalizar(nombre), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("gerencias", gerencias);
        model.addAttribute("areas", areas);
        model.addAttribute("conceptosPage", conceptosPage);
        model.addAttribute("nombre", nombre);
        model.addAttribute("estado", estado);

        // Para que el combo de Área del formulario de Concepto se filtre
        // solo por la Gerencia elegida, sin ir de nuevo al servidor.
        List<Map<String, Object>> areasJson = new ArrayList<>();
        for (ProvisionArea a : areas) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", a.getIdArea());
            item.put("nombre", a.getNombreArea());
            item.put("idGerencia", a.getGerencia() != null ? a.getGerencia().getIdGerencia() : null);
            areasJson.add(item);
        }
        model.addAttribute("areasJson", areasJson);

        return "mantenimiento/conceptos-provision";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    // ---- Gerencia ----

    @PostMapping("/gerencia/guardar")
    @Transactional("secondTransactionManager")
    public String guardarGerencia(@RequestParam(required = false) Long idGerencia,
                                   @RequestParam String nombreGerencia,
                                   @RequestParam String estado,
                                   RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        boolean esNueva = idGerencia == null;
        ProvisionGerencia gerencia = !esNueva
                ? gerenciaRepository.findById(idGerencia).orElseThrow(() -> new RuntimeException("Gerencia no encontrada"))
                : new ProvisionGerencia();

        gerencia.setNombreGerencia(nombreGerencia.trim());
        gerencia.setEstado(estado);
        gerenciaRepository.save(gerencia);
        auditoriaSessionService.registrarComentario("PROVISION_GERENCIA", gerencia.getIdGerencia(),
                esNueva ? "INSERT" : "UPDATE",
                (esNueva ? "Creó" : "Editó") + " la gerencia de provisión " + gerencia.getNombreGerencia() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/conceptos-provision";
    }

    @PostMapping("/gerencia/eliminar/{idGerencia}")
    @Transactional("secondTransactionManager")
    public String eliminarGerencia(@PathVariable Long idGerencia, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();
        String nombreEliminada = gerenciaRepository.findById(idGerencia).map(ProvisionGerencia::getNombreGerencia).orElse("(desconocida)");
        try {
            gerenciaRepository.deleteById(idGerencia);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene Áreas asociadas");
            return "redirect:/mantenimiento/conceptos-provision";
        }
        auditoriaSessionService.registrarComentario("PROVISION_GERENCIA", idGerencia, "DELETE",
                "Eliminó la gerencia de provisión " + nombreEliminada + ".");
        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/conceptos-provision";
    }

    // ---- Área ----

    @PostMapping("/area/guardar")
    @Transactional("secondTransactionManager")
    public String guardarArea(@RequestParam(required = false) Long idArea,
                               @RequestParam Long idGerencia,
                               @RequestParam String nombreArea,
                               @RequestParam String estado,
                               RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        ProvisionGerencia gerencia = gerenciaRepository.findById(idGerencia)
                .orElseThrow(() -> new RuntimeException("Gerencia no encontrada"));

        boolean esNueva = idArea == null;
        ProvisionArea area = !esNueva
                ? areaRepository.findById(idArea).orElseThrow(() -> new RuntimeException("Área no encontrada"))
                : new ProvisionArea();

        area.setGerencia(gerencia);
        area.setNombreArea(nombreArea.trim());
        area.setEstado(estado);
        areaRepository.save(area);
        auditoriaSessionService.registrarComentario("PROVISION_AREA", area.getIdArea(),
                esNueva ? "INSERT" : "UPDATE",
                (esNueva ? "Creó" : "Editó") + " el área de provisión " + area.getNombreArea() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/conceptos-provision";
    }

    @PostMapping("/area/eliminar/{idArea}")
    @Transactional("secondTransactionManager")
    public String eliminarArea(@PathVariable Long idArea, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();
        String nombreEliminada = areaRepository.findById(idArea).map(ProvisionArea::getNombreArea).orElse("(desconocida)");
        try {
            areaRepository.deleteById(idArea);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene Conceptos asociados");
            return "redirect:/mantenimiento/conceptos-provision";
        }
        auditoriaSessionService.registrarComentario("PROVISION_AREA", idArea, "DELETE",
                "Eliminó el área de provisión " + nombreEliminada + ".");
        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/conceptos-provision";
    }

    // ---- Concepto ----

    @PostMapping("/concepto/guardar")
    @Transactional("secondTransactionManager")
    public String guardarConcepto(@RequestParam(required = false) Long idConcepto,
                                   @RequestParam Long idArea,
                                   @RequestParam String zona,
                                   @RequestParam String nombreConcepto,
                                   @RequestParam String estado,
                                   RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        ProvisionArea area = areaRepository.findById(idArea)
                .orElseThrow(() -> new RuntimeException("Área no encontrada"));

        boolean esNuevo = idConcepto == null;
        ProvisionConcepto concepto = !esNuevo
                ? conceptoRepository.findById(idConcepto).orElseThrow(() -> new RuntimeException("Concepto no encontrado"))
                : new ProvisionConcepto();

        concepto.setArea(area);
        concepto.setZona(zona);
        concepto.setNombreConcepto(nombreConcepto.trim());
        concepto.setEstado(estado);
        conceptoRepository.save(concepto);
        auditoriaSessionService.registrarComentario("PROVISION_CONCEPTO", concepto.getIdConcepto(),
                esNuevo ? "INSERT" : "UPDATE",
                (esNuevo ? "Creó" : "Editó") + " el concepto de provisión " + concepto.getNombreConcepto() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/conceptos-provision";
    }

    @PostMapping("/concepto/eliminar/{idConcepto}")
    @Transactional("secondTransactionManager")
    public String eliminarConcepto(@PathVariable Long idConcepto, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();
        String nombreEliminado = conceptoRepository.findById(idConcepto).map(ProvisionConcepto::getNombreConcepto).orElse("(desconocido)");
        try {
            conceptoRepository.deleteById(idConcepto);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros de Provisiones asociados");
            return "redirect:/mantenimiento/conceptos-provision";
        }
        auditoriaSessionService.registrarComentario("PROVISION_CONCEPTO", idConcepto, "DELETE",
                "Eliminó el concepto de provisión " + nombreEliminado + ".");
        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/conceptos-provision";
    }
}
