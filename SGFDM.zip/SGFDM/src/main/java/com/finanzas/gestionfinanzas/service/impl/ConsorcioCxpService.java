package com.finanzas.gestionfinanzas.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDate;
import java.util.List;

// Lectura cruda de facturas de Cuentas por Pagar de los consorcios Shaya y
// Shushufindi (vista APPS.XXOCS_AP_CXP_CONSORCIOS_V, datasource "primary",
// misma base que APPS.XXOCS_AP_CXP_CONS_V). Es solo de referencia para la
// sección "Información Consorcios" de Egresos (ver
// FlujoCajaReporteController.verEgresos): al elegir un consorcio en esa
// grilla, se le muestra al usuario qué facturas de ESE consorcio vencen en
// la semana del reporte, para ayudarlo a llenar Descripción/Saldo estimado
// a mano — no se guarda nada de esto, no se suma a ningún total.
//
// SQL nativo directo en vez de mapear una @Entity completa para la vista,
// mismo patrón que EgresoCxpService.
@Service
public class ConsorcioCxpService {

    // Filtra por PROVEEDOR en vez de exigir el nombre exacto: la vista real
    // trae "SHAYA ECUADOR S.A." (sin "CONSORCIO" adelante) y "CONSORCIO
    // SHUSHUFINDI S.A." (con "CONSORCIO") — el LIKE por la palabra clave
    // cubre ambas variantes sin depender de que el ERP escriba el nombre
    // completo igual que el select de la pantalla.
    private static final String SQL_FACTURAS_CONSORCIOS =
            "SELECT FUENTE, INVOICE_ID, PROVEEDOR, TIPO_DOCUMENTO, DOCUMENTO, " +
            "       TO_CHAR(FECHA_DOCUMENTO, 'YYYY-MM-DD') AS FECHA_DOC_STR, " +
            "       TO_CHAR(FECHA_VENCIMIENTO, 'YYYY-MM-DD') AS FECHA_VENC_STR, " +
            "       IMPORTE_A_PAGAR, DESCRIPCION, CONTRATO, TERMINO_PAGO, GRUPO_PAGO, METODO_PAGO " +
            "FROM APPS.XXOCS_AP_CXP_CONSORCIOS_V " +
            "WHERE (UPPER(PROVEEDOR) LIKE '%SHAYA%' OR UPPER(PROVEEDOR) LIKE '%SHUSHUFINDI%') " +
            "AND FECHA_VENCIMIENTO >= TO_DATE(:fechaInicio, 'YYYY-MM-DD') " +
            "AND FECHA_VENCIMIENTO < TO_DATE(:fechaFin, 'YYYY-MM-DD') + 1 " +
            "ORDER BY FECHA_VENCIMIENTO";

    @PersistenceContext(unitName = "primary")
    private EntityManager entityManager;

    // Fila: [0]=FUENTE, [1]=INVOICE_ID, [2]=PROVEEDOR, [3]=TIPO_DOCUMENTO, [4]=DOCUMENTO,
    // [5]=FECHA_DOC_STR, [6]=FECHA_VENC_STR, [7]=IMPORTE_A_PAGAR, [8]=DESCRIPCION,
    // [9]=CONTRATO, [10]=TERMINO_PAGO, [11]=GRUPO_PAGO, [12]=METODO_PAGO.
    @Transactional("primaryTransactionManager")
    public List<Object[]> obtenerFacturasConsorcios(LocalDate fechaInicio, LocalDate fechaFin) {
        @SuppressWarnings("unchecked")
        List<Object[]> filas = entityManager.createNativeQuery(SQL_FACTURAS_CONSORCIOS)
                .setParameter("fechaInicio", fechaInicio.toString())
                .setParameter("fechaFin", fechaFin.toString())
                .getResultList();
        return filas;
    }
}
