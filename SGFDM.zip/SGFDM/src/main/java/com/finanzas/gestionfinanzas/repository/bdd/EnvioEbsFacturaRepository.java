package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.EnvioEbsFactura;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EnvioEbsFacturaRepository extends JpaRepository<EnvioEbsFactura, Long> {
    boolean existsByFactura_IdFactura(Long idFactura);

    @Query("SELECT ef FROM EnvioEbsFactura ef LEFT JOIN FETCH ef.factura WHERE ef.envioEbs.idEnvioEbs = :idEnvioEbs")
    List<EnvioEbsFactura> findByEnvioEbs_IdEnvioEbs(@Param("idEnvioEbs") Long idEnvioEbs);
}
