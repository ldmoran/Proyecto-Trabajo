package com.finanzas.gestionfinanzas.repository.apps;

import com.finanzas.gestionfinanzas.entity.Factura;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import java.util.List;

@Repository
public interface FacturaRepository extends JpaRepository<Factura, Long> {

    @Query(value = "SELECT * FROM APPS.XXOCS_AR_FACTURAS_INGRESOS_V",
            countQuery = "SELECT COUNT(*) FROM APPS.XXOCS_AR_FACTURAS_INGRESOS_V",
            nativeQuery = true)
    Page<Factura> findFacturas(Pageable pageable);

    // Trae TODAS las facturas cuyo FEC_EMBARQUE caiga en el rango [fecEmbarqueInicio,
    // fecEmbarqueFin] (7 días desde la fecha buscada), sin paginar, porque estos resultados
    // se van a sincronizar completos a la tabla local FACTURAS (si se paginara aquí, solo
    // se guardarían los de la página actual).
    // FEC_EMBARQUE es texto libre con formatos mezclados (confirmado en la BDD real):
    //   'YYYY/MM/DD HH24:MI:SS' (ej. 2023/02/04 00:00:00)
    //   'DD/MM/YYYY HH24:MI:SS' (ej. 19/12/2022 19:00:00)
    //   'DD/MM/RR' sin hora     (ej. 31/10/25 -> 31-oct-2025)
    // y también filas en blanco. El CASE detecta cada formato por su forma (REGEXP_LIKE)
    // y lo convierte a DATE real; lo que no calza con ninguno queda NULL y no entra en
    // el rango (no hay forma confiable de interpretarlo).
    // El REGEXP_LIKE solo valida la FORMA del texto (dígitos y separadores), no que sea
    // una fecha de calendario válida — una fila con, ej., día 30 de febrero calza el
    // patrón pero hace que TO_DATE reviente con ORA-01847 y tumbe la consulta entera
    // (le pasó a un usuario real buscando por Fecha Embarque, sin relación con la fila
    // rota). Por eso cada WHEN valida también que el mes esté entre 1-12 y el día no
    // pase del máximo de ese mes (Febrero se acota a 28 siempre, sin lógica de año
    // bisiesto, para no arriesgarse a que un 29 de febrero de un año no bisiesto vuelva
    // a hacer explotar el TO_DATE) — así la fila con fecha imposible directamente no
    // entra en ningún WHEN y queda NULL (fuera del rango), sin que TO_DATE la vea nunca.
    // (No se usa DEFAULT NULL ON CONVERSION ERROR: esa cláusula de Oracle 12.2+ no la
    // soporta esta base — tiraba ORA-00907 al arrancar.)
    @Query(value = "SELECT * FROM (" +
            "SELECT f.*, " +
            "CASE " +
            "WHEN REGEXP_LIKE(f.FEC_EMBARQUE, '^[0-9]{4}/[0-9]{2}/[0-9]{2}') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 6, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 9, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 6, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(SUBSTR(f.FEC_EMBARQUE, 1, 10), 'YYYY/MM/DD') " +
            "WHEN REGEXP_LIKE(f.FEC_EMBARQUE, '^[0-9]{2}/[0-9]{2}/[0-9]{4}') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 4, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 1, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 4, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(SUBSTR(f.FEC_EMBARQUE, 1, 10), 'DD/MM/YYYY') " +
            "WHEN REGEXP_LIKE(f.FEC_EMBARQUE, '^[0-9]{2}/[0-9]{2}/[0-9]{2}$') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 4, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 1, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_EMBARQUE, 4, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(f.FEC_EMBARQUE, 'DD/MM/RR') " +
            "ELSE NULL END AS FEC_EMBARQUE_PARSED, " +
            "CASE " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{4}/[0-9]{2}/[0-9]{2}') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 6, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 9, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 6, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(SUBSTR(f.FEC_DEPOSITO, 1, 10), 'YYYY/MM/DD') " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{2}/[0-9]{2}/[0-9]{4}') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 4, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 1, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 4, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(SUBSTR(f.FEC_DEPOSITO, 1, 10), 'DD/MM/YYYY') " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{2}/[0-9]{2}/[0-9]{2}$') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 4, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 1, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 4, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(f.FEC_DEPOSITO, 'DD/MM/RR') " +
            "ELSE NULL END AS FEC_DEPOSITO_PARSED " +
            "FROM APPS.XXOCS_AR_FACTURAS_INGRESOS_V f" +
            ") f " +
            "WHERE f.FEC_EMBARQUE_PARSED >= TO_DATE(:fecEmbarqueInicio, 'YYYY-MM-DD') " +
            "AND f.FEC_EMBARQUE_PARSED < TO_DATE(:fecEmbarqueFin, 'YYYY-MM-DD') + 1 " +
            "AND (NULLIF(TRIM(:ruc), '') IS NULL OR f.RUC = :ruc) " +
            "AND (NULLIF(TRIM(:numFactura), '') IS NULL OR f.NUM_FACTURA = :numFactura) " +
            "AND (NULLIF(TRIM(:fecDeposito), '') IS NULL OR f.FEC_DEPOSITO_PARSED = TO_DATE(:fecDeposito, 'YYYY-MM-DD')) " +
            "AND (NULLIF(TRIM(:fecFactura), '') IS NULL OR f.FEC_FACTURA = TO_DATE(:fecFactura, 'YYYY-MM-DD'))",
            nativeQuery = true)
    List<Factura> buscarTodasPorRangoEmbarque(@Param("fecEmbarqueInicio") String fecEmbarqueInicio,
                                              @Param("fecEmbarqueFin") String fecEmbarqueFin,
                                              @Param("ruc") String ruc,
                                              @Param("numFactura") String numFactura,
                                              @Param("fecDeposito") String fecDeposito,
                                              @Param("fecFactura") String fecFactura);

    // Misma lógica que buscarTodasPorRangoEmbarque pero usando FEC_DEPOSITO como
    // rango obligatorio (7 días desde la fecha buscada). FEC_DEPOSITO tiene los MISMOS
    // formatos de texto mezclados que FEC_EMBARQUE (confirmado con datos reales, ej.
    // '03/07/26' -> DD/MM/RR), así que necesita el mismo CASE/REGEXP_LIKE para convertirla.
    @Query(value = "SELECT * FROM (" +
            "SELECT f.*, " +
            "CASE " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{4}/[0-9]{2}/[0-9]{2}') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 6, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 9, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 6, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(SUBSTR(f.FEC_DEPOSITO, 1, 10), 'YYYY/MM/DD') " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{2}/[0-9]{2}/[0-9]{4}') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 4, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 1, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 4, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(SUBSTR(f.FEC_DEPOSITO, 1, 10), 'DD/MM/YYYY') " +
            "WHEN REGEXP_LIKE(f.FEC_DEPOSITO, '^[0-9]{2}/[0-9]{2}/[0-9]{2}$') " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 4, 2)) BETWEEN 1 AND 12 " +
            "AND TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 1, 2)) BETWEEN 1 AND CASE TO_NUMBER(SUBSTR(f.FEC_DEPOSITO, 4, 2)) WHEN 2 THEN 28 WHEN 4 THEN 30 WHEN 6 THEN 30 WHEN 9 THEN 30 WHEN 11 THEN 30 ELSE 31 END " +
            "THEN TO_DATE(f.FEC_DEPOSITO, 'DD/MM/RR') " +
            "ELSE NULL END AS FEC_DEPOSITO_PARSED " +
            "FROM APPS.XXOCS_AR_FACTURAS_INGRESOS_V f" +
            ") f " +
            "WHERE f.FEC_DEPOSITO_PARSED >= TO_DATE(:fecDepositoInicio, 'YYYY-MM-DD') " +
            "AND f.FEC_DEPOSITO_PARSED < TO_DATE(:fecDepositoFin, 'YYYY-MM-DD') + 1 " +
            "AND (NULLIF(TRIM(:ruc), '') IS NULL OR f.RUC = :ruc) " +
            "AND (NULLIF(TRIM(:numFactura), '') IS NULL OR f.NUM_FACTURA = :numFactura) " +
            "AND (NULLIF(TRIM(:fecFactura), '') IS NULL OR f.FEC_FACTURA = TO_DATE(:fecFactura, 'YYYY-MM-DD'))",
            nativeQuery = true)
    List<Factura> buscarTodasPorRangoDeposito(@Param("fecDepositoInicio") String fecDepositoInicio,
                                              @Param("fecDepositoFin") String fecDepositoFin,
                                              @Param("ruc") String ruc,
                                              @Param("numFactura") String numFactura,
                                              @Param("fecFactura") String fecFactura);

    // Búsqueda directa por Número o RUC, SIN acotar por fecha: trae todo lo que haya
    // en la vista del ERP para ese número/RUC, a diferencia de las dos búsquedas de
    // arriba que solo miran una ventana de 7 días. La usan las cajitas de búsqueda
    // por columna (Número/RUC) de "Ver facturas". Al menos uno de los dos parámetros
    // debe venir con valor (si vinieran los dos nulos, traería la vista completa).
    @Query(value = "SELECT * FROM APPS.XXOCS_AR_FACTURAS_INGRESOS_V f WHERE " +
            "(:ruc IS NULL OR f.RUC = :ruc) " +
            "AND (:numFactura IS NULL OR f.NUM_FACTURA = :numFactura)",
            nativeQuery = true)
    List<Factura> buscarPorNumFacturaORuc(@Param("ruc") String ruc, @Param("numFactura") String numFactura);

}
