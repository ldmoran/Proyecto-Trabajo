package com.finanzas.gestionfinanzas.controller;

import com.finanzas.gestionfinanzas.entity.ConceptoIngreso;
import com.finanzas.gestionfinanzas.entity.Cuenta;
import com.finanzas.gestionfinanzas.repository.bdd.ConceptoIngresoRepository;
import com.finanzas.gestionfinanzas.repository.bdd.CuentaRepository;
import com.finanzas.gestionfinanzas.service.impl.AuditoriaSessionService;
import com.finanzas.gestionfinanzas.utils.SecurityUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/mantenimiento/conceptos-ingreso")
public class MantenimientoConceptoIngresoController {

    private final ConceptoIngresoRepository conceptoIngresoRepository;
    private final CuentaRepository cuentaRepository;
    private final AuditoriaSessionService auditoriaSessionService;

    public MantenimientoConceptoIngresoController(ConceptoIngresoRepository conceptoIngresoRepository,
                                                    CuentaRepository cuentaRepository,
                                                    AuditoriaSessionService auditoriaSessionService) {
        this.conceptoIngresoRepository = conceptoIngresoRepository;
        this.cuentaRepository = cuentaRepository;
        this.auditoriaSessionService = auditoriaSessionService;
    }

    @GetMapping
    public String listar(@RequestParam(defaultValue = "0") int page,
                          @RequestParam(required = false) String nombre,
                          @RequestParam(required = false) String estado,
                          HttpServletRequest request, Model model) {
        Page<ConceptoIngreso> conceptosIngresoPage =
                conceptoIngresoRepository.buscar(normalizar(nombre), normalizar(estado), PageRequest.of(page, 10));

        model.addAttribute("path", request.getRequestURI());
        model.addAttribute("conceptosIngresoPage", conceptosIngresoPage);
        model.addAttribute("cuentas", cuentaRepository.findByEstadoOrderByNumeroCuentaAsc("A"));
        model.addAttribute("nombre", nombre);
        model.addAttribute("estado", estado);
        return "mantenimiento/conceptos-ingreso";
    }

    private String normalizar(String valor) {
        if (valor == null) {
            return null;
        }
        String limpio = valor.trim();
        return limpio.isEmpty() ? null : limpio;
    }

    @PostMapping("/guardar")
    @Transactional("secondTransactionManager")
    public String guardar(@RequestParam(required = false) Long idConcepto,
                           @RequestParam String nombreConcepto,
                           @RequestParam(required = false) Long idCuenta,
                           @RequestParam String estado,
                           RedirectAttributes redirectAttributes) {

        auditoriaSessionService.activarUsuarioActual();

        ConceptoIngreso conceptoIngreso = (idConcepto != null)
                ? conceptoIngresoRepository.findById(idConcepto).orElseThrow(() -> new RuntimeException("Concepto de ingreso no encontrado"))
                : new ConceptoIngreso();

        boolean esNuevo = conceptoIngreso.getIdConcepto() == null;

        conceptoIngreso.setNombreConcepto(nombreConcepto.trim());
        conceptoIngreso.setEstado(estado);

        if (idCuenta != null) {
            Cuenta cuenta = cuentaRepository.findById(idCuenta).orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
            conceptoIngreso.setCuenta(cuenta);
        } else {
            conceptoIngreso.setCuenta(null);
        }

        if (esNuevo) {
            conceptoIngreso.setIdUsuarioCreacion(obtenerUsuarioActual());
            conceptoIngreso.setFechaCreacion(LocalDateTime.now());
        }

        conceptoIngresoRepository.save(conceptoIngreso);
        auditoriaSessionService.registrarComentario("CONCEPTO_INGRESO", conceptoIngreso.getIdConcepto(),
                esNuevo ? "INSERT" : "UPDATE",
                (esNuevo ? "Creó" : "Editó") + " el concepto de ingreso " + conceptoIngreso.getNombreConcepto() + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/conceptos-ingreso";
    }

    @PostMapping("/eliminar/{idConcepto}")
    @Transactional("secondTransactionManager")
    public String eliminar(@PathVariable Long idConcepto, RedirectAttributes redirectAttributes) {
        auditoriaSessionService.activarUsuarioActual();

        String nombreEliminado = conceptoIngresoRepository.findById(idConcepto)
                .map(ConceptoIngreso::getNombreConcepto).orElse("(desconocido)");
        try {
            conceptoIngresoRepository.deleteById(idConcepto);
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "No se puede eliminar: tiene registros asociados en algún reporte de Flujo de Caja");
            return "redirect:/mantenimiento/conceptos-ingreso";
        }
        auditoriaSessionService.registrarComentario("CONCEPTO_INGRESO", idConcepto, "DELETE",
                "Eliminó el concepto de ingreso " + nombreEliminado + ".");

        redirectAttributes.addFlashAttribute("ok", true);
        return "redirect:/mantenimiento/conceptos-ingreso";
    }

    private String obtenerUsuarioActual() {
        return SecurityUtils.getUsuarioActual() != null
                ? SecurityUtils.getUsuarioActual().getUsuario()
                : null;
    }
}