package com.finanzas.gestionfinanzas.repository.bdd;

import com.finanzas.gestionfinanzas.entity.ProvisionPagoSeleccionado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProvisionPagoSeleccionadoRepository extends JpaRepository<ProvisionPagoSeleccionado, Long> {

    List<ProvisionPagoSeleccionado> findByRegistro_IdRegistro(Long idRegistro);

    // Qué facturas (RUC+Documento) ya se pagaron alguna vez desde Provisiones,
    // sin importar en qué registro/semana — para no ofrecerlas de nuevo en el
    // selector de Pendiente/Mixto (ver ProvisionesController.verProvisiones).
    // Solo estas 2 columnas, no la entidad completa: no hace falta traer
    // proveedor/monto/fecha para armar el filtro.
    @Query("SELECT p.ruc, p.documento FROM ProvisionPagoSeleccionado p")
    List<Object[]> findRucDocumentoUsados();
}
