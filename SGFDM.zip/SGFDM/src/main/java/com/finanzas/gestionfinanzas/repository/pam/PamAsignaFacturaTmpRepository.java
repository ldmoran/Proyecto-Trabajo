package com.finanzas.gestionfinanzas.repository.pam;

import com.finanzas.gestionfinanzas.entity.PamAsignaFacturaTmp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PamAsignaFacturaTmpRepository extends JpaRepository<PamAsignaFacturaTmp, Long> {

    // INSERT directo (no .save()): esta tabla no tiene una clave primaria real
    // que garantice que INVOICE_ID sea único para Hibernate, así que un
    // .save() intentaría un merge (SELECT + UPDATE/INSERT) en vez del INSERT
    // limpio que queremos acá.
    @Modifying
    @Query(value = "INSERT INTO XX_PAM.PAM_ASIGNA_FACTURAS_TMP (INVOICE_ID, COMENTARIO, LOAD_DATE, CODIGO_FC) " +
            "VALUES (:invoiceId, :comentario, SYSDATE, :codigoFc)", nativeQuery = true)
    void insertar(@Param("invoiceId") Long invoiceId, @Param("comentario") String comentario, @Param("codigoFc") String codigoFc);
}
